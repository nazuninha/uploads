const path = require('path');
const fs = require('fs');

async function initGoldSystem(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  };
  return {
    user: async(id) => {
      const userFile = path.join(dirPath, id+'.json');
      if (fs.existsSync(userFile)) {
        return JSON.parse(fs.readFileSync(userFile, 'utf-8'));
      } else {
        fs.writeFileSync(userFile, JSON.stringify({}));
        return {};
      };
    };
  };
};

module.exports = {
  
};