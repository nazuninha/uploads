const path = require('path');
const fs = require('fs').promises;
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const RENTAL_FILE = path.join(DATABASE_DIR, 'rentalData.json');

const ensureJsonFileExists = async (file, defaultData) => {
  try {
    if (!(await fs.access(file).then(() => true).catch(() => false))) {
      await fs.mkdir(DATABASE_DIR, { recursive: true });
      await fs.writeFile(file, JSON.stringify(defaultData, null, 2));
    }
  } catch (error) {
    console.error(`Erro ao garantir existência do arquivo ${file}:`, error);
  }
};

const loadJsonFile = async (file, defaultData) => {
  try {
    const data = await fs.readFile(file, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

const updateGroupNameCache = async (nazu, groupId, rentalData) => {
  try {
    const groupMetadata = await nazu.groupMetadata(groupId);
    rentalData.groups[groupId].groupName = groupMetadata.subject || 'Sem Nome';
    await fs.writeFile(RENTAL_FILE, JSON.stringify(rentalData, null, 2));
    return rentalData.groups[groupId].groupName;
  } catch (error) {
    console.error(`Erro ao atualizar cache do grupo ${groupId}:`, error);
    return 'Desconhecido';
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_listaluguel: {
        only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
        header: (nomebot, globalMode, groupCount) => `╭───「 *Lista de Aluguéis - ${nomebot}* 」───╮\n│ 🌍 *Modo Aluguel Global*: ${globalMode}\n│ 📊 *Total de Grupos*: ${groupCount}\n╰────────────────╯\n`,
        no_groups: () => '📪 Nenhum grupo com aluguel registrado.',
        group_entry: (index, groupName, status, expires) => `🔹 *${index}. ${groupName}*\n  - *Status*: ${status}\n  - *Expira em*: ${expires}\n\n`,
        no_groups_filtered: () => '📪 Nenhum grupo encontrado com esse filtro.',
        invalid_filter: (prefix) => `🤔 Filtro inválido! Use: ${prefix}listaluguel [ven|atv|perm]`,
        error: () => '❌ Ocorreu um erro ao listar os aluguéis 💔'
      }
    };
  }
})();

const commandMap = {
  listaluguel: {
    key: 'listaluguel',
    action: 'list_rentals',
    aliases: ['listaralugueis', 'aluguelist', 'listaaluguel', 'listrentals', 'listalocaciones', 'listlocations', 'daftarsewa']
  }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-19',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query, args) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_listaluguel.only_owner() }, { quoted: info });
      }

      const rentalData = await loadJsonFile(RENTAL_FILE, { globalMode: false, groups: {} });
      await ensureJsonFileExists(RENTAL_FILE, { globalMode: false, groups: {} });

      const globalMode = rentalData.globalMode ? '🟢 Ativo' : '🔴 Desativado';
      const groupRentals = rentalData.groups || {};
      const groupCount = Object.keys(groupRentals).length;

      const filtro = args[0]?.toLowerCase();
      if (filtro && !['ven', 'atv', 'perm'].includes(filtro)) {
        return nazu.sendMessage(from, { text: lang.plugin_listaluguel.invalid_filter(info.prefix) }, { quoted: info });
      }

      let message = lang.plugin_listaluguel.header(info.nomebot, globalMode, groupCount);

      if (groupCount === 0) {
        message += lang.plugin_listaluguel.no_groups();
      } else {
        message += '📋 *Grupos com Aluguel*:\n\n';
        let index = 1;

        for (const [groupId, info] of Object.entries(groupRentals)) {
          let status = 'Expirado';
          if (info.expiresAt === 'permanent') {
            status = 'Permanente';
          } else if (info.expiresAt && new Date(info.expiresAt) > new Date()) {
            status = 'Ativo';
          }

          const shouldInclude =
            !filtro ||
            (filtro === 'ven' && status === 'Expirado') ||
            (filtro === 'atv' && status === 'Ativo') ||
            (filtro === 'perm' && status === 'Permanente');

          if (!shouldInclude) continue;

          let groupName = info.groupName || 'Sem Nome';
          if (!info.groupName) {
            groupName = await updateGroupNameCache(nazu, groupId, rentalData);
          }

          const expires = info.expiresAt === 'permanent'
            ? '∞ Permanente'
            : info.expiresAt
              ? new Date(info.expiresAt).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })
              : 'N/A';

          message += lang.plugin_listaluguel.group_entry(index, groupName, status, expires);
          index++;
        }

        if (index === 1) {
          message += lang.plugin_listaluguel.no_groups_filtered();
        }
      }

      return nazu.sendMessage(from, { text: message }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_listaluguel.error() }, { quoted: info });
    }
  }
};