const path = require('path');
const fs = require('fs');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const BLOCK_FILE = path.join(DATABASE_DIR, 'globalBlocks.json');

const ensureJsonFileExists = (file, defaultData) => {
  if (!fs.existsSync(file)) {
    ensureDirectoryExists(DATABASE_DIR);
    fs.writeFileSync(file, JSON.stringify(defaultData, null, 2));
  }
};

const ensureDirectoryExists = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

const loadJsonFile = (file, defaultData) => {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_global_block_manager: {
        only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
        no_command: (prefix, command) => `❌ Informe o comando a bloquear/desbloquear! Ex.: ${prefix}${command} sticker`,
        no_user: () => '🤔 Marque alguém ou forneça o ID do usuário! 🙄',
        command_already_blocked: (cmd) => `❌ O comando *${cmd}* já está bloqueado!`,
        command_not_blocked: (cmd) => `❌ O comando *${cmd}* não está bloqueado!`,
        user_already_blocked: (user) => `❌ O usuário @${user} já está bloqueado!`,
        user_not_blocked: (user) => `❌ O usuário @${user} não está bloqueado!`,
        default_reason: () => 'Não informado',
        command_blocked: (cmd, reason) => `✅ Comando *${cmd}* bloqueado globalmente!\nMotivo: ${reason}`,
        command_unblocked: (cmd) => `✅ Comando *${cmd}* desbloqueado globalmente!`,
        user_blocked: (user, reason) => `✅ Usuário @${user} bloqueado globalmente!\nMotivo: ${reason}`,
        user_unblocked: (user) => `✅ Usuário @${user} desbloqueado globalmente!`,
        no_blocked_commands: () => 'Nenhum comando bloqueado.',
        no_blocked_users: () => 'Nenhum usuário bloqueado.',
        list_blocks: (nomebot, blockedCommands, blockedUsers) => `🔒 *Bloqueios Globais - ${nomebot}* 🔒\n\n📜 *Comandos Bloqueados*:\n${blockedCommands}\n\n👥 *Usuários Bloqueados*:\n${blockedUsers}`,
        error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
      }
    };
  }
})();

const commandMap = {
  blockcmdg: { key: 'blockcmdg', action: 'block_command', aliases: ['blockcmdglobal', 'bloquearcmdglobal', 'bloquercmdglobal', 'blokirkmdglobal'] },
  unblockcmdg: { key: 'unblockcmdg', action: 'unblock_command', aliases: ['unblockcmdglobal', 'desbloquearcmdglobal', 'debloquercmdglobal', 'bukaankmdglobal'] },
  blockuserg: { key: 'blockuserg', action: 'block_user', aliases: ['blockuserglobal', 'bloquearusuarioglobal', 'bloquerutilisateurglobal', 'blokiruserglobal'] },
  unblockuserg: { key: 'unblockuserg', action: 'unblock_user', aliases: ['unblockuserglobal', 'desbloquearusuarioglobal', 'debloquerutilisateurglobal', 'bukaanuserglobal'] },
  listblocks: { key: 'listblocks', action: 'list_blocks', aliases: ['listablocos', 'listbloqueios', 'listabloqueos', 'listebloqueios', 'daftarblokir'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-17',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.only_owner() }, { quoted: info });
      }

      const blockFile = BLOCK_FILE;
      let globalBlocks = loadJsonFile(blockFile, { commands: {}, users: {} });
      ensureJsonFileExists(blockFile, { commands: {}, users: {} });

      if (config.action === 'block_command') {
        const cmdToBlock = query?.toLowerCase().split(' ')[0];
        const reason = query?.split(' ').slice(1).join(' ') || lang.plugin_global_block_manager.default_reason();
        if (!cmdToBlock) {
          return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.no_command(info.prefix, command) }, { quoted: info });
        }
        globalBlocks.commands = globalBlocks.commands || {};
        if (globalBlocks.commands[cmdToBlock]) {
          return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.command_already_blocked(cmdToBlock) }, { quoted: info });
        }
        globalBlocks.commands[cmdToBlock] = { reason, timestamp: Date.now() };
        fs.writeFileSync(blockFile, JSON.stringify(globalBlocks, null, 2));
        return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.command_blocked(cmdToBlock, reason) }, { quoted: info });
      }

      if (config.action === 'unblock_command') {
        const cmdToUnblock = query?.toLowerCase().split(' ')[0];
        if (!cmdToUnblock) {
          return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.no_command(info.prefix, command) }, { quoted: info });
        }
        globalBlocks.commands = globalBlocks.commands || {};
        if (!globalBlocks.commands[cmdToUnblock]) {
          return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.command_not_blocked(cmdToUnblock) }, { quoted: info });
        }
        delete globalBlocks.commands[cmdToUnblock];
        fs.writeFileSync(blockFile, JSON.stringify(globalBlocks, null, 2));
        return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.command_unblocked(cmdToUnblock) }, { quoted: info });
      }

      if (config.action === 'block_user') {
        const userToBlock = info.menc_jid2 && info.menc_jid2.length > 0 ? info.menc_jid2[0] : null;
        if (!userToBlock) {
          return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.no_user() }, { quoted: info });
        }
        const reason = query && query.includes(' ') ? query.split(' ').slice(1).join(' ') : lang.plugin_global_block_manager.default_reason();
        globalBlocks.users = globalBlocks.users || {};
        const userId = userToBlock.includes('@') ? userToBlock : userToBlock + '@s.whatsapp.net';
        if (globalBlocks.users[userId]) {
          return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.user_already_blocked(userId.split('@')[0]), mentions: [userId] }, { quoted: info });
        }
        globalBlocks.users[userId] = { reason, timestamp: Date.now() };
        fs.writeFileSync(blockFile, JSON.stringify(globalBlocks, null, 2));
        return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.user_blocked(userId.split('@')[0], reason), mentions: [userId] }, { quoted: info });
      }

      if (config.action === 'unblock_user') {
        const userToUnblock = info.menc_jid2 && info.menc_jid2.length > 0 ? info.menc_jid2[0] : null;
        if (!userToUnblock) {
          return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.no_user() }, { quoted: info });
        }
        globalBlocks.users = globalBlocks.users || {};
        const userId = userToUnblock.includes('@') ? userToUnblock : userToUnblock + '@s.whatsapp.net';
        const userIdShort = userToUnblock.split('@')[0];
        if (!globalBlocks.users[userId] && !globalBlocks.users[userIdShort]) {
          return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.user_not_blocked(userIdShort), mentions: [userId] }, { quoted: info });
        }
        if (globalBlocks.users[userId]) {
          delete globalBlocks.users[userId];
        } else if (globalBlocks.users[userIdShort]) {
          delete globalBlocks.users[userIdShort];
        }
        fs.writeFileSync(blockFile, JSON.stringify(globalBlocks, null, 2));
        return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.user_unblocked(userIdShort), mentions: [userId] }, { quoted: info });
      }

      if (config.action === 'list_blocks') {
        const blockedCommands = globalBlocks.commands && Object.keys(globalBlocks.commands).length > 0
          ? Object.entries(globalBlocks.commands).map(([cmd, data]) => `🔧 *${cmd}* - Motivo: ${data.reason}`).join('\n')
          : lang.plugin_global_block_manager.no_blocked_commands();
        const blockedUsers = globalBlocks.users && Object.keys(globalBlocks.users).length > 0
          ? Object.entries(globalBlocks.users).map(([user, data]) => `👤 *${user.split('@')[0]}* - Motivo: ${data.reason}`).join('\n')
          : lang.plugin_global_block_manager.no_blocked_users();
        const message = lang.plugin_global_block_manager.list_blocks(info.nomebot, blockedCommands, blockedUsers);
        return nazu.sendMessage(from, { text: message }, { quoted: info });
      }
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_global_block_manager.error() }, { quoted: info });
    }
  }
};