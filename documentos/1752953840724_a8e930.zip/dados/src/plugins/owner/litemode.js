const path = require('path');
const fs = require('fs').promises;
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const MODOLITE_FILE = path.join(DATABASE_DIR, 'modolite.json');

const ensureJsonFileExists = async (file, defaultData) => {
  try {
    if (!(await fs.access(file).then(() => true).catch(() => false))) {
      await fs.mkdir(DATABASE_DIR, { recursive: true });
      await fs.writeFile(file, JSON.stringify(defaultData, null, 2));
    }
  } catch (error) {
    console.error(`Erro ao garantir existência do arquivo ${file}:`, error);
  }
};

const loadJsonFile = async (file, defaultData) => {
  try {
    const data = await fs.readFile(file, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_modoliteglobal: {
        only_owner: () => '🚫 Este comando é apenas para o meu dono! 💔',
        lite_enabled: () => '👶 *Modo Lite ativado globalmente!* O conteúdo inapropriado para crianças será filtrado em todos os grupos (a menos que seja explicitamente desativado em algum grupo).',
        lite_disabled: () => '🔞 *Modo Lite desativado globalmente!* O conteúdo do menu de brincadeiras será exibido completamente (a menos que seja explicitamente ativado em algum grupo).',
        error: () => '❌ Ocorreu um erro inesperado ao alterar o modo lite.'
      }
    };
  }
})();

const commandMap = {
  modoliteglobal: {
    key: 'modoliteglobal',
    action: 'toggle_lite_global',
    aliases: ['liteglobal', 'modolitglobal', 'modeliteglobal', 'modelegerglobal', 'modeliteglobal']
  }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-19',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_modoliteglobal.only_owner() }, { quoted: info });
      }

      const modoLiteFile = MODOLITE_FILE;
      let modoLiteGlobal = await loadJsonFile(modoLiteFile, { status: false });
      await ensureJsonFileExists(modoLiteFile, { status: false });

      modoLiteGlobal.status = !modoLiteGlobal.status;

      if (!modoLiteGlobal.status) {
        modoLiteGlobal.forceOff = true;
      } else if (modoLiteGlobal.hasOwnProperty('forceOff')) {
        delete modoLiteGlobal.forceOff;
      }

      await fs.writeFile(modoLiteFile, JSON.stringify(modoLiteGlobal, null, 2));

      const message = modoLiteGlobal.status
        ? lang.plugin_modoliteglobal.lite_enabled()
        : lang.plugin_modoliteglobal.lite_disabled();
      return nazu.sendMessage(from, { text: message }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_modoliteglobal.error() }, { quoted: info });
    }
  }
};