const path = require('path');
const fs = require('fs');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const BOT_STATE_FILE = path.join(DATABASE_DIR, 'botState.json');

const ensureJsonFileExists = (file, defaultData) => {
  if (!fs.existsSync(file)) {
    ensureDirectoryExists(DATABASE_DIR);
    fs.writeFileSync(file, JSON.stringify(defaultData, null, 2));
  }
};

const ensureDirectoryExists = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

const loadJsonFile = (file, defaultData) => {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_bot_state: {
        only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
        already_on: () => '🌟 O bot já está ativado!',
        already_off: () => '🌙 O bot já está desativado!',
        bot_on: () => '✅ *Bot ativado!* Agora todos podem usar os comandos.',
        bot_off: () => '✅ *Bot desativado!* Apenas o dono pode usar comandos.',
        error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
      }
    };
  }
})();

const commandMap = {
  boton: { key: 'boton', action: 'set_bot_on', aliases: ['botligar', 'botactiver', 'botactivar', 'botnyala'] },
  botoff: { key: 'botoff', action: 'set_bot_off', aliases: ['botdesligar', 'botdesactiver', 'botdesactivar', 'botmatikan'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-17',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_bot_state.only_owner() }, { quoted: info });
      }

      const botStateFile = BOT_STATE_FILE;
      let botState = loadJsonFile(botStateFile, { status: 'on' });
      ensureJsonFileExists(botStateFile, { status: 'on' });

      const isOn = botState.status === 'on';
      if (config.action === 'set_bot_on' && isOn) {
        return nazu.sendMessage(from, { text: lang.plugin_bot_state.already_on() }, { quoted: info });
      }
      if (config.action === 'set_bot_off' && !isOn) {
        return nazu.sendMessage(from, { text: lang.plugin_bot_state.already_off() }, { quoted: info });
      }

      botState.status = config.action === 'set_bot_on' ? 'on' : 'off';
      fs.writeFileSync(botStateFile, JSON.stringify(botState, null, 2));

      const message = config.action === 'set_bot_on' ? lang.plugin_bot_state.bot_on() : lang.plugin_bot_state.bot_off();
      return nazu.sendMessage(from, { text: message }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_bot_state.error() }, { quoted: info });
    }
  }
};