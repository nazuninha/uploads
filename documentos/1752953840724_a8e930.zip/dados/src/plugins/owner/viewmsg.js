const path = require('path');
const fs = require('fs').promises;
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const BOT_STATE_FILE = path.join(DATABASE_DIR, 'botState.json');

const ensureJsonFileExists = async (file, defaultData) => {
  try {
    if (!(await fs.access(file).then(() => true).catch(() => false))) {
      await fs.mkdir(DATABASE_DIR, { recursive: true });
      await fs.writeFile(file, JSON.stringify(defaultData, null, 2));
    }
  } catch (error) {
    console.error(`Erro ao garantir existência do arquivo ${file}:`, error);
  }
};

const loadJsonFile = async (file, defaultData) => {
  try {
    const data = await fs.readFile(file, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_viewmsg: {
        only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
        invalid_usage: (prefix) => `🤔 Use: ${prefix}viewmsg [on/off]`,
        viewmsg_on: () => '✅ Visualização de mensagens ativada!',
        viewmsg_off: () => '✅ Visualização de mensagens desativada!',
        error: () => '😥 Ocorreu um erro ao alterar a visualização de mensagens.'
      }
    };
  }
})();

const commandMap = {
  viewmsg: { key: 'viewmsg', action: 'toggle_viewmsg', aliases: ['vermsg', 'visualizarmensagens', 'vermensajes', 'voirmessages', 'lihatpesan'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-19',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_viewmsg.only_owner() }, { quoted: info });
      }

      if (!query || !['on', 'off'].includes(query.toLowerCase())) {
        return nazu.sendMessage(from, { text: lang.plugin_viewmsg.invalid_usage(info.prefix) }, { quoted: info });
      }

      const botStateFile = BOT_STATE_FILE;
      let botState = await loadJsonFile(botStateFile, { status: 'on', viewMessages: true });
      await ensureJsonFileExists(botStateFile, { status: 'on', viewMessages: true });

      const newState = query.toLowerCase() === 'on';
      botState.viewMessages = newState;
      await fs.writeFile(botStateFile, JSON.stringify(botState, null, 2));

      const message = newState ? lang.plugin_viewmsg.viewmsg_on() : lang.plugin_viewmsg.viewmsg_off();
      return nazu.sendMessage(from, { text: message }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_viewmsg.error() }, { quoted: info });
    }
  }
};