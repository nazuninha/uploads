const { loadMessages, getMessages } = require('../../langs/loader.js');

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_group_list: {
        only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
        group_list: (nomebot, totalGroups, groupsText) => `🌟 *Lista de Grupos e Comunidades - ${nomebot}* 🌟\n📊 *Total de Grupos:* ${totalGroups}\n\n${groupsText}`,
        no_groups: () => 'Nenhum grupo encontrado.',
        group_entry: (index, subject, id, participantCount) => `🔹 *${index}. ${subject}*\n🆔 *ID:* ${id}\n👥 *Participantes:* ${participantCount}\n\n`,
        error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
      }
    };
  }
})();

const commandMap = {
  listagp: { key: 'listagp', action: 'list_groups', aliases: ['listgp', 'listagrupos', 'listagrupos', 'listagrupo', 'listargrupos', 'listargrupo', 'listagrupos', 'listagroupes', 'daftargroup'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-17',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_group_list.only_owner() }, { quoted: info });
      }

      const getGroups = await nazu.groupFetchAllParticipating();
      const groups = Object.entries(getGroups).map(entry => entry[1]);
      const sortedGroups = groups.sort((a, b) => a.subject.localeCompare(b.subject));

      let groupsText = '';
      if (sortedGroups.length > 0) {
        groupsText = sortedGroups.map((group, i) =>
          lang.plugin_group_list.group_entry(i + 1, group.subject, group.id, group.participants.length)
        ).join('');
      } else {
        groupsText = lang.plugin_group_list.no_groups();
      }

      const message = lang.plugin_group_list.group_list(info.nomebot, sortedGroups.length, groupsText);
      return nazu.sendMessage(from, { text: message }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_group_list.error() }, { quoted: info });
    }
  }
};