const path = require('path');
const fs = require('fs').promises;
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const RENTAL_FILE = path.join(DATABASE_DIR, 'rentalData.json');

const ensureJsonFileExists = async (file, defaultData) => {
  try {
    if (!(await fs.access(file).then(() => true).catch(() => false))) {
      await fs.mkdir(DATABASE_DIR, { recursive: true });
      await fs.writeFile(file, JSON.stringify(defaultData, null, 2));
    }
  } catch (error) {
    console.error(`Erro ao garantir existência do arquivo ${file}:`, error);
  }
};

const loadJsonFile = async (file, defaultData) => {
  try {
    const data = await fs.readFile(file, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

const updateGroupNameCache = async (nazu, groupId, rentalData) => {
  try {
    const groupMetadata = await nazu.groupMetadata(groupId);
    rentalData.groups[groupId] = rentalData.groups[groupId] || {};
    rentalData.groups[groupId].groupName = groupMetadata.subject || 'Sem Nome';
    await fs.writeFile(RENTAL_FILE, JSON.stringify(rentalData, null, 2));
    return rentalData.groups[groupId].groupName;
  } catch (error) {
    console.error(`Erro ao atualizar cache do grupo ${groupId}:`, error);
    return 'Desconhecido';
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_entrar: {
        only_owner: () => '🚫 Este comando é apenas para o meu dono! 💔',
        invalid_link: (prefix) => `🤔 Digite um link de convite válido! Exemplo: ${prefix}entrar https://chat.whatsapp.com/...`,
        success: () => '✅ Entrei no grupo com sucesso!',
        error_join: () => '❌ Erro ao entrar no grupo. Link inválido, permissão negada ou bot já está no grupo.',
        error: () => '❌ Ocorreu um erro inesperado ao tentar entrar no grupo.'
      }
    };
  }
})();

const commandMap = {
  entrar: {
    key: 'entrar',
    action: 'join_group',
    aliases: ['entrargrupo', 'join', 'unirse', 'rejoindre', 'gabung']
  }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-19',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_entrar.only_owner() }, { quoted: info });
      }

      if (!query || !query.includes('chat.whatsapp.com')) {
        return nazu.sendMessage(from, { text: lang.plugin_entrar.invalid_link(info.prefix) }, { quoted: info });
      }

      let code;
      try {
        code = query.split('https://chat.whatsapp.com/')[1]?.trim();
        if (!code) throw new Error('Invalid link format');
      } catch {
        return nazu.sendMessage(from, { text: lang.plugin_entrar.invalid_link(info.prefix) }, { quoted: info });
      }

      const groupId = await nazu.groupAcceptInvite(code).catch((err) => {
        console.error('Erro ao entrar no grupo:', err);
        return null;
      });

      if (!groupId) {
        return nazu.sendMessage(from, { text: lang.plugin_entrar.error_join() }, { quoted: info });
      }

      const rentalData = await loadJsonFile(RENTAL_FILE, { globalMode: false, groups: {}, codes: {} });
      await ensureJsonFileExists(RENTAL_FILE, { globalMode: false, groups: {}, codes: {} });
      const groupName = await updateGroupNameCache(nazu, groupId, rentalData);

      return nazu.sendMessage(from, { text: lang.plugin_entrar.success(groupName) }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_entrar.error() }, { quoted: info });
    }
  }
};