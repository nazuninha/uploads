const path = require('path');
const fs = require('fs');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_group_ban: {
        only_owner: () => '⚠️ Desculpe, este comando é exclusivo para o meu dono! 😎',
        only_group: () => '🚫 Este comando só funciona em grupos! Tente em um grupo, por favor! 🗣️',
        success_ban: () => '🚫 Grupo banido! Apenas usuários premium ou meu dono podem usar o bot aqui agora. 🔒',
        success_unban: () => '✅ Grupo desbanido! Todos podem usar o bot novamente. 🎉',
        error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
      }
    };
  }
})();

const commandMap = {
  bangp: { key: 'bangp', action: 'ban', aliases: ['bangroup', 'bangrupo', 'bangroupe', 'bannedgrup'] },
  unbangp: { key: 'unbangp', action: 'unban', aliases: ['unbangroup', 'desbangrupo', 'debangroupe', 'unbannedgrup'] },
  desbangp: { key: 'desbangp', action: 'unban', aliases: ['unbangroup', 'desbangrupo', 'debangroupe', 'unbannedgrup'] }
};

const banGpFile = path.join(__dirname, '..', '..', '..', 'database', 'dono', 'bangp.json');
let banGpIds = {};
if (fs.existsSync(banGpFile)) {
  try {
    banGpIds = JSON.parse(fs.readFileSync(banGpFile, 'utf-8'));
  } catch (error) {
    console.error('Erro ao carregar bangp.json:', error);
    banGpIds = {};
  }
}

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-15',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'group',
  exec: async (nazu, from, sender, info, command, query) => {
    if (!info.isGroup) {
      return nazu.sendMessage(from, { text: lang.plugin_group_ban.only_group() }, { quoted: info });
    }

    if (!info.isOwner) {
      return nazu.sendMessage(from, { text: lang.plugin_group_ban.only_owner() }, { quoted: info });
    }

    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    
    if (!config) return;

    try {
      banGpIds[from] = config.action === 'ban';
      fs.writeFileSync(banGpFile, JSON.stringify(banGpIds, null, 2));

      const successKey = config.action === 'ban' ? 'success_ban' : 'success_unban';
      return nazu.sendMessage(from, { text: lang.plugin_group_ban[successKey]() }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_group_ban.error() }, { quoted: info });
    }
  }
};