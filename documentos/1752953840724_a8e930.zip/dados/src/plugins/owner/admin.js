const path = require('path');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_owner_admin: {
        only_owner: () => '⚠️ Desculpe, este comando é exclusivo para o meu dono! 😎',
        only_group: () => '🚫 Este comando só funciona em grupos! Tente em um grupo, por favor! 🗣️',
        success_seradm: (prefix, command) => `🎉 Você agora é admin! Use seus poderes com sabedoria! 😎`,
        success_sermembro: (prefix, command) => `📌 Você foi rebaixado a membro. Qualquer coisa, é só chamar! 😉`,
        error: (prefix, command) => `🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺`
      }
    };
  }
})();

const commandMap = {
  seradm: { key: 'seradm', action: 'promote', aliases: ['beadmin', 'seradmin', 'etreadmin', 'jadidadmin'] },
  sermembro: { key: 'sermembro', action: 'demote', aliases: ['bemember', 'sermiembro', 'etremembre', 'jadimember'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-15',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'group',
  exec: async (nazu, from, sender, info, command, query) => {
    if (!info.isGroup) {
      return nazu.sendMessage(from, { text: lang.plugin_owner_admin.only_group() }, { quoted: info });
    }

    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    
    if (!config) return;

    if (!info.isOwner) {
      return nazu.sendMessage(from, { text: lang.plugin_owner_admin.only_owner() }, { quoted: info });
    }

    try {
      await nazu.groupParticipantsUpdate(from, [sender], config.action);
      const successKey = `success_${config.key}`;
      return nazu.sendMessage(from, { text: lang.plugin_owner_admin[successKey](info.prefix, command) }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_owner_admin.error(info.prefix, command) }, { quoted: info });
    }
  }
};