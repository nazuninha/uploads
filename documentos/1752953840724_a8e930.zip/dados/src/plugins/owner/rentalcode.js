const path = require('path');
const fs = require('fs').promises;
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const RENTAL_FILE = path.join(DATABASE_DIR, 'rentalData.json');

const ensureJsonFileExists = async (file, defaultData) => {
  try {
    if (!(await fs.access(file).then(() => true).catch(() => false))) {
      await fs.mkdir(DATABASE_DIR, { recursive: true });
      await fs.writeFile(file, JSON.stringify(defaultData, null, 2));
    }
  } catch (error) {
    console.error(`Erro ao garantir existência do arquivo ${file}:`, error);
  }
};

const loadJsonFile = async (file, defaultData) => {
  try {
    const data = await fs.readFile(file, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

const updateGroupNameCache = async (nazu, groupId, rentalData) => {
  try {
    const groupMetadata = await nazu.groupMetadata(groupId);
    rentalData.groups[groupId] = rentalData.groups[groupId] || {};
    rentalData.groups[groupId].groupName = groupMetadata.subject || 'Sem Nome';
    await fs.writeFile(RENTAL_FILE, JSON.stringify(rentalData, null, 2));
    return rentalData.groups[groupId].groupName;
  } catch (error) {
    console.error(`Erro ao atualizar cache do grupo ${groupId}:`, error);
    return 'Desconhecido';
  }
};

const generateActivationCode = async (nazu, durationDays, targetGroupId, lang) => {
  try {
    const rentalData = await loadJsonFile(RENTAL_FILE, { globalMode: false, groups: {}, codes: {} });
    await ensureJsonFileExists(RENTAL_FILE, { globalMode: false, groups: {}, codes: {} });

    const code = Math.random().toString(36).substring(2, 10).toUpperCase();
    rentalData.codes = rentalData.codes || {};
    rentalData.codes[code] = {
      durationDays,
      groupId: targetGroupId || null,
      createdAt: new Date().toISOString(),
      used: false
    };

    let message = lang.plugin_gerarcodigo.success(
      code,
      durationDays === 'permanent' ? lang.plugin_gerarcodigo.permanent : `${durationDays} ${lang.plugin_gerarcodigo.days}`
    );
    if (targetGroupId) {
      const groupName = rentalData.groups[targetGroupId]?.groupName || await updateGroupNameCache(nazu, targetGroupId, rentalData);
      message += lang.plugin_gerarcodigo.target_group(groupName, targetGroupId);
    } else {
      message += lang.plugin_gerarcodigo.no_target_group();
    }

    await fs.writeFile(RENTAL_FILE, JSON.stringify(rentalData, null, 2));
    return { success: true, message };
  } catch (error) {
    console.error('Erro ao gerar código:', error);
    return { success: false, message: lang.plugin_gerarcodigo.error_generate };
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_gerarcodigo: {
        only_owner: () => '🚫 Apenas o Dono principal pode gerar códigos!',
        invalid_usage: (prefix) => `🤔 Uso: ${prefix}gerarcodigo <dias|permanente> [id_do_grupo_opcional]`,
        invalid_duration: () => '🤔 Duração inválida. Use um número de dias (ex: 7) ou a palavra "permanente".',
        invalid_group_id: () => '🤔 ID do grupo alvo inválido. Forneça o ID completo (numero@g.us) ou deixe em branco para um código genérico.',
        success: (code, duration) => `✅ Código gerado: *${code}*\nDuração: ${duration}`,
        target_group: (groupName, groupId) => `\nGrupo alvo: *${groupName}* (${groupId})`,
        no_target_group: () => '\nGrupo alvo: Qualquer grupo',
        error_generate: () => '❌ Erro ao gerar o código de ativação.',
        error: () => '❌ Ocorreu um erro inesperado ao gerar o código.',
        permanent: () => 'Permanente',
        days: () => 'dias'
      }
    };
  }
})();

const commandMap = {
  gerarcodigo: {
    key: 'gerarcodigo',
    action: 'generate_code',
    aliases: ['gerarcode', 'generatecode', 'generarcodigo', 'generercode', 'buatkode']
  }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-19',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query, args) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_gerarcodigo.only_owner() }, { quoted: info });
      }

      if (!query) {
        return nazu.sendMessage(from, { text: lang.plugin_gerarcodigo.invalid_usage(info.prefix) }, { quoted: info });
      }

      const parts = query.trim().split(' ');
      const durationArg = parts[0]?.toLowerCase();
      const targetGroupArg = parts[1];

      let durationDays = null;
      if (durationArg === 'permanente') {
        durationDays = 'permanent';
      } else if (!isNaN(parseInt(durationArg)) && parseInt(durationArg) > 0) {
        durationDays = parseInt(durationArg);
      } else {
        return nazu.sendMessage(from, { text: lang.plugin_gerarcodigo.invalid_duration() }, { quoted: info });
      }

      let targetGroupId = null;
      if (targetGroupArg) {
        if (targetGroupArg.includes('@g.us')) {
          targetGroupId = targetGroupArg;
        } else if (/^\d+$/.test(targetGroupArg)) {
          targetGroupId = targetGroupArg + '@g.us';
        } else {
          const mentionedJid = info.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
          if (mentionedJid && mentionedJid.endsWith('@g.us')) {
            targetGroupId = mentionedJid;
          } else {
            return nazu.sendMessage(from, { text: lang.plugin_gerarcodigo.invalid_group_id() }, { quoted: info });
          }
        }
      }

      const result = await generateActivationCode(nazu, durationDays, targetGroupId, lang);
      return nazu.sendMessage(from, { text: result.message }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_gerarcodigo.error() }, { quoted: info });
    }
  }
};