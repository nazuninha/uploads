const path = require('path');
const fs = require('fs');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_config: {
        only_owner: () => '⚠️ Desculpe, este comando é exclusivo para o meu dono! 😎',
        usage_prefixo: (prefix, command) => `Digite um prefixo maneiro! Exemplo: ${prefix}${command} #`,
        usage_numerodono: (prefix, command) => `Por favor, informe o número do dono! Exemplo: ${prefix}${command} 55123456789`,
        usage_nomedono: (prefix, command) => `Qual é o nome do dono? Exemplo: ${prefix}${command} João`,
        usage_nomebot: (prefix, command) => `Dê um nome incrível para o bot! Exemplo: ${prefix}${command} SuperBot`,
        usage_language: (prefix, command) => `Escolha um idioma! Exemplo: ${prefix}${command} pt (opções: en, pt, es, fr, id)`,
        success_prefixo: (value) => `✨ Prefixo atualizado para *${value}*! Agora é só usar! 🚀`,
        success_numerodono: (value) => `📱 Número do dono atualizado para *${value}*! Tudo certo! ✅`,
        success_nomedono: (value) => `👑 Nome do dono atualizado para *${value}*! Perfeito! 😊`,
        success_nomebot: (value) => `🤖 O bot agora se chama *${value}*! Nome top! 🎉`,
        success_language: (value) => `🌍 Idioma alterado para *${value}*! Tudo pronto para conversar! 🗣️`,
        error: () => '😥 Ops, algo deu errado! Tente novamente, por favor! 💔',
        invalid_prefix: () => '⚠️ O prefixo deve ter entre 1 e 5 caracteres. Tente algo como ! ou #!',
        invalid_phone: () => '⚠️ Número inválido! Use apenas números, entre 10 e 15 dígitos (ex.: 55123456789).',
        invalid_name: () => '⚠️ O nome deve ter entre 1 e 50 caracteres. Vamos caprichar! 😊',
        invalid_language: () => '⚠️ Idioma inválido! Escolha entre: en, pt, es, fr, id.'
      }
    };
  }
})();


const saveConfig = (key, value) => {
  const configPath = path.join(__dirname, '..', '..', 'config.json');
  let config;
  try {
    config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
  } catch (error) {
    config = {
      prefix: '!',
      numerodono: '',
      nomedono: '',
      nomebot: 'Bot',
      language: 'pt'
    };
  }
  config[key] = value;
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
};

const validatePrefix = (query) => {
  if (query.length < 1 || query.length > 5) {
    return { valid: false, error: lang.plugin_config.invalid_prefix() };
  }
  return { valid: true };
};

const validatePhone = (query) => {
  if (!/^\d{10,15}$/.test(query)) {
    return { valid: false, error: lang.plugin_config.invalid_phone() };
  }
  return { valid: true };
};

const validateName = (query) => {
  if (query.length < 1 || query.length > 50) {
    return { valid: false, error: lang.plugin_config.invalid_name() };
  }
  return { valid: true };
};

const validateLanguage = (query) => {
  const validLanguages = ['en', 'pt', 'es', 'fr', 'id'];
  if (!validLanguages.includes(query.toLowerCase())) {
    return { valid: false, error: lang.plugin_config.invalid_language() };
  }
  return { valid: true };
};

const commandMap = {
  prefixo: { key: 'prefix', validate: validatePrefix, aliases: ['prefix', 'prefijo', 'prefixe', 'awalan'] },
  numerodono: { key: 'numerodono', validate: validatePhone, aliases: ['ownerphone', 'telefonoprop', 'telephoneprop', 'nomortuan'] },
  nomedono: { key: 'nomedono', validate: validateName, aliases: ['ownername', 'nombreprop', 'nomprop', 'namatuan'] },
  nomebot: { key: 'nomebot', validate: validateName, aliases: ['botname', 'nombot', 'nombot', 'namabot'] },
  language: { key: 'language', validate: validateLanguage, aliases: ['idioma', 'lenguaje', 'langue', 'bahasa'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-15',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    if (!info.isOwner) {
      return nazu.sendMessage(from, { text: lang.plugin_config.only_owner() }, { quoted: info });
    }

    if (!query) {
      const usageKey = `usage_${config.key}`;
      return nazu.sendMessage(from, { text: lang.plugin_config[usageKey](info.prefix, command) }, { quoted: info });
    }

    try {
      const validation = config.validate(query);
      if (!validation.valid) {
        return nazu.sendMessage(from, { text: validation.error }, { quoted: info });
      }

      saveConfig(config.key, query);
      const successKey = `success_${config.key}`;
      return nazu.sendMessage(from, { text: lang.plugin_config[successKey](query) }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_config.error() }, { quoted: info });
    }
  }
};