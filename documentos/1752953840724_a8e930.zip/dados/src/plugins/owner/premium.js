const path = require('path');
const fs = require('fs');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database', 'dono');
const PREMIUM_FILE = path.join(DATABASE_DIR, 'premium.json');

const ensureJsonFileExists = (file, defaultData) => {
  if (!fs.existsSync(file)) {
    ensureDirectoryExists(DATABASE_DIR);
    fs.writeFileSync(file, JSON.stringify(defaultData, null, 2));
  }
};

const ensureDirectoryExists = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

const loadJsonFile = (file, defaultData) => {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_premium_manager: {
        only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
        no_user: () => '🤔 Marque alguém ou forneça o ID do usuário! 🙄',
        only_group: () => '❌ Este comando só pode ser usado em grupos! 💔',
        user_already_premium: (user) => `❌ O usuário @${user} já está na lista premium!`,
        user_not_premium: (user) => `❌ O usuário @${user} não está na lista premium!`,
        group_already_premium: () => '❌ O grupo já está na lista premium!',
        group_not_premium: () => '❌ O grupo não está na lista premium!',
        user_added: (user) => `✅ Usuário @${user} foi adicionado(a) à lista premium!`,
        user_removed: (user) => `🫡 Usuário @${user} foi removido(a) da lista premium!`,
        group_added: () => '✅ O grupo foi adicionado à lista premium!',
        group_removed: () => '🫡 O grupo foi removido da lista premium!',
        premium_list: (nomebot, usersPremiumText, groupsPremiumText, usersCount, groupsCount) => 
          `✨ *Lista de Membros Premium - ${nomebot}* ✨\n\n👤 *Usuários Premium* (${usersCount})\n${usersPremiumText}\n\n👥 *Grupos Premium* (${groupsCount})\n${groupsPremiumText}`,
        no_premium_users: () => 'Nenhum usuário premium encontrado.',
        no_premium_groups: () => 'Nenhum grupo premium encontrado.',
        group_info_error: (groupId) => `Grupo ID: ${groupId} (não foi possível obter o nome)`,
        error: () => '😔 Ops, algo deu errado. Tente novamente mais tarde! 💔'
      }
    };
  }
})();

const commandMap = {
  addpremium: { key: 'addpremium', action: 'add_user', aliases: ['addvip', 'adicionarpremium', 'agregarpremium', 'ajouterpremium', 'tambahpremium'] },
  delpremium: { key: 'delpremium', action: 'remove_user', aliases: ['delvip', 'rmpremium', 'rmvip', 'removerpremium', 'eliminarpremium', 'supprimerpremium', 'hapuspremium'] },
  addpremiumgp: { key: 'addpremiumgp', action: 'add_group', aliases: ['addvipgp', 'adicionarpremiumgp', 'agregarpremiumgp', 'ajouterpremiumgp', 'tambahpremiumgp'] },
  delpremiumgp: { key: 'delpremiumgp', action: 'remove_group', aliases: ['delvipgp', 'rmpremiumgp', 'rmvipgp', 'removerpremiumgp', 'eliminarpremiumgp', 'supprimerpremiumgp', 'hapuspremiumgp'] },
  listapremium: { key: 'listapremium', action: 'list_premium', aliases: ['listavip', 'premiumlist', 'listpremium', 'listapremium', 'listapremiumgp', 'listabloqueos', 'listepremium', 'daftarpremium'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-17',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_premium_manager.only_owner() }, { quoted: info });
      }

      const premiumFile = PREMIUM_FILE;
      let premiumListaZinha = loadJsonFile(premiumFile, {});
      ensureJsonFileExists(premiumFile, {});

      if (config.action === 'add_user') {
        const userToAdd = info.menc_jid2 && info.menc_jid2.length > 0 ? info.menc_jid2[0] : null;
        if (!userToAdd) {
          return nazu.sendMessage(from, { text: lang.plugin_premium_manager.no_user() }, { quoted: info });
        }
        const userId = userToAdd.includes('@') ? userToAdd : userToAdd + '@s.whatsapp.net';
        if (premiumListaZinha[userId]) {
          return nazu.sendMessage(from, { text: lang.plugin_premium_manager.user_already_premium(userId.split('@')[0]), mentions: [userId] }, { quoted: info });
        }
        premiumListaZinha[userId] = true;
        fs.writeFileSync(premiumFile, JSON.stringify(premiumListaZinha, null, 2));
        return nazu.sendMessage(from, { text: lang.plugin_premium_manager.user_added(userId.split('@')[0]), mentions: [userId] }, { quoted: info });
      }

      if (config.action === 'remove_user') {
        const userToRemove = info.menc_jid2 && info.menc_jid2.length > 0 ? info.menc_jid2[0] : null;
        if (!userToRemove) {
          return nazu.sendMessage(from, { text: lang.plugin_premium_manager.no_user() }, { quoted: info });
        }
        const userId = userToRemove.includes('@') ? userToRemove : userToRemove + '@s.whatsapp.net';
        if (!premiumListaZinha[userId]) {
          return nazu.sendMessage(from, { text: lang.plugin_premium_manager.user_not_premium(userId.split('@')[0]), mentions: [userId] }, { quoted: info });
        }
        delete premiumListaZinha[userId];
        fs.writeFileSync(premiumFile, JSON.stringify(premiumListaZinha, null, 2));
        return nazu.sendMessage(from, { text: lang.plugin_premium_manager.user_removed(userId.split('@')[0]), mentions: [userId] }, { quoted: info });
      }

      if (config.action === 'add_group') {
        if (!info.isGroup) {
          return nazu.sendMessage(from, { text: lang.plugin_premium_manager.only_group() }, { quoted: info });
        }
        if (premiumListaZinha[from]) {
          return nazu.sendMessage(from, { text: lang.plugin_premium_manager.group_already_premium() }, { quoted: info });
        }
        premiumListaZinha[from] = true;
        fs.writeFileSync(premiumFile, JSON.stringify(premiumListaZinha, null, 2));
        return nazu.sendMessage(from, { text: lang.plugin_premium_manager.group_added() }, { quoted: info });
      }

      if (config.action === 'remove_group') {
        if (!info.isGroup) {
          return nazu.sendMessage(from, { text: lang.plugin_premium_manager.only_group() }, { quoted: info });
        }
        if (!premiumListaZinha[from]) {
          return nazu.sendMessage(from, { text: lang.plugin_premium_manager.group_not_premium() }, { quoted: info });
        }
        delete premiumListaZinha[from];
        fs.writeFileSync(premiumFile, JSON.stringify(premiumListaZinha, null, 2));
        return nazu.sendMessage(from, { text: lang.plugin_premium_manager.group_removed() }, { quoted: info });
      }

      if (config.action === 'list_premium') {
        const premiumList = premiumListaZinha || {};
        const usersPremium = Object.keys(premiumList).filter(id => id.includes('@s.whatsapp.net'));
        const groupsPremium = Object.keys(premiumList).filter(id => id.includes('@g.us'));

        let usersPremiumText = usersPremium.length > 0
          ? usersPremium.map((user, i) => `🔹 ${i + 1}. @${user.split('@')[0]}`).join('\n')
          : lang.plugin_premium_manager.no_premium_users();

        let groupsPremiumText = '';
        if (groupsPremium.length > 0) {
          for (let i = 0; i < groupsPremium.length; i++) {
            try {
              const groupInfo = await nazu.groupMetadata(groupsPremium[i]);
              groupsPremiumText += `🔹 ${i + 1}. ${groupInfo.subject}\n`;
            } catch {
              groupsPremiumText += `🔹 ${i + 1}. ${lang.plugin_premium_manager.group_info_error(groupsPremium[i])}\n`;
            }
          }
        } else {
          groupsPremiumText = lang.plugin_premium_manager.no_premium_groups();
        }

        const message = lang.plugin_premium_manager.premium_list(
          info.nomebot,
          usersPremiumText,
          groupsPremiumText,
          usersPremium.length,
          groupsPremium.length
        );
        return nazu.sendMessage(from, { text: message, mentions: usersPremium }, { quoted: info });
      }
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_premium_manager.error() }, { quoted: info });
    }
  }
};