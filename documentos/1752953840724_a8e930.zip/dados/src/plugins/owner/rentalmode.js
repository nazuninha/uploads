const path = require('path');
const fs = require('fs').promises;
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const BOT_STATE_FILE = path.join(DATABASE_DIR, 'botState.json');

const ensureJsonFileExists = async (file, defaultData) => {
  try {
    if (!(await fs.access(file).then(() => true).catch(() => false))) {
      await fs.mkdir(DATABASE_DIR, { recursive: true });
      await fs.writeFile(file, JSON.stringify(defaultData, null, 2));
    }
  } catch (error) {
    console.error(`Erro ao garantir existência do arquivo ${file}:`, error);
  }
};

const loadJsonFile = async (file, defaultData) => {
  try {
    const data = await fs.readFile(file, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

const setRentalMode = async (state) => {
  try {
    const botStateFile = BOT_STATE_FILE;
    let botState = await loadJsonFile(botStateFile, { status: 'on', viewMessages: true, rentalMode: false });
    botState.rentalMode = state;
    await fs.writeFile(botStateFile, JSON.stringify(botState, null, 2));
    return true;
  } catch (error) {
    console.error('Erro ao definir modo de aluguel:', error);
    return false;
  }
};

const isRentalModeActive = async () => {
  try {
    const botStateFile = BOT_STATE_FILE;
    const botState = await loadJsonFile(botStateFile, { status: 'on', viewMessages: true, rentalMode: false });
    return botState.rentalMode === true;
  } catch (error) {
    console.error('Erro ao verificar modo de aluguel:', error);
    return false;
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_modoaluguel: {
        only_main_owner: () => '🚫 Apenas o Dono principal pode gerenciar o modo de aluguel!',
        invalid_usage: (prefix, status) => `🤔 Uso: ${prefix}modoaluguel on|off\nStatus atual: ${status}`,
        rental_mode_on: () => '✅ Modo de aluguel global ATIVADO! O bot agora só responderá em grupos com aluguel ativo.',
        rental_mode_off: () => '✅ Modo de aluguel global DESATIVADO! O bot responderá em todos os grupos permitidos.',
        error_set_mode: () => '❌ Erro ao alterar o modo de aluguel global.',
        error: () => '❌ Ocorreu um erro inesperado.'
      }
    };
  }
})();

const commandMap = {
  modoaluguel: {
    key: 'modoaluguel',
    action: 'toggle_rental_mode',
    aliases: ['rentalmode', 'modolocacao', 'modoalquiler', 'modelocation', 'sewabot']
  }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-19',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner || (info.isOwner && info.isSubOwner)) {
        return nazu.sendMessage(from, { text: lang.plugin_modoaluguel.only_main_owner() }, { quoted: info });
      }

      await ensureJsonFileExists(BOT_STATE_FILE, { status: 'on', viewMessages: true, rentalMode: false });

      const action = query.toLowerCase().trim();
      if (action === 'on' || action === 'ativar') {
        if (await setRentalMode(true)) {
          return nazu.sendMessage(from, { text: lang.plugin_modoaluguel.rental_mode_on() }, { quoted: info });
        } else {
          return nazu.sendMessage(from, { text: lang.plugin_modoaluguel.error_set_mode() }, { quoted: info });
        }
      } else if (action === 'off' || action === 'desativar') {
        if (await setRentalMode(false)) {
          return nazu.sendMessage(from, { text: lang.plugin_modoaluguel.rental_mode_off() }, { quoted: info });
        } else {
          return nazu.sendMessage(from, { text: lang.plugin_modoaluguel.error_set_mode() }, { quoted: info });
        }
      } else {
        const currentStatus = (await isRentalModeActive()) ? 'ATIVADO' : 'DESATIVADO';
        return nazu.sendMessage(from, { text: lang.plugin_modoaluguel.invalid_usage(info.prefix, currentStatus) }, { quoted: info });
      }
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_modoaluguel.error() }, { quoted: info });
    }
  }
};