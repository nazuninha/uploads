const path = require('path');
const fs = require('fs').promises;
const os = require('os');
const https = require('https');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const formatUptime = (seconds, detailed = false) => {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  if (detailed) {
    return `${days}d ${hours}h ${minutes}m ${secs}s`;
  }
  return `${hours}h ${minutes}m ${secs}s`;
};

const getDiskSpaceInfo = async () => {
  try {
    const rootPath = path.parse(process.cwd()).root;
    const stats = await fs.statfs(rootPath).catch(() => null);
    if (!stats) throw new Error('Não foi possível obter estatísticas do disco');
    
    const blockSize = stats.bsize || 4096;
    const totalBytes = stats.blocks * blockSize;
    const freeBytes = stats.bfree * blockSize;
    const usedBytes = totalBytes - freeBytes;
    
    return {
      totalGb: (totalBytes / 1024 / 1024 / 1024).toFixed(2),
      freeGb: (freeBytes / 1024 / 1024 / 1024).toFixed(2),
      usedGb: (usedBytes / 1024 / 1024 / 1024).toFixed(2),
      percentUsed: ((usedBytes / totalBytes) * 100).toFixed(1)
    };
  } catch (error) {
    console.error('Erro ao obter informações de disco:', error);
    return { totalGb: 'N/A', freeGb: 'N/A', usedGb: 'N/A', percentUsed: 'N/A' };
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_infoserver: {
        only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
        server_info: (nomebot, data) => `🌸 ═════════════════════ 🌸\n    *INFORMAÇÕES DO SERVIDOR - ${nomebot}*\n🌸 ═════════════════════ 🌸\n\n` +
          `🖥️ *Sistema Operacional:* 🏠\n` +
          `├ 🟢 Node.js: ${data.nodeVersion}\n` +
          `├ 💻 Plataforma: ${data.platform}\n` +
          `├ 🏗️ Arquitetura: ${data.arch}\n` +
          `├ 🔧 Tipo: ${data.type}\n` +
          `├ 📋 Release: ${data.release}\n` +
          `├ 🏷️ Hostname: ${data.hostname}\n` +
          `├ 🔄 Endianness: ${data.endianness}\n` +
          `├ ⏳ Sistema online há: ${data.osUptime} horas\n` +
          `└ 📅 Hora atual: ${data.currentTime}\n\n` +
          `⚡ *Processador (CPU):* 🧠\n` +
          `├ 🔢 Núcleos: ${data.cpuCount}\n` +
          `├ 🏷️ Modelo: ${data.cpuModel}\n` +
          `├ 👤 Tempo usuário: ${data.cpuUser}s\n` +
          `├ ⚙️ Tempo sistema: ${data.cpuSystem}s\n` +
          `├ 📈 Uso CPU atual: ${data.cpuPercent}%\n` +
          `├ 📊 Load 1min: ${data.loadAvg[0].toFixed(2)}\n` +
          `├ 📈 Load 5min: ${data.loadAvg[1].toFixed(2)}\n` +
          `└ 📉 Load 15min: ${data.loadAvg[2].toFixed(2)}\n\n` +
          `💾 *Memória do Sistema:* 🧠\n` +
          `├ 🆓 RAM Livre: ${data.freeMemory} GB\n` +
          `├ 📊 RAM Total: ${data.totalMemory} GB\n` +
          `├ 📈 RAM Usada: ${data.usedMemory} GB\n` +
          `└ ${data.memoryEmoji} Uso: [${data.memoryBar}] ${data.memoryUsagePercent}%\n\n` +
          `🤖 *Memória do Bot:* 💖\n` +
          `├ 🧠 Heap Usado: ${data.botMemUsed} MB\n` +
          `├ 📦 Heap Total: ${data.botMemTotal} MB\n` +
          `├ 🏠 RSS: ${data.botMemRss} MB\n` +
          `├ 🔗 Externo: ${data.botMemExternal} MB\n` +
          `└ ${data.botMemoryEmoji} Eficiência: [${data.botMemoryBar}] ${data.botMemoryUsagePercent}%\n\n` +
          `🌐 *Rede e Conectividade:* 🔗\n` +
          `├ 🔌 Interfaces: ${data.networkInterfaces}\n` +
          `${data.networkDetails}` +
          `├ 📡 Status: ${data.networkStatus}\n` +
          `├ ⏱️ Latência de Rede: ${data.networkLatency}\n` +
          `└ 🛡️ Firewall: ${data.firewallStatus}\n\n` +
          `💽 *Armazenamento:* 💿\n` +
          `├ 🆓 Livre: ${data.diskFree} GB\n` +
          `├ 📊 Total: ${data.diskTotal} GB\n` +
          `├ 📈 Usado: ${data.diskUsed} GB\n` +
          `└ ${data.diskEmoji} Uso: [${data.diskBar}] ${data.diskUsagePercent}%\n\n` +
          `⏰ *Tempo e Latência:* 🕐\n` +
          `├ ⏱️ Latência do Bot: ${data.latency}ms\n` +
          `└ 🚀 Bot online há: ${data.botUptime}`,
        error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
      }
    };
  }
})();

const commandMap = {
  infoserver: { key: 'infoserver', action: 'get_server_info', aliases: ['serverinfo', 'infservidor', 'infoservidor', 'infserveur', 'infoserverid'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-17',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_infoserver.only_owner() }, { quoted: info });
      }

      const serverUptime = process.uptime();
      const botUptime = formatUptime(serverUptime, true);

      const serverMemUsage = process.memoryUsage();
      const botMemUsed = (serverMemUsage.heapUsed / 1024 / 1024).toFixed(2);
      const botMemTotal = (serverMemUsage.heapTotal / 1024 / 1024).toFixed(2);
      const botMemRss = (serverMemUsage.rss / 1024 / 1024).toFixed(2);
      const botMemExternal = (serverMemUsage.external / 1024 / 1024).toFixed(2);
      const botMemoryUsagePercent = ((botMemUsed / botMemTotal) * 100).toFixed(1);
      const botMemoryEmoji = botMemoryUsagePercent > 80 ? '⚠️' : '✅';
      const botMemoryBar = '█'.repeat(botMemoryUsagePercent / 10) + '-'.repeat(10 - botMemoryUsagePercent / 10);

      const serverCpuUsage = process.cpuUsage();
      const cpuUser = (serverCpuUsage.user / 1000000).toFixed(2);
      const cpuSystem = (serverCpuUsage.system / 1000000).toFixed(2);

      const serverOsInfo = {
        platform: os.platform() || 'N/A',
        arch: os.arch() || 'N/A',
        release: os.release() || 'N/A',
        hostname: os.hostname() || 'N/A',
        type: os.type() || 'N/A',
        endianness: os.endianness() || 'N/A'
      };

      const freeMemory = (os.freemem() / 1024 / 1024 / 1024).toFixed(2) || 'N/A';
      const totalMemory = (os.totalmem() / 1024 / 1024 / 1024).toFixed(2) || 'N/A';
      const usedMemory = (totalMemory - freeMemory).toFixed(2) || 'N/A';
      const memoryUsagePercent = totalMemory !== 'N/A' ? (((totalMemory - freeMemory) / totalMemory) * 100).toFixed(1) : 'N/A';
      const memoryEmoji = memoryUsagePercent !== 'N/A' && memoryUsagePercent > 80 ? '⚠️' : '✅';
      const memoryBar = memoryUsagePercent !== 'N/A' ? '█'.repeat(memoryUsagePercent / 10) + '-'.repeat(10 - memoryUsagePercent / 10) : 'N/A';

      const loadAvg = os.loadavg() || [0, 0, 0];
      const cpuCount = os.cpus().length || 'N/A';
      const cpuModel = os.cpus()[0]?.model || 'Desconhecido';
      const osUptime = (os.uptime() / 3600).toFixed(2) || 'N/A';

      const networkInterfaces = os.networkInterfaces() || {};
      const networkInterfacesCount = Object.keys(networkInterfaces).length;
      let networkDetails = '';
      for (const [name, interfaces] of Object.entries(networkInterfaces)) {
        interfaces.forEach(iface => {
          networkDetails += `├ ${name} (${iface.family}): ${iface.address}\n`;
        });
      }
      if (!networkDetails) networkDetails = '├ Nenhuma interface de rede encontrada.\n';

      const currentTime = new Date().toLocaleString('pt-BR', {
        timeZone: 'America/Sao_Paulo',
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      });

      const startUsage = process.cpuUsage();
      await new Promise(resolve => setTimeout(resolve, 1000));
      const endUsage = process.cpuUsage(startUsage);
      const cpuPercent = ((endUsage.user + endUsage.system) / 10000).toFixed(1) || 'N/A';

      const startTime = Date.now();
      const endTime = Date.now();
      const latency = endTime - startTime;

      let networkLatency = 'N/A';
      try {
        const startNetworkTest = Date.now();
        await new Promise((resolve, reject) => {
          const req = https.get('https://www.google.com', { timeout: 5000 }, res => {
            res.on('data', () => {});
            res.on('end', () => resolve());
          });
          req.on('error', err => reject(err));
          req.setTimeout(5000, () => reject(new Error('Timeout')));
        });
        const endNetworkTest = Date.now();
        networkLatency = `${endNetworkTest - startNetworkTest}ms`;
      } catch (error) {
        networkLatency = 'Erro ao testar';
        console.error('Erro ao testar latência de rede:', error);
      }

      const diskInfo = await getDiskSpaceInfo();
      const diskEmoji = diskInfo.percentUsed !== 'N/A' && diskInfo.percentUsed > 80 ? '⚠️' : '✅';
      const diskBar = diskInfo.percentUsed !== 'N/A' ? '█'.repeat(diskInfo.percentUsed / 10) + '-'.repeat(10 - diskInfo.percentUsed / 10) : 'N/A';

      const data = {
        nomebot: info.nomebot,
        nodeVersion: process.version || 'N/A',
        platform: serverOsInfo.platform,
        arch: serverOsInfo.arch,
        release: serverOsInfo.release,
        hostname: serverOsInfo.hostname,
        type: serverOsInfo.type,
        endianness: serverOsInfo.endianness,
        osUptime,
        currentTime,
        cpuCount,
        cpuModel,
        cpuUser,
        cpuSystem,
        cpuPercent,
        loadAvg,
        freeMemory,
        totalMemory,
        usedMemory,
        memoryEmoji,
        memoryBar,
        memoryUsagePercent,
        botMemUsed,
        botMemTotal,
        botMemRss,
        botMemExternal,
        botMemoryEmoji,
        botMemoryBar,
        botMemoryUsagePercent,
        networkInterfaces: networkInterfacesCount,
        networkDetails,
        networkStatus: networkLatency !== 'Erro ao testar' ? 'Online' : 'Offline',
        networkLatency,
        firewallStatus: 'Ativo', // Placeholder, pode ser ajustado
        diskFree: diskInfo.freeGb,
        diskTotal: diskInfo.totalGb,
        diskUsed: diskInfo.usedGb,
        diskEmoji,
        diskBar,
        diskUsagePercent: diskInfo.percentUsed,
        latency,
        botUptime
      };

      const message = lang.plugin_infoserver.server_info(info.nomebot, data);
      return nazu.sendMessage(from, { text: message }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_infoserver.error() }, { quoted: info });
    }
  }
};