const path = require('path');
const fs = require('fs').promises;
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const getAllJsFiles = async (dir) => {
  let results = [];
  try {
    const files = await fs.readdir(dir, { withFileTypes: true });
    for (const file of files) {
      const fullPath = path.join(dir, file.name);
      if (file.isDirectory()) {
        results = results.concat(await getAllJsFiles(fullPath));
      } else if (file.isFile() && file.name.endsWith('.js')) {
        results.push(fullPath);
      }
    }
  } catch (error) {
    console.error(`Erro ao ler diretório ${dir}:`, error);
  }
  return results;
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_getplugin: {
        only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
        no_command: (prefix) => `❌ Digite o nome do comando. Exemplo: ${prefix}getplugin menu`,
        command_not_found: (cmd) => `❌ O comando *${cmd}* não foi encontrado em nenhum plugin!`,
        error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
      }
    };
  }
})();

const commandMap = {
  getplugin: { key: 'getplugin', action: 'get_plugin_case', aliases: ['getcase', 'obtercomando', 'obtenercomando', 'obtenircommande', 'dapatkanperintah'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-17',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_getplugin.only_owner() }, { quoted: info });
      }

      if (!query) {
        return nazu.sendMessage(from, { text: lang.plugin_getplugin.no_command(info.prefix) }, { quoted: info });
      }

      const cmdToFind = query.toLowerCase().split(' ')[0];

      const baseDir = path.join(__dirname, '..');
      const jsFiles = await getAllJsFiles(baseDir);

      let found = false;
      let caseCode = '';

      for (const file of jsFiles) {
        try {
          const plugin = require(file);
          const commands = plugin.commands || [];
          
          if (commands.includes(cmdToFind)) {
            const fileContent = await fs.readFile(file, 'utf-8');
            const match = fileContent;
            
            if (match) {
              caseCode = `${match}`;
              found = true;
              break;
            }
          }
        } catch (error) {
          console.error(`Erro ao processar arquivo ${file}:`, error);
          continue;
        }
      }

      if (!found) {
        return nazu.sendMessage(from, { text: lang.plugin_getplugin.command_not_found(cmdToFind) }, { quoted: info });
      }

      return nazu.sendMessage(from, {
        document: Buffer.from(caseCode, 'utf-8'),
        mimetype: 'text/plain',
        fileName: `${cmdToFind}.txt`
      }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_getplugin.error() }, { quoted: info });
    }
  }
};