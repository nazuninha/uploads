const path = require('path');
const fs = require('fs');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_menu_media: {
        only_owner: () => '⚠️ Desculpe, este comando é exclusivo para o meu dono! 😎',
        only_group: () => '🚫 Este comando só funciona em grupos! Tente em um grupo, por favor! 🗣️',
        no_media: (prefix, command) => `📸 Marque uma imagem ou vídeo com o comando: ${prefix}${command} (mencionando a mídia)`,
        success: () => `✅ Mídia do menu atualizada com sucesso! Pronta para brilhar! ✨`,
        error: () => `😥 Ops, algo deu errado ao atualizar a mídia! Tente novamente, por favor! 💔`
      }
    };
  }
})();

const commandMap = {
  fotomenu: { key: 'fotomenu', aliases: ['menuphoto', 'fotomenu', 'photommenu', 'fotomenu'] },
  videomenu: { key: 'videomenu', aliases: ['menuvideo', 'videomenu', 'videomenu', 'videomenu'] },
  mediamenu: { key: 'mediamenu', aliases: ['menumedia', 'mediamenu', 'mediamenu', 'mediamenu'] },
  midiamenu: { key: 'midiamenu', aliases: ['menumedia', 'midiamenu', 'midiamenu', 'midiamenu'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-15',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query) => {
    if (info.isGroup === false) {
      return nazu.sendMessage(from, { text: lang.plugin_menu_media.only_group() }, { quoted: info });
    }

    if (!info.isOwner) {
      return nazu.sendMessage(from, { text: lang.plugin_menu_media.only_owner() }, { quoted: info });
    }

    try {
      const RSM = info.message?.extendedTextMessage?.contextInfo?.quotedMessage;
      const image = RSM?.imageMessage || info.message?.imageMessage || RSM?.viewOnceMessageV2?.message?.imageMessage || info.message?.viewOnceMessageV2?.message?.imageMessage || info.message?.viewOnceMessage?.message?.imageMessage || RSM?.viewOnceMessage?.message?.imageMessage;
      const video = RSM?.videoMessage || info.message?.videoMessage || RSM?.viewOnceMessageV2?.message?.videoMessage || info.message?.viewOnceMessageV2?.message?.videoMessage || info.message?.viewOnceMessage?.message?.videoMessage || RSM?.viewOnceMessage?.message?.videoMessage;

      if (!image && !video) {
        return nazu.sendMessage(from, { text: lang.plugin_menu_media.no_media(info.prefix, command) }, { quoted: info });
      }

      const isVideo = !!video;
      const media = isVideo ? video : image;

      const mediaPath = path.join(__dirname, '..', '..', '..', 'midias');
      if (fs.existsSync(path.join(mediaPath, 'menu.jpg'))) fs.unlinkSync(path.join(mediaPath, 'menu.jpg'));
      if (fs.existsSync(path.join(mediaPath, 'menu.mp4'))) fs.unlinkSync(path.join(mediaPath, 'menu.mp4'));

      const buffer = await nazu.getFileBuffer(media, isVideo ? 'video' : 'image');
      fs.writeFileSync(path.join(mediaPath, `menu.${isVideo ? 'mp4' : 'jpg'}`), buffer);

      return nazu.sendMessage(from, { text: lang.plugin_menu_media.success() }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_menu_media.error() }, { quoted: info });
    }
  }
};