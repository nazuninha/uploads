const path = require('path');
const fs = require('fs');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_subowner_manager: {
        only_main_owner: () => '🚫 Apenas o Dono principal pode usar este comando! 😎',
        no_target: (prefix, command) => `🤔 Você precisa marcar o usuário ou fornecer o número completo (ex: ${prefix}${command} 5511999998888 ou @usuário)`,
        invalid_jid: () => '❌ ID de usuário inválido. Use o formato completo (ex: 1234567890@s.whatsapp.net) ou marque o usuário.',
        already_subowner: () => '🌟 Este usuário já é um subdono! Não precisa adicionar de novo. 😊',
        owner_cannot_be_subowner: () => '🤔 O Dono principal já tem todos os superpoderes! Não dá pra adicionar como subdono. 😉',
        save_error: () => '😥 Oops! Tive um probleminha para salvar a lista de subdonos. Tente novamente, por favor!',
        not_subowner: () => '🤔 Este usuário não está na lista de subdonos.',
        unexpected_error: () => '❌ Erro inesperado ao processar a lista de subdonos. 🤷',
        no_subowners: () => '✨ Nenhum subdono cadastrado no momento.',
        success_add: (user) => `✅ @${user} foi adicionado(a) como subdono! 🎉`,
        success_remove: (user) => `🫡 @${user} foi removido(a) dos subdonos.`,
        list_subowners: (list, mentions) => `👑 *Lista de Subdonos Atuais:*\n\n${list}`,
        error: () => '❌ Ops, algo deu errado! Tente novamente, por favor! 💔'
      }
    };
  }
})();

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const DONO_DIR = path.join(DATABASE_DIR, 'dono');
const SUBDONOS_FILE = path.join(DONO_DIR, 'subdonos.json');

const ensureJsonFileExists = (file, defaultData) => {
  if (!fs.existsSync(file)) {
    ensureDirectoryExists(DONO_DIR);
    fs.writeFileSync(file, JSON.stringify(defaultData, null, 2));
  }
};

const ensureDirectoryExists = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

const loadJsonFile = (file, defaultData) => {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

const loadSubdonos = () => {
  return loadJsonFile(SUBDONOS_FILE, { subdonos: [] }).subdonos || [];
};

const saveSubdonos = (subdonoList) => {
  try {
    ensureDirectoryExists(DONO_DIR);
    fs.writeFileSync(SUBDONOS_FILE, JSON.stringify({ subdonos: subdonoList }, null, 2));
    return true;
  } catch (error) {
    console.error('❌ Erro ao salvar subdonos:', error);
    return false;
  }
};

const isSubdono = (userId) => {
  const currentSubdonos = loadSubdonos();
  return currentSubdonos.includes(userId);
};

const addSubdono = (userId, numerodono) => {
  if (!userId || typeof userId !== 'string' || !userId.includes('@s.whatsapp.net')) {
    return { success: false, message: lang.plugin_subowner_manager.invalid_jid() };
  }
  let currentSubdonos = loadSubdonos();
  if (currentSubdonos.includes(userId)) {
    return { success: false, message: lang.plugin_subowner_manager.already_subowner() };
  }
  const nmrdn_check = numerodono.replace(/[^\d]/g, '') + '@s.whatsapp.net';
  if (userId === nmrdn_check) {
    return { success: false, message: lang.plugin_subowner_manager.owner_cannot_be_subowner() };
  }
  currentSubdonos.push(userId);
  if (saveSubdonos(currentSubdonos)) {
    return { success: true, message: lang.plugin_subowner_manager.success_add(userId.split('@')[0]) };
  } else {
    return { success: false, message: lang.plugin_subowner_manager.save_error() };
  }
};

const removeSubdono = (userId) => {
  if (!userId || typeof userId !== 'string' || !userId.includes('@s.whatsapp.net')) {
    return { success: false, message: lang.plugin_subowner_manager.invalid_jid() };
  }
  let currentSubdonos = loadSubdonos();
  if (!currentSubdonos.includes(userId)) {
    return { success: false, message: lang.plugin_subowner_manager.not_subowner() };
  }
  const initialLength = currentSubdonos.length;
  currentSubdonos = currentSubdonos.filter(id => id !== userId);
  if (currentSubdonos.length === initialLength) {
    return { success: false, message: lang.plugin_subowner_manager.unexpected_error() };
  }
  if (saveSubdonos(currentSubdonos)) {
    return { success: true, message: lang.plugin_subowner_manager.success_remove(userId.split('@')[0]) };
  } else {
    return { success: false, message: lang.plugin_subowner_manager.save_error() };
  }
};

const getSubdonos = () => {
  return [...loadSubdonos()];
};

const commandMap = {
  addsubdono: { key: 'addsubdono', action: 'add', aliases: ['addsubowner', 'agregarsubdono', 'ajoutersubowner', 'tambahsubdono'] },
  remsubdono: { key: 'remsubdono', action: 'remove', aliases: ['rmsubdono', 'removesubowner', 'eliminarsubdono', 'supprimersubowner', 'hapussubdono'] },
  listasubdonos: { key: 'listasubdonos', action: 'list', aliases: ['listsubdonos', 'listsubowners', 'listasubdonos', 'listesubowners', 'daftarsubdono'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-15',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwnerOrSub: true },
  only: 'all', 
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (['add', 'remove'].includes(config.action) && (!info.isOwner || (info.isOwner && info.isSubOwner))) {
        return nazu.sendMessage(from, { text: lang.plugin_subowner_manager.only_main_owner() }, { quoted: info });
      }

      if (config.action === 'list') {
        const subdonos = getSubdonos();
        if (subdonos.length === 0) {
          return nazu.sendMessage(from, { text: lang.plugin_subowner_manager.no_subowners() }, { quoted: info });
        }

        let participantsInfo = {};
        if (info.isGroup && info.groupMetadata?.participants) {
          info.groupMetadata.participants.forEach(p => {
            participantsInfo[p.id] = p.pushname || p.id.split('@')[0];
          });
        }

        const mentions = [];
        const lista = subdonos.map((jid, index) => {
          const nameOrNumber = participantsInfo[jid] || jid.split('@')[0];
          mentions.push(jid);
          return `${index + 1}. @${jid.split('@')[0]} (${nameOrNumber})`;
        }).join('\n');

        return nazu.sendMessage(from, {
          text: lang.plugin_subowner_manager.list_subowners(lista, mentions),
          mentions
        }, { quoted: info });
      }

      const targetUserJid = info.menc_jid2 && info.menc_jid2.length > 0 ? info.menc_jid2[0] : (query.includes('@') ? query.split(' ')[0].replace('@', '') + '@s.whatsapp.net' : null);
      if (!targetUserJid) {
        return nazu.sendMessage(from, { text: lang.plugin_subowner_manager.no_target(info.prefix, command) }, { quoted: info });
      }
      const normalizedJid = targetUserJid.includes('@') ? targetUserJid : targetUserJid.replace(/\D/g, '') + '@s.whatsapp.net';

      if (config.action === 'add') {
        const result = addSubdono(normalizedJid, info.numerodono);
        return nazu.sendMessage(from, {
          text: result.message,
          mentions: result.success ? [normalizedJid] : []
        }, { quoted: info });
      } else {
        const result = removeSubdono(normalizedJid);
        return nazu.sendMessage(from, {
          text: result.message,
          mentions: result.success ? [normalizedJid] : []
        }, { quoted: info });
      }
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_subowner_manager.error() }, { quoted: info });
    }
  }
};