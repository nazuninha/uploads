const path = require('path');
const fs = require('fs').promises;
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const RENTAL_FILE = path.join(DATABASE_DIR, 'rentalData.json');

const ensureJsonFileExists = async (file, defaultData) => {
  try {
    if (!(await fs.access(file).then(() => true).catch(() => false))) {
      await fs.mkdir(DATABASE_DIR, { recursive: true });
      await fs.writeFile(file, JSON.stringify(defaultData, null, 2));
    }
  } catch (error) {
    console.error(`Erro ao garantir existência do arquivo ${file}:`, error);
  }
};

const loadJsonFile = async (file, defaultData) => {
  try {
    const data = await fs.readFile(file, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

const updateGroupNameCache = async (nazu, groupId, rentalData) => {
  try {
    const groupMetadata = await nazu.groupMetadata(groupId);
    rentalData.groups[groupId] = rentalData.groups[groupId] || {};
    rentalData.groups[groupId].groupName = groupMetadata.subject || 'Sem Nome';
    await fs.writeFile(RENTAL_FILE, JSON.stringify(rentalData, null, 2));
    return rentalData.groups[groupId].groupName;
  } catch (error) {
    console.error(`Erro ao atualizar cache do grupo ${groupId}:`, error);
    return 'Desconhecido';
  }
};

const setGroupRental = async (nazu, groupId, durationDays, lang) => {
  try {
    const rentalData = await loadJsonFile(RENTAL_FILE, { globalMode: false, groups: {} });
    await ensureJsonFileExists(RENTAL_FILE, { globalMode: false, groups: {} });

    const expiresAt = durationDays === 'permanent'
      ? 'permanent'
      : new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString();

    rentalData.groups[groupId] = {
      expiresAt,
      groupName: rentalData.groups[groupId]?.groupName || await updateGroupNameCache(nazu, groupId, rentalData)
    };

    await fs.writeFile(RENTAL_FILE, JSON.stringify(rentalData, null, 2));
    const groupName = rentalData.groups[groupId].groupName;
    return {
      success: true,
      message: lang.plugin_addaluguel.success(groupName, durationDays === 'permanent' ? lang.plugin_addaluguel.permanent : `${durationDays} ${lang.plugin_addaluguel.days}`)
    };
  } catch (error) {
    console.error('Erro ao adicionar aluguel:', error);
    return { success: false, message: lang.plugin_addaluguel.error_add };
  }
};

let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_addaluguel: {
        only_owner: () => '🚫 Apenas o Dono principal pode adicionar aluguel!',
        only_group: () => '🚫 Este comando só pode ser usado em grupos.',
        invalid_duration: (prefix) => `🤔 Duração inválida. Use um número de dias (ex: 30) ou a palavra "permanente".\nExemplo: ${prefix}addaluguel 30`,
        success: (groupName, duration) => `✅ Aluguel adicionado para o grupo *${groupName}*! Duração: ${duration}.`,
        error_add: () => '❌ Erro ao adicionar o aluguel ao grupo.',
        error: () => '❌ Ocorreu um erro inesperado ao adicionar o aluguel.',
        permanent: () => 'Permanente',
        days: () => 'dias'
      }
    };
  }
})();

const commandMap = {
  addaluguel: {
    key: 'addaluguel',
    action: 'add_rental',
    aliases: ['adicionaraluguel', 'addlocacao', 'agregaralquiler', 'ajouterlocation', 'tambahsewa']
  }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-19',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'group',
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_addaluguel.only_owner() }, { quoted: info });
      }

      if (!info.isGroup) {
        return nazu.sendMessage(from, { text: lang.plugin_addaluguel.only_group() }, { quoted: info });
      }

      const durationArg = query.toLowerCase().trim().split(' ')[0];
      let durationDays = null;
      if (durationArg === 'permanente') {
        durationDays = 'permanent';
      } else if (!isNaN(parseInt(durationArg)) && parseInt(durationArg) > 0) {
        durationDays = parseInt(durationArg);
      } else {
        return nazu.sendMessage(from, { text: lang.plugin_addaluguel.invalid_duration(info.prefix) }, { quoted: info });
      }

      const result = await setGroupRental(nazu, from, durationDays, lang);
      return nazu.sendMessage(from, { text: result.message }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_addaluguel.error() }, { quoted: info });
    }
  }
};