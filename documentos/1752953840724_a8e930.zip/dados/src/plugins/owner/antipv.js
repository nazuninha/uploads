const path = require('path');
const fs = require('fs');
const { loadMessages, getMessages } = require(path.join(__dirname, '..', '..', 'langs', 'loader.js'));

const DATABASE_DIR = path.join(__dirname, '..', '..', '..', 'database');
const ANTIPV_FILE = path.join(DATABASE_DIR, 'antipv.json');

const ensureJsonFileExists = (file, defaultData) => {
  if (!fs.existsSync(file)) {
    ensureDirectoryExists(DATABASE_DIR);
    fs.writeFileSync(file, JSON.stringify(defaultData, null, 2));
  }
};

const ensureDirectoryExists = (dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

const loadJsonFile = (file, defaultData) => {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8'));
  } catch (error) {
    console.error(`Erro ao carregar ${file}:`, error);
    return defaultData;
  }
};

// Inicialização das mensagens de idioma
let lang;
(async () => {
  try {
    await loadMessages();
    lang = getMessages();
  } catch (error) {
    console.error('Erro ao carregar mensagens:', error);
    lang = {
      plugin_antipv_manager: {
        only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
        no_message: (prefix, command) => `🤔 Por favor, forneça a nova mensagem para o antipv. Exemplo: ${prefix}${command} Comandos no privado estão desativados!`,
        antipv_enabled: () => '✅ Antipv ativado! O bot agora ignora mensagens no privado.',
        antipv_disabled: () => '✅ Antipv desativado! O bot agora responde normalmente no privado.',
        antipv2_enabled: () => '✅ Antipv2 ativado! O bot agora avisa que comandos só funcionam em grupos no privado.',
        antipv2_disabled: () => '✅ Antipv2 desativado! O bot agora responde normalmente no privado.',
        antipv3_enabled: () => '✅ Antipv3 ativado! O bot agora bloqueia usuários que usam comandos no privado.',
        antipv3_disabled: () => '✅ Antipv3 desativado! O bot agora responde normalmente no privado.',
        message_updated: (message) => `✅ Mensagem do antipv atualizada para: "${message}"`,
        error: () => '❌ Ops, algo deu errado! Tente novamente, por favor! 💔'
      }
    };
  }
})();

const commandMap = {
  antipv: { key: 'antipv', action: 'toggle_antipv', aliases: ['antiprivate', 'antiprivado', 'antiprivé', 'antiprivat'] },
  antipv2: { key: 'antipv2', action: 'toggle_antipv2', aliases: ['antiprivate2', 'antiprivado2', 'antiprivé2', 'antiprivat2'] },
  antipv3: { key: 'antipv3', action: 'toggle_antipv3', aliases: ['antiprivate3', 'antiprivado3', 'antiprivé3', 'antiprivat3'] },
  antipvmessage: { key: 'antipvmessage', action: 'set_message', aliases: ['antipvmensagem', 'antipvmensaje', 'antipvmessagem', 'pesanantipv'] }
};

module.exports = {
  creator: 'Hiudy',
  update: '2025-07-17',
  commands: Object.values(commandMap).flatMap(cmd => [cmd.key, ...cmd.aliases]),
  require: { isOwner: true },
  only: 'all',
  exec: async (nazu, from, sender, info, command, query) => {
    const config = Object.values(commandMap).find(
      cmd => cmd.key === command || cmd.aliases.includes(command)
    );
    if (!config) return;

    try {
      if (!info.isOwner) {
        return nazu.sendMessage(from, { text: lang.plugin_antipv_manager.only_owner() }, { quoted: info });
      }

      const antipvFile = ANTIPV_FILE;
      let antipvData = loadJsonFile(antipvFile, { mode: null, message: '🚫' });
      ensureJsonFileExists(antipvFile, { mode: null, message: '🚫' });

      if (config.action === 'set_message') {
        if (!query) {
          return nazu.sendMessage(from, { text: lang.plugin_antipv_manager.no_message(info.prefix, command) }, { quoted: info });
        }
        antipvData.message = query.trim();
        fs.writeFileSync(antipvFile, JSON.stringify(antipvData, null, 2));
        return nazu.sendMessage(from, { text: lang.plugin_antipv_manager.message_updated(antipvData.message) }, { quoted: info });
      }

      let responseMessage;
      if (config.action === 'toggle_antipv') {
        antipvData.mode = antipvData.mode === 'antipv' ? null : 'antipv';
        responseMessage = antipvData.mode
          ? lang.plugin_antipv_manager.antipv_enabled()
          : lang.plugin_antipv_manager.antipv_disabled();
      } else if (config.action === 'toggle_antipv2') {
        antipvData.mode = antipvData.mode === 'antipv2' ? null : 'antipv2';
        responseMessage = antipvData.mode
          ? lang.plugin_antipv_manager.antipv2_enabled()
          : lang.plugin_antipv_manager.antipv2_disabled();
      } else if (config.action === 'toggle_antipv3') {
        antipvData.mode = antipvData.mode === 'antipv3' ? null : 'antipv3';
        responseMessage = antipvData.mode
          ? lang.plugin_antipv_manager.antipv3_enabled()
          : lang.plugin_antipv_manager.antipv3_disabled();
      }

      fs.writeFileSync(antipvFile, JSON.stringify(antipvData, null, 2));
      return nazu.sendMessage(from, { text: responseMessage }, { quoted: info });
    } catch (error) {
      console.error(`Erro ao processar comando ${command}:`, error);
      return nazu.sendMessage(from, { text: lang.plugin_antipv_manager.error() }, { quoted: info });
    }
  }
};