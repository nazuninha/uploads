// [ By Hiudy ] -- PT

module.exports = {
  // config.js || By Hiudy
  invalid_prefix: "❌ O prefixo deve ter exatamente 1 caractere.",
  invalid_number: "❌ O número deve conter apenas dígitos (10-15 caracteres).",
  example_number: "Exemplo: 553399285117 (sem símbolos ou espaços)",
  invalid_language: (valid) => `❌ Linguagem invalida, as linguagens são: ${valid.join(',')}`,
  config_cancelled: "🛑 Operação cancelada pelo usuário.",
  installing_dependencies: "📦 Instalando dependências...",
  install_complete: "✔ Instalação concluída! Rode 'npm start' para iniciar o bot.",
  install_error: (message) => `❌ Erro na instalação: ${message}`,
  manual_install_info: "ℹ️ Você pode tentar instalar manualmente com: npm install --force --no-bin-links",
  config_welcome: (version) => `🔧 Configurador da Nazuna - v${version}`,
  creator_message: "🚀 Criado por Hiudy",
  existing_config_loaded: "ℹ️ Configuração existente carregada.",
  error_reading_config: (message) => `⚠ Erro ao ler configuração existente: ${message}`,
  using_default_values: "ℹ️ Usando valores padrão.",
  basic_config_title: "CONFIGURAÇÃO BÁSICA",
  ask_owner_name: "👤 Qual seu nome?",
  ask_owner_number: "📞 Qual seu número (somente dígitos, 10-15)?",
  ask_bot_name: "🤖 Qual o nome do bot?",
  ask_prefix: "⚙️ Qual o prefixo (1 caractere)?",
  ask_language: "⚒️ Qual a linguagem da bot? (pt, en, es, id, fr)",
  config_summary: "📋 Resumo da configuração:",
  owner_name_summary: (name) => `Nome dono: ${name}`,
  owner_number_summary: (number) => `Numero dono: ${number}`,
  bot_name_summary: (name) => `Nome da bot: ${name}`,
  prefix_summary: (prefix) => `Prefixo da bot: ${prefix}`,
  language_summary: (lang) => `Linguagem da bot: ${lang}`,
  config_saved_success: "🎉 Configuração concluída com sucesso!",
  ask_install_deps: "📦 Instalar dependências agora?",
  install_later_info: "⚡ Para instalar depois, use: npm run config:install",
  nazuna_ready: (version) => `🚀 Nazuna pronta para uso! - v${version}`,
  error_saving_config: (message) => `❌ Erro ao salvar configuração: ${message}`,
  unexpected_error: (message) => `❌ Erro inesperado: ${message}`,
  prompt_input_current: (value) => `(Atual: ${value || 'Não definido'})`,
  fatal_error: (message) => `❌ Erro fatal: ${message}`,
  
  // start.js || By Hiudy
  shutting_down: "🛑 Encerrando o bot...",
  starter_header: "🚀 Inicializador da Nazuna 🚀",
  starter_version: (version) => `🔧 Criado por Hiudy - Versão: ${version} 🔧`,
  config_not_found: "⚠ Opa! Parece que você ainda não configurou o bot.",
  run_config_command: (command) => `🔹 Para configurar, execute: ${command}`,
  modules_not_found: "⚠ Opa! Parece que os módulos ainda não foram instalados.",
  run_install_command: (command) => `📦 Para instalar, execute: ${command}`,
  connection_file_not_found: (file) => `⚠ Arquivo de conexão não encontrado: ${file}`,
  check_installation: "Verifique se o bot foi instalado corretamente.",
  starting_with_code: (dualMode) => `🚀 Iniciando o bot com código${dualMode ? ' (modo dual)' : ''}...`,
  starting_with_qrcode: (dualMode) => `🚀 Iniciando o bot com QR Code${dualMode ? ' (modo dual)' : ''}...`,
  error_starting_process: (message) => `❌ Erro ao iniciar o processo: ${message}`,
  bot_crashed: (code) => `⚠ O bot caiu com código: ${code}`,
  many_restarts: (count, seconds) => `⚠ Muitas reinicializações (${count}). Aguardando ${seconds} segundos...`,
  restarting_bot: (seconds) => `⚠ O bot caiu! Reiniciando em ${seconds} segundo...`,
  error_checking_qr: (message) => `❌ Erro ao verificar diretório QR Code: ${message}`,
  ask_connection_method: "🔗 Como deseja conectar o bot?",
  qr_code_connection: "1. Conexão por QR Code",
  code_connection: "2. Conexão por Código",
  exit_option: "3. Sair",
  choose_option: "Escolha uma opção (1/2/3): ",
  starting_qr_connection: "📡 Iniciando conexão por QR Code...",
  starting_code_connection: "🔑 Iniciando conexão por Código...",
  exiting: "👋 Saindo...",
  invalid_option_qr_default: "❌ Opção inválida! Usando QR Code como padrão.",
  qr_detected_auto_connect: "📡 QR Code já detectado! Iniciando conexão automática...",
  
  // update.js || By Hiudy
  updater_header: "Atualizador da Nazuna",
  checking_requirements: "Verificando os pré-requisitos...",
  git_found: "✔ Git encontrado.",
  git_not_found: "❌ Git não foi encontrado. O Git é necessário para continuar.",
  git_download_win: "ℹ️ Baixe e instale o Git para Windows em: https://git-scm.com/download/win",
  git_install_mac: "ℹ️ Instale o Git no macOS via Homebrew ('brew install git') ou Xcode Command Line Tools.",
  git_install_linux: "ℹ️ Instale o Git no Linux usando o gerenciador de pacotes da sua distribuição (ex: 'sudo apt-get install git').",
  npm_found: "✔ NPM encontrado.",
  npm_not_found: "❌ NPM não foi encontrado. O NPM é necessário para instalar as dependências.",
  npm_download: "ℹ️ O NPM vem com o Node.js. Baixe e instale em: https://nodejs.org/",
  requirements_met: "✔ Todos os pré-requisitos foram atendidos.",
  update_warning: "ATENÇÃO: Este processo irá substituir os arquivos atuais do bot pela versão mais recente.",
  backup_info: "ℹ️ Um backup de 'config.json', 'database' e 'midias' será criado automaticamente.",
  cancel_info: "Você pode cancelar a qualquer momento pressionando CTRL+C.",
  starting_in: (countdown) => `Iniciando a atualização em ${countdown} segundos...`,
  proceeding_with_update: "🚀 Prosseguindo com a atualização...",
  creating_backup: "📦 Criando backup dos seus dados...",
  copying_database: "Copiando banco de dados...",
  copying_config: "Copiando arquivo de configuração...",
  copying_media: "Copiando arquivos de mídia...",
  backup_saved_at: (dir) => `✔ Backup salvo com sucesso em: ${dir}`,
  error_creating_backup: (msg) => `❌ Erro ao criar o backup: ${msg}`,
  downloading_latest_version: "📥 Baixando a versão mais recente do repositório...",
  cloning_repo: "Clonando repositório...",
  downloading: "Baixando...",
  download_complete: "✔ Download concluído.",
  failed_to_download: (msg) => `❌ Falha ao baixar a atualização: ${msg}`,
  checking_github_connectivity: "Verificando conectividade com o GitHub...",
  permission_or_git_config_error: "Pode ser um erro de permissão ou configuração do Git. Tente rodar o terminal como administrador.",
  internet_connection_error: "Parece ser um problema de conexão com a internet.",
  cleaning_old_files: "🧹 Limpando arquivos antigos...",
  removing_git_dir: "Removendo diretório .git antigo...",
  removing_package_json: "Removendo package.json antigo...",
  removing_package_lock: "Removendo package-lock.json antigo...",
  cleaning_data_dir: "Limpando diretório de dados (exceto backups)...",
  cleaning_complete: "✔ Limpeza concluída.",
  error_cleaning_files: (msg) => `❌ Erro ao limpar arquivos antigos: ${msg}`,
  applying_update: "⬆️ Aplicando a atualização...",
  copying_dir: (dir) => `Copiando diretório: ${dir}`,
  files_copied: (copied, total) => `Arquivos copiados: ${copied} de ${total}`,
  update_applied_success: "✔ Atualização aplicada com sucesso.",
  error_applying_update: (msg) => `❌ Erro ao aplicar a atualização: ${msg}`,
  restoring_backup: "🗂️ Restaurando o backup...",
  restoring_database: "Restaurando banco de dados...",
  restoring_config: "Restaurando arquivo de configuração...",
  restoring_media: "Restaurando arquivos de mídia...",
  restore_success: "✔ Backup restaurado com sucesso.",
  error_restoring_backup: (msg) => `❌ Erro ao restaurar o backup: ${msg}`,
  installing_deps: "📦 Instalando novas dependências...",
  deps_installed_success: "✔ Dependências instaladas com sucesso.",
  failed_to_install_deps: (msg) => `❌ Falha ao instalar dependências: ${msg}`,
  manual_install_prompt: "Tente instalar manualmente com 'npm install'.",
  finishing_up: "✨ Finalizando...",
  removing_backup_dir: "Removendo diretório de backup temporário...",
  backup_removed: "Backup temporário removido.",
  error_cleaning_temp_files: (msg) => `❌ Erro ao limpar arquivos temporários: ${msg}`,
  progress: (completed, total) => `Progresso: [${completed}/${total}]`,
  fetching_commit_info: "🔍 Buscando informações da última atualização...",
  error_fetching_commits: (status) => `❌ Erro ao buscar informações de commit: ${status}`,
  update_complete_success: "🎉 Atualização concluída com sucesso!",
  start_bot_prompt: "Você já pode iniciar o bot com 'npm start'.",
  error_during_update: (msg) => `❌ Ocorreu um erro crítico durante a atualização: ${msg}`,
  backup_location_info: (dir) => `ℹ️ Seus dados importantes (config, database, midias) foram salvos em: ${dir}`,
  manual_restore_info: "Você pode restaurá-los manualmente movendo os arquivos da pasta de backup para a pasta 'dados'.",
  contact_dev_for_help: "Se o problema persistir, entre em contato com o desenvolvedor.",
  
  // connect.js || By Hiudy
  invalid_number: "❌ Número inválido! Deve ter entre 10 e 15 dígitos.",
  ask_phone_number: "📞 Digite seu número (com DDD e DDI, ex: +5511999999999): \n\n",
  pairing_code: (code) => `🔢 Seu código de pareamento: ${code}`,
  pairing_instructions: "📲 No WhatsApp, vá em 'Aparelhos Conectados' -> 'Conectar com Número de Telefone' e insira o código.\n",
  bot_started: (nomebot, prefixo, nomedono, dualMode) => `
============================================
Bot: ${nomebot}
Prefix: ${prefixo}
Dono: ${nomedono}
Criador: Hiudy
============================================
    ✅ BOT INICIADO COM SUCESSO${dualMode ? ' (MODO DUAL)' : ''}
============================================`,
  starting_nazuna: (dualMode) => `🚀 Iniciando Nazuna ${dualMode ? '(Modo Dual)' : '(Modo Simples)'}...`,
  starting_dual_mode: "🔀 Modo Dual ativado - Iniciando conexão secundária...",
  dual_mode_ready: "🔀 Ambas as conexões estabelecidas - Modo dual pronto!",
  secondary_connection_established: "🔀 Conexão secundária estabelecida com sucesso!",
  secondary_connection_closed: (reason) => `🔀 Conexão secundária fechada, motivo: ${reason}`,
  reconnecting_secondary: "🔀 Tentando reconectar conexão secundária...",
  error_starting_secondary: (err) => `🔀 Erro ao iniciar conexão secundária: ${err}`,
  continuing_primary_only: "🔀 Continuando apenas com conexão primária...",
  error_starting_bot: (err) => `❌ Erro ao iniciar o bot: ${err}`,
  primary_connection_closed: (reason, message) => `⚠️ Conexão primária fechada, motivo: ${reason} - ${message}`,
  reconnecting_primary: "🔄 Tentando reconectar conexão primária...",
  updating_primary_session: "🔄 Atualizando sessão primária...",
  connecting_secondary_session: "🔀 Conectando sessão secundária...",
  invalid_index_module: "❌ O módulo index.js não exporta uma função válida.",
  error_processing_poll: (err) => `❌ Erro ao processar atualização de enquete: ${err}`,
  error_calling_index: (err) => `❌ Erro ao chamar o módulo index.js: ${err}`,
  error_removing_blacklist_user: (from, err) => `❌ Erro ao remover usuário da blacklist no grupo ${from}: ${err}`,
  error_sending_welcome: (from, err) => `❌ Erro ao enviar mensagem de boas-vindas no grupo ${from}: ${err}`,
  error_sending_exit: (from, err) => `❌ Erro ao enviar mensagem de saída no grupo ${from}: ${err}`,
  x9_mode_message: (participant, action, by) => `🕵️ *X9 Mode* 🕵️\n\n@${participant} foi ${action} por @${by}!`,
  antifake_remove_message: (participant) => `🚫 @${participant} foi removido por ser de um país não permitido (antifake ativado)!`,
  antipt_remove_message: (participant) => `🚫 @${participant} foi removido por ser de Portugal (antipt ativado)!`,
  blacklist_remove_message: (participant, reason) => `🚫 @${participant} foi removido automaticamente por estar na blacklist.\nMotivo: ${reason}`,
  welcome_message: (text, sender) => ({
    default: `Seja bem-vindo(a) @${sender} ao #nomedogp#!\nVocê é nosso membro número: *#membros#*!`,
    custom: (text) => text,
  }),
  exit_message: (text, sender) => ({
    default: `Adeus @${sender}! 👋\nO grupo *#nomedogp#* agora tem *#membros#* membros.`,
    custom: (text) => text,
  }),
  reason_messages: {
    401: "🗑️ Sessão inválida, excluindo autenticação...",
    408: "� empo, recarregando...",
    411: "📄 O arquivo de sessão parece incorreto, tentando recarregar...",
    428: "📡 Não foi possível manter a conexão com o WhatsApp, tentando novamente...",
    440: "🔗 Existem muitas sessões conectadas, feche algumas...",
    500: "⚙️ A sessão parece mal configurada, tentando reconectar...",
    503: "❓ Erro desconhecido, tentando reconectar...",
    515: "🔄 Reiniciando código para estabilizar conexão...",
  },
plugin_config: {
  only_owner: () => '⚠️ Desculpe, este comando é exclusivo para o meu dono! 😎',
  usage_prefixo: (prefix, command) => `Digite um prefixo maneiro! Exemplo: ${prefix}${command} #`,
  usage_numerodono: (prefix, command) => `Por favor, informe o número do dono! Exemplo: ${prefix}${command} 55123456789`,
  usage_nomedono: (prefix, command) => `Qual é o nome do dono? Exemplo: ${prefix}${command} João`,
  usage_nomebot: (prefix, command) => `Dê um nome incrível para o bot! Exemplo: ${prefix}${command} SuperBot`,
  usage_language: (prefix, command) => `Escolha um idioma! Exemplo: ${prefix}${command} pt (opções: en, pt, es, fr, id)`,
  success_prefixo: (value) => `✨ Prefixo atualizado para *${value}*! Agora é só usar! 🚀`,
  success_numerodono: (value) => `📱 Número do dono atualizado para *${value}*! Tudo certo! ✅`,
  success_nomedono: (value) => `👑 Nome do dono atualizado para *${value}*! Perfeito! 😊`,
  success_nomebot: (value) => `🤖 O bot agora se chama *${value}*! Nome top! 🎉`,
  success_language: (value) => `🌍 Idioma alterado para *${value}*! Tudo pronto para conversar! 🗣️`,
  error: () => '😥 Ops, algo deu errado! Tente novamente, por favor! 💔',
  invalid_prefix: () => '⚠️ O prefixo deve ter entre 1 e 5 caracteres. Tente algo como ! ou #!',
  invalid_phone: () => '⚠️ Número inválido! Use apenas números, entre 10 e 15 dígitos (ex.: 55123456789).',
  invalid_name: () => '⚠️ O nome deve ter entre 1 e 50 caracteres. Vamos caprichar! 😊',
  invalid_language: () => '⚠️ Idioma inválido! Escolha entre: en, pt, es, fr, id.'
},
plugin_owner_admin: {
  only_owner: () => '⚠️ Desculpe, este comando é exclusivo para o meu dono! 😎',
  only_group: () => '🚫 Este comando só funciona em grupos! Tente em um grupo, por favor! 🗣️',
  success_seradm: (prefix, command) => `🎉 Você agora é admin! Use seus poderes com sabedoria! 😎`,
  success_sermembro: (prefix, command) => `📌 Você foi rebaixado a membro. Qualquer coisa, é só chamar! 😉`,
  error: (prefix, command) => `🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺`
},
plugin_menu_media: {
  only_owner: () => '⚠️ Desculpe, este comando é exclusivo para o meu dono! 😎',
  only_group: () => '🚫 Este comando só funciona em grupos! Tente em um grupo, por favor! 🗣️',
  no_media: (prefix, command) => `📸 Marque uma imagem ou vídeo com o comando: ${prefix}${command} (mencionando a mídia)`,
  success: () => `✅ Mídia do menu atualizada com sucesso! Pronta para brilhar! ✨`,
  error: () => `😥 Ops, algo deu errado ao atualizar a mídia! Tente novamente, por favor! 💔`
},
plugin_group_ban: {
  only_owner: () => '⚠️ Desculpe, este comando é exclusivo para o meu dono! 😎',
  only_group: () => '🚫 Este comando só funciona em grupos! Tente em um grupo, por favor! 🗣️',
  success_ban: () => '🚫 Grupo banido! Apenas usuários premium ou meu dono podem usar o bot aqui agora. 🔒',
  success_unban: () => '✅ Grupo desbanido! Todos podem usar o bot novamente. 🎉',
  error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
},
plugin_premium_manager: {
  only_owner: () => '⚠️ Desculpe, este comando é exclusivo para o meu dono! 😎',
  only_group: () => '🚫 Este comando só funciona em grupos! Tente em um grupo, por favor! 🗣️',
  no_mention: (prefix, command) => `🙄 Marque um usuário com o comando: ${prefix}${command} @usuário`,
  user_already_premium: () => '🌟 O usuário já está na lista premium!',
  user_not_premium: () => '❌ O usuário não está na lista premium.',
  group_already_premium: () => '🌟 O grupo já está na lista premium!',
  group_not_premium: () => '❌ O grupo não está na lista premium.',
  success_add_user: (user) => `✅ @${user} foi adicionado(a) à lista premium! 🎉`,
  success_remove_user: (user) => `🫡 @${user} foi removido(a) da lista premium.`,
  success_add_group: () => `✅ O grupo foi adicionado à lista premium! 🎉`,
  success_remove_group: () => `🫡 O grupo foi removido da lista premium.`,
  premium_list: (users, groups) => `✨ *Lista de Membros Premium* ✨\n\n` +
    `👤 *Usuários Premium* (${users.length})\n` +
    (users.length > 0 ? users.map((u, i) => `🔹 ${i + 1}. @${u.split('@')[0]}`).join('\n') : `   Nenhum usuário premium encontrado.\n`) +
    `\n👥 *Grupos Premium* (${groups.length})\n` +
    (groups.length > 0 ? groups.join('\n') : `   Nenhum grupo premium encontrado.\n`),
  error: () => '😥 Ops, algo deu errado! Tente novamente, por favor! 💔'
},
plugin_subowner_manager: {
  only_main_owner: () => '🚫 Apenas o Dono principal pode usar este comando! 😎',
  no_target: (prefix, command) => `🤔 Você precisa marcar o usuário ou fornecer o número completo (ex: ${prefix}${command} 5511999998888 ou @usuário)`,
  invalid_jid: () => '❌ ID de usuário inválido. Use o formato completo (ex: 1234567890@s.whatsapp.net) ou marque o usuário.',
  already_subowner: () => '🌟 Este usuário já é um subdono! Não precisa adicionar de novo. 😊',
  owner_cannot_be_subowner: () => '🤔 O Dono principal já tem todos os superpoderes! Não dá pra adicionar como subdono. 😉',
  save_error: () => '😥 Oops! Tive um probleminha para salvar a lista de subdonos. Tente novamente, por favor!',
  not_subowner: () => '🤔 Este usuário não está na lista de subdonos.',
  unexpected_error: () => '❌ Erro inesperado ao processar a lista de subdonos. 🤷',
  no_subowners: () => '✨ Nenhum subdono cadastrado no momento.',
  success_add: (user) => `✅ @${user} foi adicionado(a) como subdono! 🎉`,
  success_remove: (user) => `🫡 @${user} foi removido(a) dos subdonos.`,
  list_subowners: (list, mentions) => `👑 *Lista de Subdonos Atuais:*\n\n${list}`,
  error: () => '❌ Ops, algo deu errado! Tente novamente, por favor! 💔'
},
plugin_antipv_manager: {
  only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
  no_message: (prefix, command) => `🤔 Por favor, forneça a nova mensagem para o antipv. Exemplo: ${prefix}${command} Comandos no privado estão desativados!`,
  antipv_enabled: () => '✅ Antipv ativado! O bot agora ignora mensagens no privado.',
  antipv_disabled: () => '✅ Antipv desativado! O bot agora responde normalmente no privado.',
  antipv2_enabled: () => '✅ Antipv2 ativado! O bot agora avisa que comandos só funcionam em grupos no privado.',
  antipv2_disabled: () => '✅ Antipv2 desativado! O bot agora responde normalmente no privado.',
  antipv3_enabled: () => '✅ Antipv3 ativado! O bot agora bloqueia usuários que usam comandos no privado.',
  antipv3_disabled: () => '✅ Antipv3 desativado! O bot agora responde normalmente no privado.',
  message_updated: (message) => `✅ Mensagem do antipv atualizada para: "${message}"`,
  error: () => '❌ Ops, algo deu errado! Tente novamente, por favor! 💔'
},
plugin_global_block_manager: {
  only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
  no_command: (prefix, command) => `❌ Informe o comando a bloquear/desbloquear! Ex.: ${prefix}${command} sticker`,
  no_user: () => '🤔 Marque alguém ou forneça o ID do usuário! 🙄',
  command_already_blocked: (cmd) => `❌ O comando *${cmd}* já está bloqueado!`,
  command_not_blocked: (cmd) => `❌ O comando *${cmd}* não está bloqueado!`,
  user_already_blocked: (user) => `❌ O usuário @${user} já está bloqueado!`,
  user_not_blocked: (user) => `❌ O usuário @${user} não está bloqueado!`,
  default_reason: () => 'Não informado',
  command_blocked: (cmd, reason) => `✅ Comando *${cmd}* bloqueado globalmente!\nMotivo: ${reason}`,
  command_unblocked: (cmd) => `✅ Comando *${cmd}* desbloqueado globalmente!`,
  user_blocked: (user, reason) => `✅ Usuário @${user} bloqueado globalmente!\nMotivo: ${reason}`,
  user_unblocked: (user) => `✅ Usuário @${user} desbloqueado globalmente!`,
  no_blocked_commands: () => 'Nenhum comando bloqueado.',
  no_blocked_users: () => 'Nenhum usuário bloqueado.',
  list_blocks: (nomebot, blockedCommands, blockedUsers) => `🔒 *Bloqueios Globais - ${nomebot}* 🔒\n\n📜 *Comandos Bloqueados*:\n${blockedCommands}\n\n👥 *Usuários Bloqueados*:\n${blockedUsers}`,
  error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
},
plugin_premium_manager: {
  only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
  no_user: () => '🤔 Marque alguém ou forneça o ID do usuário! 🙄',
  only_group: () => '❌ Este comando só pode ser usado em grupos! 💔',
  user_already_premium: (user) => `❌ O usuário @${user} já está na lista premium!`,
  user_not_premium: (user) => `❌ O usuário @${user} não está na lista premium!`,
  group_already_premium: () => '❌ O grupo já está na lista premium!',
  group_not_premium: () => '❌ O grupo não está na lista premium!',
  user_added: (user) => `✅ Usuário @${user} foi adicionado(a) à lista premium!`,
  user_removed: (user) => `🫡 Usuário @${user} foi removido(a) da lista premium!`,
  group_added: () => '✅ O grupo foi adicionado à lista premium!',
  group_removed: () => '🫡 O grupo foi removido da lista premium!',
  premium_list: (nomebot, usersPremiumText, groupsPremiumText, usersCount, groupsCount) => 
    `✨ *Lista de Membros Premium - ${nomebot}* ✨\n\n👤 *Usuários Premium* (${usersCount})\n${usersPremiumText}\n\n👥 *Grupos Premium* (${groupsCount})\n${groupsPremiumText}`,
  no_premium_users: () => 'Nenhum usuário premium encontrado.',
  no_premium_groups: () => 'Nenhum grupo premium encontrado.',
  group_info_error: (groupId) => `Grupo ID: ${groupId} (não foi possível obter o nome)`,
  error: () => '😔 Ops, algo deu errado. Tente novamente mais tarde! 💔'
},
plugin_group_list: {
  only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
  group_list: (nomebot, totalGroups, groupsText) => `🌟 *Lista de Grupos e Comunidades - ${nomebot}* 🌟\n📊 *Total de Grupos:* ${totalGroups}\n\n${groupsText}`,
  no_groups: () => 'Nenhum grupo encontrado.',
  group_entry: (index, subject, id, participantCount) => `🔹 *${index}. ${subject}*\n🆔 *ID:* ${id}\n👥 *Participantes:* ${participantCount}\n\n`,
  error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
},
plugin_bot_state: {
  only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
  already_on: () => '🌟 O bot já está ativado!',
  already_off: () => '🌙 O bot já está desativado!',
  bot_on: () => '✅ *Bot ativado!* Agora todos podem usar os comandos.',
  bot_off: () => '✅ *Bot desativado!* Apenas o dono pode usar comandos.',
  error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
},
plugin_getplugin: {
  only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
  no_command: (prefix) => `❌ Digite o nome do comando. Exemplo: ${prefix}getplugin menu`,
  command_not_found: (cmd) => `❌ O comando *${cmd}* não foi encontrado em nenhum plugin!`,
  error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
},
plugin_infoserver: {
  only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
  server_info: (nomebot, data) => `🌸 ═════════════════════ 🌸\n    *INFORMAÇÕES DO SERVIDOR - ${nomebot}*\n🌸 ═════════════════════ 🌸\n\n` +
    `🖥️ *Sistema Operacional:* 🏠\n` +
    `├ 🟢 Node.js: ${data.nodeVersion}\n` +
    `├ 💻 Plataforma: ${data.platform}\n` +
    `├ 🏗️ Arquitetura: ${data.arch}\n` +
    `├ 🔧 Tipo: ${data.type}\n` +
    `├ 📋 Release: ${data.release}\n` +
    `├ 🏷️ Hostname: ${data.hostname}\n` +
    `├ 🔄 Endianness: ${data.endianness}\n` +
    `├ ⏳ Sistema online há: ${data.osUptime} horas\n` +
    `└ 📅 Hora atual: ${data.currentTime}\n\n` +
    `⚡ *Processador (CPU):* 🧠\n` +
    `├ 🔢 Núcleos: ${data.cpuCount}\n` +
    `├ 🏷️ Modelo: ${data.cpuModel}\n` +
    `├ 👤 Tempo usuário: ${data.cpuUser}s\n` +
    `├ ⚙️ Tempo sistema: ${data.cpuSystem}s\n` +
    `├ 📈 Uso CPU atual: ${data.cpuPercent}%\n` +
    `├ 📊 Load 1min: ${data.loadAvg[0].toFixed(2)}\n` +
    `├ 📈 Load 5min: ${data.loadAvg[1].toFixed(2)}\n` +
    `└ 📉 Load 15min: ${data.loadAvg[2].toFixed(2)}\n\n` +
    `💾 *Memória do Sistema:* 🧠\n` +
    `├ 🆓 RAM Livre: ${data.freeMemory} GB\n` +
    `├ 📊 RAM Total: ${data.totalMemory} GB\n` +
    `├ 📈 RAM Usada: ${data.usedMemory} GB\n` +
    `└ ${data.memoryEmoji} Uso: [${data.memoryBar}] ${data.memoryUsagePercent}%\n\n` +
    `🤖 *Memória do Bot:* 💖\n` +
    `├ 🧠 Heap Usado: ${data.botMemUsed} MB\n` +
    `├ 📦 Heap Total: ${data.botMemTotal} MB\n` +
    `├ 🏠 RSS: ${data.botMemRss} MB\n` +
    `├ 🔗 Externo: ${data.botMemExternal} MB\n` +
    `└ ${data.botMemoryEmoji} Eficiência: [${data.botMemoryBar}] ${data.botMemoryUsagePercent}%\n\n` +
    `🌐 *Rede e Conectividade:* 🔗\n` +
    `├ 🔌 Interfaces: ${data.networkInterfaces}\n` +
    `${data.networkDetails}` +
    `├ 📡 Status: ${data.networkStatus}\n` +
    `├ ⏱️ Latência de Rede: ${data.networkLatency}\n` +
    `└ 🛡️ Firewall: ${data.firewallStatus}\n\n` +
    `💽 *Armazenamento:* 💿\n` +
    `├ 🆓 Livre: ${data.diskFree} GB\n` +
    `├ 📊 Total: ${data.diskTotal} GB\n` +
    `├ 📈 Usado: ${data.diskUsed} GB\n` +
    `└ ${data.diskEmoji} Uso: [${data.diskBar}] ${data.diskUsagePercent}%\n\n` +
    `⏰ *Tempo e Latência:* 🕐\n` +
    `├ ⏱️ Latência do Bot: ${data.latency}ms\n` +
    `└ 🚀 Bot online há: ${data.botUptime}`,
  error: () => '🐝 Oh não! Aconteceu um errinho inesperado aqui. Tente de novo daqui a pouquinho, por favor! 🥺'
},
plugin_viewmsg: {
  only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
  invalid_usage: (prefix) => `🤔 Use: ${prefix}viewmsg [on/off]`,
  viewmsg_on: () => '✅ Visualização de mensagens ativada!',
  viewmsg_off: () => '✅ Visualização de mensagens desativada!',
  error: () => '😥 Ocorreu um erro ao alterar a visualização de mensagens.'
},
plugin_modoaluguel: {
  only_main_owner: () => '🚫 Apenas o Dono principal pode gerenciar o modo de aluguel!',
  invalid_usage: (prefix, status) => `🤔 Uso: ${prefix}modoaluguel on|off\nStatus atual: ${status}`,
  rental_mode_on: () => '✅ Modo de aluguel global ATIVADO! O bot agora só responderá em grupos com aluguel ativo.',
  rental_mode_off: () => '✅ Modo de aluguel global DESATIVADO! O bot responderá em todos os grupos permitidos.',
  error_set_mode: () => '❌ Erro ao alterar o modo de aluguel global.',
  error: () => '❌ Ocorreu um erro inesperado.'
},
plugin_listaluguel: {
  only_owner: () => '🚫 Este comando é apenas para o dono do bot! 💔',
  header: (nomebot, globalMode, groupCount) => `╭───「 *Lista de Aluguéis - ${nomebot}* 」───╮\n│ 🌍 *Modo Aluguel Global*: ${globalMode}\n│ 📊 *Total de Grupos*: ${groupCount}\n╰────────────────╯\n`,
  no_groups: () => '📪 Nenhum grupo com aluguel registrado.',
  group_entry: (index, groupName, status, expires) => `🔹 *${index}. ${groupName}*\n  - *Status*: ${status}\n  - *Expira em*: ${expires}\n\n`,
  no_groups_filtered: () => '📪 Nenhum grupo encontrado com esse filtro.',
  invalid_filter: (prefix) => `🤔 Filtro inválido! Use: ${prefix}listaluguel [ven|atv|perm]`,
  error: () => '❌ Ocorreu um erro ao listar os aluguéis 💔'
},
plugin_addaluguel: {
  only_owner: () => '🚫 Apenas o Dono principal pode adicionar aluguel!',
  only_group: () => '🚫 Este comando só pode ser usado em grupos.',
  invalid_duration: (prefix) => `🤔 Duração inválida. Use um número de dias (ex: 30) ou a palavra "permanente".\nExemplo: ${prefix}addaluguel 30`,
  success: (groupName, duration) => `✅ Aluguel adicionado para o grupo *${groupName}*! Duração: ${duration}.`,
  error_add: () => '❌ Erro ao adicionar o aluguel ao grupo.',
  error: () => '❌ Ocorreu um erro inesperado ao adicionar o aluguel.',
  permanent: () => 'Permanente',
  days: () => 'dias'
},
plugin_gerarcodigo: {
  only_owner: () => '🚫 Apenas o Dono principal pode gerar códigos!',
  invalid_usage: (prefix) => `🤔 Uso: ${prefix}gerarcodigo <dias|permanente> [id_do_grupo_opcional]`,
  invalid_duration: () => '🤔 Duração inválida. Use um número de dias (ex: 7) ou a palavra "permanente".',
  invalid_group_id: () => '🤔 ID do grupo alvo inválido. Forneça o ID completo (numero@g.us) ou deixe em branco para um código genérico.',
  success: (code, duration) => `✅ Código gerado: *${code}*\nDuração: ${duration}`,
  target_group: (groupName, groupId) => `\nGrupo alvo: *${groupName}* (${groupId})`,
  no_target_group: () => '\nGrupo alvo: Qualquer grupo',
  error_generate: () => '❌ Erro ao gerar o código de ativação.',
  error: () => '❌ Ocorreu um erro inesperado ao gerar o código.',
  permanent: () => 'Permanente',
  days: () => 'dias'
},
plugin_entrar: {
  only_owner: () => '🚫 Este comando é apenas para o meu dono! 💔',
  invalid_link: (prefix) => `🤔 Digite um link de convite válido! Exemplo: ${prefix}entrar https://chat.whatsapp.com/...`,
  success: (groupName) => `✅ Entrei no grupo *${groupName}* com sucesso!`,
  error_join: () => '❌ Erro ao entrar no grupo. Link inválido, permissão negada ou bot já está no grupo.',
  error: () => '❌ Ocorreu um erro inesperado ao tentar entrar no grupo.'
},
plugin_modoliteglobal: {
  only_owner: () => '🚫 Este comando é apenas para o meu dono! 💔',
  lite_enabled: () => '👶 *Modo Lite ativado globalmente!* O conteúdo inapropriado para crianças será filtrado em todos os grupos (a menos que seja explicitamente desativado em algum grupo).',
  lite_disabled: () => '🔞 *Modo Lite desativado globalmente!* O conteúdo do menu de brincadeiras será exibido completamente (a menos que seja explicitamente ativado em algum grupo).',
  error: () => '❌ Ocorreu um erro inesperado ao alterar o modo lite.'
}
};