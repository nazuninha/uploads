// [ By Hiudy ] -- EN

module.exports = {
  // config.js || By Hiudy
  invalid_prefix: "❌ The prefix must be exactly 1 character long.",
  invalid_number: "❌ The number must contain only digits (10-15 characters).",
  example_number: "Example: 553399285117 (without symbols or spaces)",
  invalid_language: (valid) => `❌ Invalid language, the available languages are: ${valid.join(',')}`,
  config_cancelled: "🛑 Operation cancelled by the user.",
  installing_dependencies: "📦 Installing dependencies...",
  install_complete: "✔ Installation complete! Run 'npm start' to start the bot.",
  install_error: (message) => `❌ Installation error: ${message}`,
  manual_install_info: "ℹ️ You can try to install manually with: npm install --force --no-bin-links",
  config_welcome: (version) => `🔧 Nazuna Configurator - v${version}`,
  creator_message: "🚀 Created by Hiudy",
  existing_config_loaded: "ℹ️ Existing configuration loaded.",
  error_reading_config: (message) => `⚠ Error reading existing configuration: ${message}`,
  using_default_values: "ℹ️ Using default values.",
  basic_config_title: "BASIC CONFIGURATION",
  ask_owner_name: "👤 What is your name?",
  ask_owner_number: "📞 What is your number (digits only, 10-15)?",
  ask_bot_name: "🤖 What is the bot's name?",
  ask_prefix: "⚙️ What is the prefix (1 character)?",
  ask_language: "⚒️ What is the bot's language? (pt, en, es, id, fr)",
  config_summary: "📋 Configuration summary:",
  owner_name_summary: (name) => `Owner name: ${name}`,
  owner_number_summary: (number) => `Owner number: ${number}`,
  bot_name_summary: (name) => `Bot name: ${name}`,
  prefix_summary: (prefix) => `Bot prefix: ${prefix}`,
  language_summary: (lang) => `Bot language: ${lang}`,
  config_saved_success: "🎉 Configuration successfully saved!",
  ask_install_deps: "📦 Install dependencies now?",
  install_later_info: "⚡ To install later, use: npm run config:install",
  nazuna_ready: (version) => `🚀 Nazuna is ready to use! - v${version}`,
  error_saving_config: (message) => `❌ Error saving configuration: ${message}`,
  unexpected_error: (message) => `❌ Unexpected error: ${message}`,
  prompt_input_current: (value) => `(Current: ${value || 'Not set'})`,
  fatal_error: (message) => `❌ Fatal error: ${message}`,

  // start.js || By Hiudy
  shutting_down: "🛑 Shutting down the bot...",
  starter_header: "🚀 Nazuna Starter 🚀",
  starter_version: (version) => `🔧 Created by Hiudy - Version: ${version} 🔧`,
  config_not_found: "⚠ Oops! It seems you haven't configured the bot yet.",
  run_config_command: (command) => `🔹 To configure, run: ${command}`,
  modules_not_found: "⚠ Oops! It seems the modules haven't been installed yet.",
  run_install_command: (command) => `📦 To install, run: ${command}`,
  connection_file_not_found: (file) => `⚠ Connection file not found: ${file}`,
  check_installation: "Check if the bot was installed correctly.",
  starting_with_code: (dualMode) => `🚀 Starting the bot with code${dualMode ? ' (dual mode)' : ''}...`,
  starting_with_qrcode: (dualMode) => `🚀 Starting the bot with QR Code${dualMode ? ' (dual mode)' : ''}...`,
  error_starting_process: (message) => `❌ Error starting the process: ${message}`,
  bot_crashed: (code) => `⚠ The bot crashed with code: ${code}`,
  many_restarts: (count, seconds) => `⚠ Too many restarts (${count}). Waiting for ${seconds} seconds...`,
  restarting_bot: (seconds) => `⚠ The bot crashed! Restarting in ${seconds} seconds...`,
  error_checking_qr: (message) => `❌ Error checking QR Code directory: ${message}`,
  ask_connection_method: "🔗 How do you want to connect the bot?",
  qr_code_connection: "1. Connect via QR Code",
  code_connection: "2. Connect via Code",
  exit_option: "3. Exit",
  choose_option: "Choose an option (1/2/3): ",
  starting_qr_connection: "📡 Starting connection via QR Code...",
  starting_code_connection: "🔑 Starting connection via Code...",
  exiting: "👋 Exiting...",
  invalid_option_qr_default: "❌ Invalid option! Defaulting to QR Code.",
  qr_detected_auto_connect: "📡 QR Code already detected! Starting automatic connection...",

  // update.js || By Hiudy
  updater_header: "Nazuna Updater",
  checking_requirements: "Checking for prerequisites...",
  git_found: "✔ Git found.",
  git_not_found: "❌ Git not found. Git is required to continue.",
  git_download_win: "ℹ️ Download and install Git for Windows at: https://git-scm.com/download/win",
  git_install_mac: "ℹ️ Install Git on macOS via Homebrew ('brew install git') or Xcode Command Line Tools.",
  git_install_linux: "ℹ️ Install Git on Linux using your distribution's package manager (e.g., 'sudo apt-get install git').",
  npm_found: "✔ NPM found.",
  npm_not_found: "❌ NPM not found. NPM is required to install dependencies.",
  npm_download: "ℹ️ NPM comes with Node.js. Download and install it from: https://nodejs.org/",
  requirements_met: "✔ All prerequisites have been met.",
  update_warning: "WARNING: This process will replace the current bot files with the latest version.",
  backup_info: "ℹ️ A backup of 'config.json', 'database', and 'midias' will be created automatically.",
  cancel_info: "You can cancel at any time by pressing CTRL+C.",
  starting_in: (countdown) => `Starting the update in ${countdown} seconds...`,
  proceeding_with_update: "🚀 Proceeding with the update...",
  creating_backup: "📦 Creating a backup of your data...",
  copying_database: "Copying database...",
  copying_config: "Copying configuration file...",
  copying_media: "Copying media files...",
  backup_saved_at: (dir) => `✔ Backup successfully saved at: ${dir}`,
  error_creating_backup: (msg) => `❌ Error creating backup: ${msg}`,
  downloading_latest_version: "📥 Downloading the latest version from the repository...",
  cloning_repo: "Cloning repository...",
  downloading: "Downloading...",
  download_complete: "✔ Download complete.",
  failed_to_download: (msg) => `❌ Failed to download the update: ${msg}`,
  checking_github_connectivity: "Checking connectivity with GitHub...",
  permission_or_git_config_error: "It might be a permission or Git configuration error. Try running the terminal as an administrator.",
  internet_connection_error: "It seems to be an internet connection problem.",
  cleaning_old_files: "🧹 Cleaning old files...",
  removing_git_dir: "Removing old .git directory...",
  removing_package_json: "Removing old package.json...",
  removing_package_lock: "Removing old package-lock.json...",
  cleaning_data_dir: "Cleaning data directory (except backups)...",
  cleaning_complete: "✔ Cleaning complete.",
  error_cleaning_files: (msg) => `❌ Error cleaning old files: ${msg}`,
  applying_update: "⬆️ Applying the update...",
  copying_dir: (dir) => `Copying directory: ${dir}`,
  files_copied: (copied, total) => `Files copied: ${copied} of ${total}`,
  update_applied_success: "✔ Update applied successfully.",
  error_applying_update: (msg) => `❌ Error applying update: ${msg}`,
  restoring_backup: "🗂️ Restoring backup...",
  restoring_database: "Restoring database...",
  restoring_config: "Restoring configuration file...",
  restoring_media: "Restoring media files...",
  restore_success: "✔ Backup restored successfully.",
  error_restoring_backup: (msg) => `❌ Error restoring backup: ${msg}`,
  installing_deps: "📦 Installing new dependencies...",
  deps_installed_success: "✔ Dependencies installed successfully.",
  failed_to_install_deps: (msg) => `❌ Failed to install dependencies: ${msg}`,
  manual_install_prompt: "Try installing manually with 'npm install'.",
  finishing_up: "✨ Finishing up...",
  removing_backup_dir: "Removing temporary backup directory...",
  backup_removed: "Temporary backup removed.",
  error_cleaning_temp_files: (msg) => `❌ Error cleaning temporary files: ${msg}`,
  progress: (completed, total) => `Progress: [${completed}/${total}]`,
  fetching_commit_info: "🔍 Fetching information about the latest update...",
  error_fetching_commits: (status) => `❌ Error fetching commit information: ${status}`,
  update_complete_success: "🎉 Update completed successfully!",
  start_bot_prompt: "You can now start the bot with 'npm start'.",
  error_during_update: (msg) => `❌ A critical error occurred during the update: ${msg}`,
  backup_location_info: (dir) => `ℹ️ Your important data (config, database, midias) has been saved in: ${dir}`,
  manual_restore_info: "You can restore them manually by moving the files from the backup folder to the 'dados' folder.",
  contact_dev_for_help: "If the problem persists, contact the developer.",
  
  // connect.js || By Hiudy
  invalid_number: "❌ Invalid number! Must be between 10 and 15 digits.",
  ask_phone_number: "📞 Enter your number (with country and area code, e.g., +5511999999999): \n\n",
  pairing_code: (code) => `🔢 Your pairing code: ${code}`,
  pairing_instructions: "📲 On WhatsApp, go to 'Linked Devices' -> 'Link with Phone Number' and enter the code.\n",
  bot_started: (nomebot, prefixo, nomedono, dualMode) => `
============================================
Bot: ${nomebot}
Prefix: ${prefixo}
Owner: ${nomedono}
Creator: Hiudy
============================================
    ✅ BOT STARTED SUCCESSFULLY${dualMode ? ' (DUAL MODE)' : ''}
============================================`,
  starting_nazuna: (dualMode) => `🚀 Starting Nazuna ${dualMode ? '(Dual Mode)' : '(Single Mode)'}...`,
  starting_dual_mode: "🔀 Dual Mode activated - Starting secondary connection...",
  dual_mode_ready: "🔀 Both connections established - Dual mode ready!",
  secondary_connection_established: "🔀 Secondary connection established successfully!",
  secondary_connection_closed: (reason) => `🔀 Secondary connection closed, reason: ${reason}`,
  reconnecting_secondary: "🔀 Attempting to reconnect secondary connection...",
  error_starting_secondary: (err) => `🔀 Error starting secondary connection: ${err}`,
  continuing_primary_only: "🔀 Continuing with primary connection only...",
  error_starting_bot: (err) => `❌ Error starting the bot: ${err}`,
  primary_connection_closed: (reason, message) => `⚠️ Primary connection closed, reason: ${reason} - ${message}`,
  reconnecting_primary: "🔄 Attempting to reconnect primary connection...",
  updating_primary_session: "🔄 Updating primary session...",
  connecting_secondary_session: "🔀 Connecting secondary session...",
  invalid_index_module: "❌ The index.js module does not export a valid function.",
  error_processing_poll: (err) => `❌ Error processing poll update: ${err}`,
  error_calling_index: (err) => `❌ Error calling index.js module: ${err}`,
  error_removing_blacklist_user: (from, err) => `❌ Error removing blacklisted user from group ${from}: ${err}`,
  error_sending_welcome: (from, err) => `❌ Error sending welcome message in group ${from}: ${err}`,
  error_sending_exit: (from, err) => `❌ Error sending exit message in group ${from}: ${err}`,
  x9_mode_message: (participant, action, by) => `🕵️ *X9 Mode* 🕵️\n\n@${participant} was ${action} by @${by}!`,
  antifake_remove_message: (participant) => `🚫 @${participant} was removed for being from a disallowed country (antifake enabled)!`,
  antipt_remove_message: (participant) => `🚫 @${participant} was removed for being from Portugal (antipt enabled)!`,
  blacklist_remove_message: (participant, reason) => `🚫 @${participant} was automatically removed for being on the blacklist.\nReason: ${reason}`,
  welcome_message: (text, sender) => ({
    default: `Welcome @${sender} to #nomedogp#!\nYou are our member number: *#membros#*!`,
    custom: (text) => text,
  }),
  exit_message: (text, sender) => ({
    default: `Goodbye @${sender}! 👋\nThe group *#nomedogp#* now has *#membros#* members.`,
    custom: (text) => text,
  }),
  reason_messages: {
    401: "🗑️ Invalid session, deleting authentication...",
    408: "⏰ Session timed out, reloading...",
    411: "📄 Session file seems incorrect, attempting to reload...",
    428: "📡 Unable to maintain WhatsApp connection, trying again...",
    440: "🔗 Too many connected sessions, close some...",
    500: "⚙️ Session seems misconfigured, attempting to reconnect...",
    503: "❓ Unknown error, attempting to reconnect...",
    515: "🔄 Restarting code to stabilize connection...",
  },
plugin_config: {
  only_owner: () => '⚠️ Sorry, this command is exclusive to my owner! 😎',
  usage_prefixo: (prefix, command) => `Type a cool prefix! Example: ${prefix}${command} #`,
  usage_numerodono: (prefix, command) => `Please provide the owner’s phone number! Example: ${prefix}${command} 55123456789`,
  usage_nomedono: (prefix, command) => `What’s the owner’s name? Example: ${prefix}${command} John`,
  usage_nomebot: (prefix, command) => `Give the bot an awesome name! Example: ${prefix}${command} SuperBot`,
  usage_language: (prefix, command) => `Choose a language! Example: ${prefix}${command} en (options: en, pt, es, fr, id)`,
  success_prefixo: (value) => `✨ Prefix updated to *${value}*! Ready to roll! 🚀`,
  success_numerodono: (value) => `📱 Owner’s phone number set to *${value}*! All good! ✅`,
  success_nomedono: (value) => `👑 Owner’s name updated to *${value}*! Looks great! 😊`,
  success_nomebot: (value) => `🤖 The bot is now called *${value}*! Awesome name! 🎉`,
  success_language: (value) => `🌍 Language changed to *${value}*! Ready to chat! 🗣️`,
  error: () => '😥 Oops, something went wrong! Please try again! 💔',
  invalid_prefix: () => '⚠️ The prefix must be 1 to 5 characters. Try something like ! or #!',
  invalid_phone: () => '⚠️ Invalid phone number! Use only numbers, 10 to 15 digits (e.g., 55123456789).',
  invalid_name: () => '⚠️ The name must be 1 to 50 characters. Let’s make it shine! 😊',
  invalid_language: () => '⚠️ Invalid language! Choose from: en, pt, es, fr, id.'
},
plugin_owner_admin: {
  only_owner: () => '⚠️ Sorry, this command is exclusive to my owner! 😎',
  only_group: () => '🚫 This command only works in groups! Please try in a group! 🗣️',
  success_seradm: (prefix, command) => `🎉 You’re now an admin! Use your powers wisely! 😎`,
  success_sermembro: (prefix, command) => `📌 You’ve been demoted to member. Call me if you need anything! 😉`,
  error: (prefix, command) => `🐝 Oh no! Something went wrong here. Please try again in a bit! 🥺`
},
plugin_menu_media: {
  only_owner: () => '⚠️ Sorry, this command is exclusive to my owner! 😎',
  only_group: () => '🚫 This command only works in groups! Please try in a group! 🗣️',
  no_media: (prefix, command) => `📸 Please tag an image or video with the command: ${prefix}${command} (quoting the media)`,
  success: () => `✅ Menu media updated successfully! Ready to shine! ✨`,
  error: () => `😥 Oops, something went wrong while updating the media! Please try again! 💔`
},
plugin_group_ban: {
  only_owner: () => '⚠️ Sorry, this command is exclusive to my owner! 😎',
  only_group: () => '🚫 This command only works in groups! Please try in a group! 🗣️',
  success_ban: () => '🚫 Group banned! Only premium users or my owner can use the bot here now. 🔒',
  success_unban: () => '✅ Group unbanned! Everyone can use the bot again. 🎉',
  error: () => '🐝 Oh no! Something went wrong here. Please try again in a bit! 🥺'
},
plugin_premium_manager: {
  only_owner: () => '⚠️ Sorry, this command is exclusive to my owner! 😎',
  only_group: () => '🚫 This command only works in groups! Please try in a group! 🗣️',
  no_mention: (prefix, command) => `🙄 Tag a user with the command: ${prefix}${command} @user`,
  user_already_premium: () => '🌟 The user is already on the premium list!',
  user_not_premium: () => '❌ The user is not on the premium list.',
  group_already_premium: () => '🌟 The group is already on the premium list!',
  group_not_premium: () => '❌ The group is not on the premium list.',
  success_add_user: (user) => `✅ @${user} has been added to the premium list! 🎉`,
  success_remove_user: (user) => `🫡 @${user} has been removed from the premium list.`,
  success_add_group: () => `✅ The group has been added to the premium list! 🎉`,
  success_remove_group: () => `🫡 The group has been removed from the premium list.`,
  premium_list: (users, groups) => `✨ *Premium Members List* ✨\n\n` +
    `👤 *Premium Users* (${users.length})\n` +
    (users.length > 0 ? users.map((u, i) => `🔹 ${i + 1}. @${u.split('@')[0]}`).join('\n') : `   No premium users found.\n`) +
    `\n👥 *Premium Groups* (${groups.length})\n` +
    (groups.length > 0 ? groups.join('\n') : `   No premium groups found.\n`),
  error: () => '😥 Oops, something went wrong! Please try again! 💔'
},
plugin_subowner_manager: {
  only_main_owner: () => '🚫 Only the main Owner can use this command! 😎',
  no_target: (prefix, command) => `🤔 You need to tag a user or provide the full number (e.g., ${prefix}${command} 5511999998888 or @user)`,
  invalid_jid: () => '❌ Invalid user ID. Use the full format (e.g., 1234567890@s.whatsapp.net) or tag the user.',
  already_subowner: () => '🌟 This user is already a subowner! No need to add again. 😊',
  owner_cannot_be_subowner: () => '🤔 The main Owner already has all the superpowers! Cannot be added as a subowner. 😉',
  save_error: () => '😥 Oops! I had a little problem saving the subowner list. Please try again!',
  not_subowner: () => '🤔 This user is not on the subowner list.',
  unexpected_error: () => '❌ Unexpected error while processing the subowner list. 🤷',
  no_subowners: () => '✨ No subowners registered at the moment.',
  success_add: (user) => `✅ @${user} has been added as a subowner! 🎉`,
  success_remove: (user) => `🫡 @${user} has been removed from subowners.`,
  list_subowners: (list, mentions) => `👑 *List of Current Subowners:*\n\n${list}`,
  error: () => '❌ Oops, something went wrong! Please try again! 💔'
},
plugin_antipv_manager: {
  only_owner: () => '🚫 This command is only for the bot owner! 💔',
  no_message: (prefix, command) => `🤔 Please provide the new antipv message. Example: ${prefix}${command} Commands in private are disabled!`,
  antipv_enabled: () => '✅ Antipv enabled! The bot will now ignore private messages.',
  antipv_disabled: () => '✅ Antipv disabled! The bot will now respond normally in private.',
  antipv2_enabled: () => '✅ Antipv2 enabled! The bot will now warn that commands only work in groups in private.',
  antipv2_disabled: () => '✅ Antipv2 disabled! The bot will now respond normally in private.',
  antipv3_enabled: () => '✅ Antipv3 enabled! The bot will now block users who use commands in private.',
  antipv3_disabled: () => '✅ Antipv3 disabled! The bot will now respond normally in private.',
  message_updated: (message) => `✅ Antipv message updated to: "${message}"`,
  error: () => '❌ Oops, something went wrong! Please try again! 💔'
},
plugin_global_block_manager: {
  only_owner: () => '🚫 This command is only for the bot owner! 💔',
  no_command: (prefix, command) => `❌ Please provide the command to block/unblock! Ex.: ${prefix}${command} sticker`,
  no_user: () => '🤔 Tag someone or provide the user ID! 🙄',
  command_already_blocked: (cmd) => `❌ The command *${cmd}* is already blocked!`,
  command_not_blocked: (cmd) => `❌ The command *${cmd}* is not blocked!`,
  user_already_blocked: (user) => `❌ The user @${user} is already blocked!`,
  user_not_blocked: (user) => `❌ The user @${user} is not blocked!`,
  default_reason: () => 'Not specified',
  command_blocked: (cmd, reason) => `✅ Command *${cmd}* blocked globally!\nReason: ${reason}`,
  command_unblocked: (cmd) => `✅ Command *${cmd}* unblocked globally!`,
  user_blocked: (user, reason) => `✅ User @${user} blocked globally!\nReason: ${reason}`,
  user_unblocked: (user) => `✅ User @${user} unblocked globally!`,
  no_blocked_commands: () => 'No commands blocked.',
  no_blocked_users: () => 'No users blocked.',
  list_blocks: (nomebot, blockedCommands, blockedUsers) => `🔒 *Global Blocks - ${nomebot}* 🔒\n\n📜 *Blocked Commands*:\n${blockedCommands}\n\n👥 *Blocked Users*:\n${blockedUsers}`,
  error: () => '🐝 Oh no! An unexpected error occurred. Please try again in a bit! 🥺'
},
plugin_premium_manager: {
  only_owner: () => '🚫 This command is only for the bot owner! 💔',
  no_user: () => '🤔 Tag someone or provide the user ID! 🙄',
  only_group: () => '❌ This command can only be used in groups! 💔',
  user_already_premium: (user) => `❌ The user @${user} is already on the premium list!`,
  user_not_premium: (user) => `❌ The user @${user} is not on the premium list!`,
  group_already_premium: () => '❌ The group is already on the premium list!',
  group_not_premium: () => '❌ The group is not on the premium list!',
  user_added: (user) => `✅ User @${user} has been added to the premium list!`,
  user_removed: (user) => `🫡 User @${user} has been removed from the premium list!`,
  group_added: () => '✅ The group has been added to the premium list!',
  group_removed: () => '🫡 The group has been removed from the premium list!',
  premium_list: (nomebot, usersPremiumText, groupsPremiumText, usersCount, groupsCount) => 
    `✨ *Premium Members List - ${nomebot}* ✨\n\n👤 *Premium Users* (${usersCount})\n${usersPremiumText}\n\n👥 *Premium Groups* (${groupsCount})\n${groupsPremiumText}`,
  no_premium_users: () => 'No premium users found.',
  no_premium_groups: () => 'No premium groups found.',
  group_info_error: (groupId) => `Group ID: ${groupId} (could not retrieve name)`,
  error: () => '😔 Oops, something went wrong. Please try again later! 💔'
},
plugin_group_list: {
  only_owner: () => '🚫 This command is only for the bot owner! 💔',
  group_list: (nomebot, totalGroups, groupsText) => `🌟 *List of Groups and Communities - ${nomebot}* 🌟\n📊 *Total Groups:* ${totalGroups}\n\n${groupsText}`,
  no_groups: () => 'No groups found.',
  group_entry: (index, subject, id, participantCount) => `🔹 *${index}. ${subject}*\n🆔 *ID:* ${id}\n👥 *Participants:* ${participantCount}\n\n`,
  error: () => '🐝 Oh no! An unexpected error occurred. Please try again in a bit! 🥺'
},
plugin_bot_state: {
  only_owner: () => '🚫 This command is only for the bot owner! 💔',
  already_on: () => '🌟 The bot is already activated!',
  already_off: () => '🌙 The bot is already deactivated!',
  bot_on: () => '✅ *Bot activated!* Now everyone can use the commands.',
  bot_off: () => '✅ *Bot deactivated!* Only the owner can use commands.',
  error: () => '🐝 Oh no! An unexpected error occurred. Please try again in a bit! 🥺'
},
plugin_getplugin: {
  only_owner: () => '🚫 This command is only for the bot owner! 💔',
  no_command: (prefix) => `❌ Please provide the command name. Example: ${prefix}getplugin menu`,
  command_not_found: (cmd) => `❌ The command *${cmd}* was not found in any plugin!`,
  error: () => '🐝 Oh no! An unexpected error occurred. Please try again in a bit! 🥺'
},
plugin_infoserver: {
  only_owner: () => '🚫 This command is only for the bot owner! 💔',
  server_info: (nomebot, data) => `🌸 ═════════════════════ 🌸\n    *SERVER INFORMATION - ${nomebot}*\n🌸 ═════════════════════ 🌸\n\n` +
    `🖥️ *Operating System:* 🏠\n` +
    `├ 🟢 Node.js: ${data.nodeVersion}\n` +
    `├ 💻 Platform: ${data.platform}\n` +
    `├ 🏗️ Architecture: ${data.arch}\n` +
    `├ 🔧 Type: ${data.type}\n` +
    `├ 📋 Release: ${data.release}\n` +
    `├ 🏷️ Hostname: ${data.hostname}\n` +
    `├ 🔄 Endianness: ${data.endianness}\n` +
    `├ ⏳ System Uptime: ${data.osUptime} hours\n` +
    `└ 📅 Current Time: ${data.currentTime}\n\n` +
    `⚡ *Processor (CPU):* 🧠\n` +
    `├ 🔢 Cores: ${data.cpuCount}\n` +
    `├ 🏷️ Model: ${data.cpuModel}\n` +
    `├ 👤 User Time: ${data.cpuUser}s\n` +
    `├ ⚙️ System Time: ${data.cpuSystem}s\n` +
    `├ 📈 Current CPU Usage: ${data.cpuPercent}%\n` +
    `├ 📊 Load 1min: ${data.loadAvg[0].toFixed(2)}\n` +
    `├ 📈 Load 5min: ${data.loadAvg[1].toFixed(2)}\n` +
    `└ 📉 Load 15min: ${data.loadAvg[2].toFixed(2)}\n\n` +
    `💾 *System Memory:* 🧠\n` +
    `├ 🆓 Free RAM: ${data.freeMemory} GB\n` +
    `├ 📊 Total RAM: ${data.totalMemory} GB\n` +
    `├ 📈 Used RAM: ${data.usedMemory} GB\n` +
    `└ ${data.memoryEmoji} Usage: [${data.memoryBar}] ${data.memoryUsagePercent}%\n\n` +
    `🤖 *Bot Memory:* 💖\n` +
    `├ 🧠 Heap Used: ${data.botMemUsed} MB\n` +
    `├ 📦 Heap Total: ${data.botMemTotal} MB\n` +
    `├ 🏠 RSS: ${data.botMemRss} MB\n` +
    `├ 🔗 External: ${data.botMemExternal} MB\n` +
    `└ ${data.botMemoryEmoji} Efficiency: [${data.botMemoryBar}] ${data.botMemoryUsagePercent}%\n\n` +
    `🌐 *Network and Connectivity:* 🔗\n` +
    `├ 🔌 Interfaces: ${data.networkInterfaces}\n` +
    `${data.networkDetails}` +
    `├ 📡 Status: ${data.networkStatus}\n` +
    `├ ⏱️ Network Latency: ${data.networkLatency}\n` +
    `└ 🛡️ Firewall: ${data.firewallStatus}\n\n` +
    `💽 *Storage:* 💿\n` +
    `├ 🆓 Free: ${data.diskFree} GB\n` +
    `├ 📊 Total: ${data.diskTotal} GB\n` +
    `├ 📈 Used: ${data.diskUsed} GB\n` +
    `└ ${data.diskEmoji} Usage: [${data.diskBar}] ${data.diskUsagePercent}%\n\n` +
    `⏰ *Time and Latency:* 🕐\n` +
    `├ ⏱️ Bot Latency: ${data.latency}ms\n` +
    `└ 🚀 Bot Uptime: ${data.botUptime}`,
  error: () => '🐝 Oh no! An unexpected error occurred. Please try again in a bit! 🥺'
},
plugin_viewmsg: {
  only_owner: () => '🚫 This command is only for the bot owner! 💔',
  invalid_usage: (prefix) => `🤔 Use: ${prefix}viewmsg [on/off]`,
  viewmsg_on: () => '✅ Message viewing activated!',
  viewmsg_off: () => '✅ Message viewing deactivated!',
  error: () => '😥 An error occurred while changing the message viewing setting.'
},
plugin_modoaluguel: {
  only_main_owner: () => '🚫 Only the main owner can manage rental mode!',
  invalid_usage: (prefix, status) => `🤔 Usage: ${prefix}rentalmode on|off\nCurrent status: ${status}`,
  rental_mode_on: () => '✅ Global rental mode ACTIVATED! The bot will now only respond in groups with active rental.',
  rental_mode_off: () => '✅ Global rental mode DEACTIVATED! The bot will respond in all allowed groups.',
  error_set_mode: () => '❌ Error changing the global rental mode.',
  error: () => '❌ An unexpected error occurred.'
},
plugin_listaluguel: {
  only_owner: () => '🚫 This command is only for the bot owner! 💔',
  header: (nomebot, globalMode, groupCount) => `╭───「 *Rental List - ${nomebot}* 」───╮\n│ 🌍 *Global Rental Mode*: ${globalMode}\n│ 📊 *Total Groups*: ${groupCount}\n╰────────────────╯\n`,
  no_groups: () => '📪 No groups with registered rentals.',
  group_entry: (index, groupName, status, expires) => `🔹 *${index}. ${groupName}*\n  - *Status*: ${status}\n  - *Expires on*: ${expires}\n\n`,
  no_groups_filtered: () => '📪 No groups found with this filter.',
  invalid_filter: (prefix) => `🤔 Invalid filter! Use: ${prefix}listrentals [ven|atv|perm]`,
  error: () => '❌ An error occurred while listing rentals 💔'
},
plugin_addaluguel: {
  only_owner: () => '🚫 Only the main owner can add rentals!',
  only_group: () => '🚫 This command can only be used in groups.',
  invalid_duration: (prefix) => `🤔 Invalid duration. Use a number of days (e.g., 30) or the word "permanent".\nExample: ${prefix}addaluguel 30`,
  success: (groupName, duration) => `✅ Rental added for the group *${groupName}*! Duration: ${duration}.`,
  error_add: () => '❌ Error adding the rental to the group.',
  error: () => '❌ An unexpected error occurred while adding the rental.',
  permanent: () => 'Permanent',
  days: () => 'days'
},
plugin_gerarcodigo: {
  only_owner: () => '🚫 Only the main owner can generate codes!',
  invalid_usage: (prefix) => `🤔 Usage: ${prefix}generatecode <days|permanent> [optional_group_id]`,
  invalid_duration: () => '🤔 Invalid duration. Use a number of days (e.g., 7) or the word "permanent".',
  invalid_group_id: () => '🤔 Invalid target group ID. Provide the full ID (number@g.us) or leave blank for a generic code.',
  success: (code, duration) => `✅ Code generated: *${code}*\nDuration: ${duration}`,
  target_group: (groupName, groupId) => `\nTarget group: *${groupName}* (${groupId})`,
  no_target_group: () => '\nTarget group: Any group',
  error_generate: () => '❌ Error generating the activation code.',
  error: () => '❌ An unexpected error occurred while generating the code.',
  permanent: () => 'Permanent',
  days: () => 'days'
},
plugin_entrar: {
  only_owner: () => '🚫 This command is only for my owner! 💔',
  invalid_link: (prefix) => `🤔 Enter a valid invite link! Example: ${prefix}join https://chat.whatsapp.com/...`,
  success: (groupName) => `✅ Successfully joined the group *${groupName}*!`,
  error_join: () => '❌ Error joining the group. Invalid link, permission denied, or bot is already in the group.',
  error: () => '❌ An unexpected error occurred while trying to join the group.'
},
plugin_modoliteglobal: {
  only_owner: () => '🚫 This command is only for my owner! 💔',
  lite_enabled: () => '👶 *Lite Mode enabled globally!* Inappropriate content for children will be filtered in all groups (unless explicitly disabled in some groups).',
  lite_disabled: () => '🔞 *Lite Mode disabled globally!* The playful menu content will be fully displayed (unless explicitly enabled in some groups).',
  error: () => '❌ An unexpected error occurred while changing the lite mode.'
}
};
