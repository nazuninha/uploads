// [ By Hiudy ] -- FR

module.exports = {
  // config.js || By Hiudy
  invalid_prefix: "❌ Le préfixe doit comporter exactement 1 caractère.",
  invalid_number: "❌ Le numéro doit contenir uniquement des chiffres (10-15 caractères).",
  example_number: "Exemple : 553399285117 (sans symboles ni espaces)",
  invalid_language: (valid) => `❌ Langue invalide, les langues disponibles sont : ${valid.join(',')}`,
  config_cancelled: "🛑 Opération annulée par l'utilisateur.",
  installing_dependencies: "📦 Installation des dépendances...",
  install_complete: "✔ Installation terminée ! Exécutez 'npm start' pour lancer le bot.",
  install_error: (message) => `❌ Erreur lors de l'installation : ${message}`,
  manual_install_info: "ℹ️ Vous pouvez essayer d'installer manuellement avec : npm install --force --no-bin-links",
  config_welcome: (version) => `🔧 Configurateur de Nazuna - v${version}`,
  creator_message: "🚀 Créé par Hiudy",
  existing_config_loaded: "ℹ️ Configuration existante chargée.",
  error_reading_config: (message) => `⚠ Erreur lors de la lecture de la configuration existante : ${message}`,
  using_default_values: "ℹ️ Utilisation des valeurs par défaut.",
  basic_config_title: "CONFIGURATION DE BASE",
  ask_owner_name: "👤 Quel est votre nom ?",
  ask_owner_number: "📞 Quel est votre numéro (chiffres uniquement, 10-15) ?",
  ask_bot_name: "🤖 Quel est le nom du bot ?",
  ask_prefix: "⚙️ Quel est le préfixe (1 caractère) ?",
  ask_language: "⚒️ Quelle est la langue du bot ? (pt, en, es, id, fr)",
  config_summary: "📋 Résumé de la configuration :",
  owner_name_summary: (name) => `Nom du propriétaire : ${name}`,
  owner_number_summary: (number) => `Numéro du propriétaire : ${number}`,
  bot_name_summary: (name) => `Nom du bot : ${name}`,
  prefix_summary: (prefix) => `Préfixe du bot : ${prefix}`,
  language_summary: (lang) => `Langue du bot : ${lang}`,
  config_saved_success: "🎉 Configuration terminée avec succès !",
  ask_install_deps: "📦 Installer les dépendances maintenant ?",
  install_later_info: "⚡ Pour installer plus tard, utilisez : npm run config:install",
  nazuna_ready: (version) => `🚀 Nazuna prête à l'utilisation ! - v${version}`,
  error_saving_config: (message) => `❌ Erreur lors de l'enregistrement de la configuration : ${message}`,
  unexpected_error: (message) => `❌ Erreur inattendue : ${message}`,
  prompt_input_current: (value) => `(Actuel : ${value || 'Non défini'})`,
  fatal_error: (message) => `❌ Erreur fatale : ${message}`,
  
  // start.js || By Hiudy
  shutting_down: "🛑 Arrêt du bot...",
  starter_header: "🚀 Lanceur de Nazuna 🚀",
  starter_version: (version) => `🔧 Créé par Hiudy - Version : ${version} 🔧`,
  config_not_found: "⚠ Oups ! Il semble que vous n'ayez pas encore configuré le bot.",
  run_config_command: (command) => `🔹 Pour configurer, exécutez : ${command}`,
  modules_not_found: "⚠ Oups ! Il semble que les modules n'aient pas encore été installés.",
  run_install_command: (command) => `📦 Pour installer, exécutez : ${command}`,
  connection_file_not_found: (file) => `⚠ Fichier de connexion introuvable : ${file}`,
  check_installation: "Vérifiez si le bot a été installé correctement.",
  starting_with_code: (dualMode) => `🚀 Lancement du bot avec code${dualMode ? ' (mode dual)' : ''}...`,
  starting_with_qrcode: (dualMode) => `🚀 Lancement du bot avec QR Code${dualMode ? ' (mode dual)' : ''}...`,
  error_starting_process: (message) => `❌ Erreur lors du démarrage du processus : ${message}`,
  bot_crashed: (code) => `⚠ Le bot a planté avec le code : ${code}`,
  many_restarts: (count, seconds) => `⚠ Trop de redémarrages (${count}). Attente de ${seconds} secondes...`,
  restarting_bot: (seconds) => `⚠ Le bot a planté ! Redémarrage dans ${seconds} secondes...`,
  error_checking_qr: (message) => `❌ Erreur lors de la vérification du répertoire QR Code : ${message}`,
  ask_connection_method: "🔗 Comment souhaitez-vous connecter le bot ?",
  qr_code_connection: "1. Connexion par QR Code",
  code_connection: "2. Connexion par code",
  exit_option: "3. Quitter",
  choose_option: "Choisissez une option (1/2/3) : ",
  starting_qr_connection: "📡 Lancement de la connexion par QR Code...",
  starting_code_connection: "🔑 Lancement de la connexion par code...",
  exiting: "👋 Quitter...",
  invalid_option_qr_default: "❌ Option invalide ! Utilisation du QR Code par défaut.",
  qr_detected_auto_connect: "📡 QR Code déjà détecté ! Lancement de la connexion automatique...",

  // update.js || By Hiudy
  updater_header: "Mise à jour de Nazuna",
  checking_requirements: "Vérification des prérequis...",
  git_found: "✔ Git trouvé.",
  git_not_found: "❌ Git non trouvé. Git est requis pour continuer.",
  git_download_win: "ℹ️ Téléchargez et installez Git pour Windows sur : https://git-scm.com/download/win",
  git_install_mac: "ℹ️ Installez Git sur macOS via Homebrew ('brew install git') ou Xcode Command Line Tools.",
  git_install_linux: "ℹ️ Installez Git sur Linux en utilisant le gestionnaire de paquets de votre distribution (ex : 'sudo apt-get install git').",
  npm_found: "✔ NPM trouvé.",
  npm_not_found: "❌ NPM non trouvé. NPM est requis pour installer les dépendances.",
  npm_download: "ℹ️ NPM est inclus avec Node.js. Téléchargez et installez sur : https://nodejs.org/",
  requirements_met: "✔ Tous les prérequis sont remplis.",
  update_warning: "ATTENTION : Ce processus remplacera les fichiers actuels du bot par la version la plus récente.",
  backup_info: "ℹ️ Une sauvegarde automatique de 'config.json', 'database' et 'médias' sera créée.",
  cancel_info: "Vous pouvez annuler à tout moment en appuyant sur CTRL+C.",
  starting_in: (countdown) => `Lancement de la mise à jour dans ${countdown} secondes...`,
  proceeding_with_update: "🚀 Poursuite de la mise à jour...",
  creating_backup: "📦 Création d'une sauvegarde de vos données...",
  copying_database: "Copie de la base de données...",
  copying_config: "Copie du fichier de configuration...",
  copying_media: "Copie des fichiers multimédias...",
  backup_saved_at: (dir) => `✔ Sauvegarde enregistrée avec succès dans : ${dir}`,
  error_creating_backup: (msg) => `❌ Erreur lors de la création de la sauvegarde : ${msg}`,
  downloading_latest_version: "📥 Téléchargement de la dernière version du dépôt...",
  cloning_repo: "Clonage du dépôt...",
  downloading: "Téléchargement...",
  download_complete: "✔ Téléchargement terminé.",
  failed_to_download: (msg) => `❌ Échec du téléchargement de la mise à jour : ${msg}`,
  checking_github_connectivity: "Vérification de la connectivité avec GitHub...",
  permission_or_git_config_error: "Il peut s'agir d'une erreur de permissions ou de configuration Git. Essayez d'exécuter le terminal en tant qu'administrateur.",
  internet_connection_error: "Il semble y avoir un problème de connexion Internet.",
  cleaning_old_files: "🧹 Nettoyage des anciens fichiers...",
  removing_git_dir: "Suppression de l'ancien répertoire .git...",
  removing_package_json: "Suppression de l'ancien package.json...",
  removing_package_lock: "Suppression de l'ancien package-lock.json...",
  cleaning_data_dir: "Nettoyage du répertoire de données (sauf sauvegardes)...",
  cleaning_complete: "✔ Nettoyage terminé.",
  error_cleaning_files: (msg) => `❌ Erreur lors du nettoyage des anciens fichiers : ${msg}`,
  applying_update: "⬆️ Application de la mise à jour...",
  copying_dir: (dir) => `Copie du répertoire : ${dir}`,
  files_copied: (copied, total) => `Fichiers copiés : ${copied} sur ${total}`,
  update_applied_success: "✔ Mise à jour appliquée avec succès.",
  error_applying_update: (msg) => `❌ Erreur lors de l'application de la mise à jour : ${msg}`,
  restoring_backup: "🗂️ Restauration de la sauvegarde...",
  restoring_database: "Restauration de la base de données...",
  restoring_config: "Restauration du fichier de configuration...",
  restoring_media: "Restauration des fichiers multimédias...",
  restore_success: "✔ Sauvegarde restaurée avec succès.",
  error_restoring_backup: (msg) => `❌ Erreur lors de la restauration de la sauvegarde : ${msg}`,
  installing_deps: "📦 Installation des nouvelles dépendances...",
  deps_installed_success: "✔ Dépendances installées avec succès.",
  failed_to_install_deps: (msg) => `❌ Échec de l'installation des dépendances : ${msg}`,
  manual_install_prompt: "Essayez d'installer manuellement avec 'npm install'.",
  finishing_up: "✨ Finalisation...",
  removing_backup_dir: "Suppression du répertoire de sauvegarde temporaire...",
  backup_removed: "Sauvegarde temporaire supprimée.",
  error_cleaning_temp_files: (msg) => `❌ Erreur lors du nettoyage des fichiers temporaires : ${msg}`,
  progress: (completed, total) => `Progression : [${completed}/${total}]`,
  fetching_commit_info: "🔍 Récupération des informations sur la dernière mise à jour...",
  error_fetching_commits: (status) => `❌ Erreur lors de la récupération des informations de commit : ${status}`,
  update_complete_success: "🎉 Mise à jour terminée avec succès !",
  start_bot_prompt: "Vous pouvez maintenant démarrer le bot avec 'npm start'.",
  error_during_update: (msg) => `❌ Une erreur critique s'est produite pendant la mise à jour : ${msg}`,
  backup_location_info: (dir) => `ℹ️ Vos données importantes (config, database, médias) ont été enregistrées dans : ${dir}`,
  manual_restore_info: "Vous pouvez les restaurer manuellement en déplaçant les fichiers du dossier de sauvegarde vers le dossier 'données'.",
  contact_dev_for_help: "Si le problème persiste, contactez le développeur.",
  
  // connect.js || By Hiudy
  invalid_number: "❌ Numéro invalide ! Doit comporter entre 10 et 15 chiffres.",
  ask_phone_number: "📞 Entrez votre numéro (avec l'indicatif du pays et de la région, ex. : +5511999999999) : \n\n",
  pairing_code: (code) => `🔢 Votre code de jumelage : ${code}`,
  pairing_instructions: "📲 Sur WhatsApp, allez dans 'Appareils connectés' -> 'Connecter avec un numéro de téléphone' et entrez le code.\n",
  bot_started: (nomebot, prefixo, nomedono, dualMode) => `
============================================
Bot : ${nomebot}
Préfixe : ${prefixo}
Propriétaire : ${nomedono}
Créateur : Hiudy
============================================
    ✅ BOT DÉMARRÉ AVEC SUCCÈS${dualMode ? ' (MODE DUAL)' : ''}
============================================`,
  starting_nazuna: (dualMode) => `🚀 Démarrage de Nazuna ${dualMode ? '(Mode Dual)' : '(Mode Simple)'}...`,
  starting_dual_mode: "🔀 Mode Dual activé - Démarrage de la connexion secondaire...",
  dual_mode_ready: "🔀 Les deux connexions sont établies - Mode dual prêt !",
  secondary_connection_established: "🔀 Connexion secondaire établie avec succès !",
  secondary_connection_closed: (reason) => `🔀 Connexion secondaire fermée, raison : ${reason}`,
  reconnecting_secondary: "🔀 Tentative de reconnexion de la connexion secondaire...",
  error_starting_secondary: (err) => `🔀 Erreur lors du démarrage de la connexion secondaire : ${err}`,
  continuing_primary_only: "🔀 Poursuite uniquement avec la connexion primaire...",
  error_starting_bot: (err) => `❌ Erreur lors du démarrage du bot : ${err}`,
  primary_connection_closed: (reason, message) => `⚠️ Connexion primaire fermée, raison : ${reason} - ${message}`,
  reconnecting_primary: "🔄 Tentative de reconnexion de la connexion primaire...",
  updating_primary_session: "🔄 Mise à jour de la session primaire...",
  connecting_secondary_session: "🔀 Connexion de la session secondaire...",
  invalid_index_module: "❌ Le module index.js n'exporte pas une fonction valide.",
  error_processing_poll: (err) => `❌ Erreur lors du traitement de la mise à jour du sondage : ${err}`,
  error_calling_index: (err) => `❌ Erreur lors de l'appel du module index.js : ${err}`,
  error_removing_blacklist_user: (from, err) => `❌ Erreur lors de la suppression d'un utilisateur en liste noire du groupe ${from} : ${err}`,
  error_sending_welcome: (from, err) => `❌ Erreur lors de l'envoi du message de bienvenue dans le groupe ${from} : ${err}`,
  error_sending_exit: (from, err) => `❌ Erreur lors de l'envoi du message de sortie dans le groupe ${from} : ${err}`,
  x9_mode_message: (participant, action, by) => `🕵️ *Mode X9* 🕵️\n\n@${participant} a été ${action} par @${by} !`,
  antifake_remove_message: (participant) => `🚫 @${participant} a été retiré car provenant d'un pays non autorisé (antifake activé) !`,
  antipt_remove_message: (participant) => `🚫 @${participant} a été retiré car provenant du Portugal (antipt activé) !`,
  blacklist_remove_message: (participant, reason) => `🚫 @${participant} a été retiré automatiquement car il est sur la liste noire.\nRaison : ${reason}`,
  welcome_message: (text, sender) => ({
    default: `Bienvenue @${sender} dans #nomedogp# !\nVous êtes notre membre numéro : *#membros#* !`,
    custom: (text) => text,
  }),
  exit_message: (text, sender) => ({
    default: `Adieu @${sender} ! 👋\nLe groupe *#nomedogp#* compte désormais *#membros#* membres.`,
    custom: (text) => text,
  }),
  reason_messages: {
    401: "🗑️ Session invalide, suppression de l'authentification...",
    408: "⏰ La session a expiré, rechargement...",
    411: "📄 Le fichier de session semble incorrect, tentative de rechargement...",
    428: "📡 Impossible de maintenir la connexion avec WhatsApp, nouvelle tentative...",
    440: "🔗 Trop de sessions connectées, fermez-en quelques-unes...",
    500: "⚙️ La session semble mal configurée, tentative de reconnexion...",
    503: "❓ Erreur inconnue, tentative de reconnexion...",
    515: "🔄 Redémarrage du code pour stabiliser la connexion...",
  },
plugin_config: {
  only_owner: () => '⚠️ Désolé, cette commande est réservée à mon propriétaire ! 😎',
  usage_prefixo: (prefix, command) => `Tapez un préfixe cool ! Exemple : ${prefix}${command} #`,
  usage_numerodono: (prefix, command) => `Veuillez indiquer le numéro du propriétaire ! Exemple : ${prefix}${command} 55123456789`,
  usage_nomedono: (prefix, command) => `Quel est le nom du propriétaire ? Exemple : ${prefix}${command} Jean`,
  usage_nomebot: (prefix, command) => `Donnez un nom génial au bot ! Exemple : ${prefix}${command} SuperBot`,
  usage_language: (prefix, command) => `Choisissez une langue ! Exemple : ${prefix}${command} fr (options : en, pt, es, fr, id)`,
  success_prefixo: (value) => `✨ Préfixe mis à jour à *${value}* ! Prêt à l’emploi ! 🚀`,
  success_numerodono: (value) => `📱 Numéro du propriétaire mis à jour à *${value}* ! Tout est bon ! ✅`,
  success_nomedono: (value) => `👑 Nom du propriétaire mis à jour à *${value}* ! Parfait ! 😊`,
  success_nomebot: (value) => `🤖 Le bot s’appelle maintenant *${value}* ! Nom super ! 🎉`,
  success_language: (value) => `🌍 Langue changée à *${value}* ! Prêt à discuter ! 🗣️`,
  error: () => '😥 Oups, quelque chose a mal tourné ! Réessayez, s’il vous plaît ! 💔',
  invalid_prefix: () => '⚠️ Le préfixe doit avoir entre 1 et 5 caractères. Essayez quelque chose comme ! ou # !',
  invalid_phone: () => '⚠️ Numéro invalide ! Utilisez uniquement des chiffres, entre 10 et 15 (ex. : 55123456789).',
  invalid_name: () => '⚠️ Le nom doit avoir entre 1 et 50 caractères. Faites briller ! 😊',
  invalid_language: () => '⚠️ Langue invalide ! Choisissez parmi : en, pt, es, fr, id.'
},
plugin_owner_admin: {
  only_owner: () => '⚠️ Désolé, cette commande est réservée à mon propriétaire ! 😎',
  only_group: () => '🚫 Cette commande ne fonctionne que dans les groupes ! Essayez dans un groupe, s’il vous plaît ! 🗣️',
  success_seradm: (prefix, command) => `🎉 Vous êtes maintenant admin ! Utilisez vos pouvoirs avec sagesse ! 😎`,
  success_sermembro: (prefix, command) => `📌 Vous avez été rétrogradé à membre. Appelez-moi si besoin ! 😉`,
  error: (prefix, command) => `🐝 Oh non ! Une petite erreur s’est produite ici. Réessayez dans un instant, s’il vous plaît ! 🥺`
},
plugin_menu_media: {
  only_owner: () => '⚠️ Désolé, cette commande est réservée à mon propriétaire ! 😎',
  only_group: () => '🚫 Cette commande ne fonctionne que dans les groupes ! Essayez dans un groupe, s’il vous plaît ! 🗣️',
  no_media: (prefix, command) => `📸 Veuillez marquer une image ou une vidéo avec la commande : ${prefix}${command} (en citant le média)`,
  success: () => `✅ Média du menu mis à jour avec succès ! Prêt à briller ! ✨`,
  error: () => `😥 Oups, quelque chose a mal tourné lors de la mise à jour du média ! Réessayez, s’il vous plaît ! 💔`
},
plugin_group_ban: {
  only_owner: () => '⚠️ Désolé, cette commande est réservée à mon propriétaire ! 😎',
  only_group: () => '🚫 Cette commande ne fonctionne que dans les groupes ! Essayez dans un groupe, s’il vous plaît ! 🗣️',
  success_ban: () => '🚫 Groupe banni ! Seuls les utilisateurs premium ou mon propriétaire peuvent utiliser le bot ici maintenant. 🔒',
  success_unban: () => '✅ Groupe débanni ! Tout le monde peut utiliser le bot à nouveau. 🎉',
  error: () => '🐝 Oh non ! Une petite erreur s’est produite ici. Réessayez dans un instant, s’il vous plaît ! 🥺'
},
plugin_premium_manager: {
  only_owner: () => '⚠️ Désolé, cette commande est réservée à mon propriétaire ! 😎',
  only_group: () => '🚫 Cette commande ne fonctionne que dans les groupes ! Essayez dans un groupe, s’il vous plaît ! 🗣️',
  no_mention: (prefix, command) => `🙄 Mentionnez un utilisateur avec la commande : ${prefix}${command} @utilisateur`,
  user_already_premium: () => '🌟 L’utilisateur est déjà sur la liste premium !',
  user_not_premium: () => '❌ L’utilisateur n’est pas sur la liste premium.',
  group_already_premium: () => '🌟 Le groupe est déjà sur la liste premium !',
  group_not_premium: () => '❌ Le groupe n’est pas sur la liste premium.',
  success_add_user: (user) => `✅ @${user} a été ajouté(e) à la liste premium ! 🎉`,
  success_remove_user: (user) => `🫡 @${user} a été retiré(e) de la liste premium.`,
  success_add_group: () => `✅ Le groupe a été ajouté à la liste premium ! 🎉`,
  success_remove_group: () => `🫡 Le groupe a été retiré de la liste premium.`,
  premium_list: (users, groups) => `✨ *Liste des Membres Premium* ✨\n\n` +
    `👤 *Utilisateurs Premium* (${users.length})\n` +
    (users.length > 0 ? users.map((u, i) => `🔹 ${i + 1}. @${u.split('@')[0]}`).join('\n') : `   Aucun utilisateur premium trouvé.\n`) +
    `\n👥 *Groupes Premium* (${groups.length})\n` +
    (groups.length > 0 ? groups.join('\n') : `   Aucun groupe premium trouvé.\n`),
  error: () => '😥 Oups, quelque chose a mal tourné ! Réessayez, s’il vous plaît ! 💔'
},
plugin_subowner_manager: {
  only_main_owner: () => '🚫 Seuls le Propriétaire principal peut utiliser cette commande ! 😎',
  no_target: (prefix, command) => `🤔 Vous devez mentionner un utilisateur ou fournir le numéro complet (ex: ${prefix}${command} 5511999998888 ou @utilisateur)`,
  invalid_jid: () => '❌ ID d’utilisateur invalide. Utilisez le format complet (ex: 1234567890@s.whatsapp.net) ou mentionnez l’utilisateur.',
  already_subowner: () => '🌟 Cet utilisateur est déjà un sous-propriétaire ! Pas besoin de l’ajouter à nouveau. 😊',
  owner_cannot_be_subowner: () => '🤔 Le Propriétaire principal a déjà tous les superpouvoirs ! Il ne peut pas être ajouté comme sous-propriétaire. 😉',
  save_error: () => '😥 Oups ! J’ai eu un petit problème pour enregistrer la liste des sous-propriétaires. Réessayez, s’il vous plaît !',
  not_subowner: () => '🤔 Cet utilisateur n’est pas dans la liste des sous-propriétaires.',
  unexpected_error: () => '❌ Erreur inattendue lors du traitement de la liste des sous-propriétaires. 🤷',
  no_subowners: () => '✨ Aucun sous-propriétaire enregistré pour le moment.',
  success_add: (user) => `✅ @${user} a été ajouté(e) comme sous-propriétaire ! 🎉`,
  success_remove: (user) => `🫡 @${user} a été retiré(e) des sous-propriétaires.`,
  list_subowners: (list, mentions) => `👑 *Liste des Sous-Propriétaires Actuels :*\n\n${list}`,
  error: () => '❌ Oups, quelque chose a mal tourné ! Réessayez, s’il vous plaît ! 💔'
},
plugin_antipv_manager: {
  only_owner: () => '🚫 Cette commande est réservée au propriétaire du bot ! 💔',
  no_message: (prefix, command) => `🤔 Veuillez fournir le nouveau message pour l’antipv. Exemple : ${prefix}${command} Les commandes en privé sont désactivées !`,
  antipv_enabled: () => '✅ Antipv activé ! Le bot ignorera désormais les messages en privé.',
  antipv_disabled: () => '✅ Antipv désactivé ! Le bot répondra désormais normalement en privé.',
  antipv2_enabled: () => '✅ Antipv2 activé ! Le bot avertira désormais que les commandes ne fonctionnent qu’en groupe en privé.',
  antipv2_disabled: () => '✅ Antipv2 désactivé ! Le bot répondra désormais normalement en privé.',
  antipv3_enabled: () => '✅ Antipv3 activé ! Le bot bloquera désormais les utilisateurs qui utilisent des commandes en privé.',
  antipv3_disabled: () => '✅ Antipv3 désactivé ! Le bot répondra désormais normalement en privé.',
  message_updated: (message) => `✅ Message de l’antipv mis à jour : "${message}"`,
  error: () => '❌ Oups, quelque chose a mal tourné ! Réessayez, s’il vous plaît ! 💔'
},
plugin_global_block_manager: {
  only_owner: () => '🚫 Cette commande est réservée au propriétaire du bot ! 💔',
  no_command: (prefix, command) => `❌ Veuillez fournir la commande à bloquer/débloquer ! Ex. : ${prefix}${command} sticker`,
  no_user: () => '🤔 Mentionnez quelqu’un ou fournissez l’ID de l’utilisateur ! 🙄',
  command_already_blocked: (cmd) => `❌ La commande *${cmd}* est déjà bloquée !`,
  command_not_blocked: (cmd) => `❌ La commande *${cmd}* n’est pas bloquée !`,
  user_already_blocked: (user) => `❌ L’utilisateur @${user} est déjà bloqué !`,
  user_not_blocked: (user) => `❌ L’utilisateur @${user} n’est pas bloqué !`,
  default_reason: () => 'Non spécifié',
  command_blocked: (cmd, reason) => `✅ Commande *${cmd}* bloquée globalement !\nRaison : ${reason}`,
  command_unblocked: (cmd) => `✅ Commande *${cmd}* débloquée globalement !`,
  user_blocked: (user, reason) => `✅ Utilisateur @${user} bloqué globalement !\nRaison : ${reason}`,
  user_unblocked: (user) => `✅ Utilisateur @${user} débloqué globalement !`,
  no_blocked_commands: () => 'Aucune commande bloquée.',
  no_blocked_users: () => 'Aucun utilisateur bloqué.',
  list_blocks: (nomebot, blockedCommands, blockedUsers) => `🔒 *Blocages Globaux - ${nomebot}* 🔒\n\n📜 *Commandes Bloquées* :\n${blockedCommands}\n\n👥 *Utilisateurs Bloqués* :\n${blockedUsers}`,
  error: () => '🐝 Oh non ! Une erreur inattendue s’est produite. Réessayez dans un instant, s’il vous plaît ! 🥺'
},
plugin_premium_manager: {
  only_owner: () => '🚫 Cette commande est réservée au propriétaire du bot ! 💔',
  no_user: () => '🤔 Mentionnez quelqu’un ou fournissez l’ID de l’utilisateur ! 🙄',
  only_group: () => '❌ Cette commande ne peut être utilisée que dans les groupes ! 💔',
  user_already_premium: (user) => `❌ L’utilisateur @${user} est déjà sur la liste premium !`,
  user_not_premium: (user) => `❌ L’utilisateur @${user} n’est pas sur la liste premium !`,
  group_already_premium: () => '❌ Le groupe est déjà sur la liste premium !',
  group_not_premium: () => '❌ Le groupe n’est pas sur la liste premium !',
  user_added: (user) => `✅ Utilisateur @${user} ajouté à la liste premium !`,
  user_removed: (user) => `🫡 Utilisateur @${user} retiré de la liste premium !`,
  group_added: () => '✅ Le groupe a été ajouté à la liste premium !',
  group_removed: () => '🫡 Le groupe a été retiré de la liste premium !',
  premium_list: (nomebot, usersPremiumText, groupsPremiumText, usersCount, groupsCount) => 
    `✨ *Liste des Membres Premium - ${nomebot}* ✨\n\n👤 *Utilisateurs Premium* (${usersCount})\n${usersPremiumText}\n\n👥 *Groupes Premium* (${groupsCount})\n${groupsPremiumText}`,
  no_premium_users: () => 'Aucun utilisateur premium trouvé.',
  no_premium_groups: () => 'Aucun groupe premium trouvé.',
  group_info_error: (groupId) => `Groupe ID : ${groupId} (impossible d’obtenir le nom)`,
  error: () => '😔 Oups, quelque chose s’est mal passé. Réessayez plus tard ! 💔'
},
plugin_group_list: {
  only_owner: () => '🚫 Cette commande est réservée au propriétaire du bot ! 💔',
  group_list: (nomebot, totalGroups, groupsText) => `🌟 *Liste des Groupes et Communautés - ${nomebot}* 🌟\n📊 *Total de Groupes:* ${totalGroups}\n\n${groupsText}`,
  no_groups: () => 'Aucun groupe trouvé.',
  group_entry: (index, subject, id, participantCount) => `🔹 *${index}. ${subject}*\n🆔 *ID:* ${id}\n👥 *Participants:* ${participantCount}\n\n`,
  error: () => '🐝 Oh non ! Une erreur inattendue s’est produite. Réessayez dans un instant, s’il vous plaît ! 🥺'
},
plugin_bot_state: {
  only_owner: () => '🚫 Cette commande est réservée au propriétaire du bot ! 💔',
  already_on: () => '🌟 Le bot est déjà activé !',
  already_off: () => '🌙 Le bot est déjà désactivé !',
  bot_on: () => '✅ *Bot activé !* Maintenant, tout le monde peut utiliser les commandes.',
  bot_off: () => '✅ *Bot désactivé !* Seul le propriétaire peut utiliser les commandes.',
  error: () => '🐝 Oh non ! Une erreur inattendue s’est produite. Réessayez dans un instant, s’il vous plaît ! 🥺'
},
plugin_getplugin: {
  only_owner: () => '🚫 Cette commande est réservée au propriétaire du bot ! 💔',
  no_command: (prefix) => `❌ Veuillez fournir le nom de la commande. Exemple : ${prefix}getplugin menu`,
  command_not_found: (cmd) => `❌ La commande *${cmd}* n’a pas été trouvée dans aucun plugin !`,
  error: () => '🐝 Oh non ! Une erreur inattendue s’est produite. Réessayez dans un instant, s’il vous plaît ! 🥺'
},
plugin_infoserver: {
  only_owner: () => '🚫 Cette commande est réservée au propriétaire du bot ! 💔',
  server_info: (nomebot, data) => `🌸 ═════════════════════ 🌸\n    *INFORMATIONS DU SERVEUR - ${nomebot}*\n🌸 ═════════════════════ 🌸\n\n` +
    `🖥️ *Système d'Exploitation:* 🏠\n` +
    `├ 🟢 Node.js: ${data.nodeVersion}\n` +
    `├ 💻 Plateforme: ${data.platform}\n` +
    `├ 🏗️ Architecture: ${data.arch}\n` +
    `├ 🔧 Type: ${data.type}\n` +
    `├ 📋 Version: ${data.release}\n` +
    `├ 🏷️ Nom d'hôte: ${data.hostname}\n` +
    `├ 🔄 Endianness: ${data.endianness}\n` +
    `├ ⏳ Système en ligne depuis: ${data.osUptime} heures\n` +
    `└ 📅 Heure actuelle: ${data.currentTime}\n\n` +
    `⚡ *Processeur (CPU):* 🧠\n` +
    `├ 🔢 Cœurs: ${data.cpuCount}\n` +
    `├ 🏷️ Modèle: ${data.cpuModel}\n` +
    `├ 👤 Temps utilisateur: ${data.cpuUser}s\n` +
    `├ ⚙️ Temps système: ${data.cpuSystem}s\n` +
    `├ 📈 Utilisation CPU actuelle: ${data.cpuPercent}%\n` +
    `├ 📊 Charge 1min: ${data.loadAvg[0].toFixed(2)}\n` +
    `├ 📈 Charge 5min: ${data.loadAvg[1].toFixed(2)}\n` +
    `└ 📉 Charge 15min: ${data.loadAvg[2].toFixed(2)}\n\n` +
    `💾 *Mémoire du Système:* 🧠\n` +
    `├ 🆓 RAM Libre: ${data.freeMemory} GB\n` +
    `├ 📊 RAM Totale: ${data.totalMemory} GB\n` +
    `├ 📈 RAM Utilisée: ${data.usedMemory} GB\n` +
    `└ ${data.memoryEmoji} Utilisation: [${data.memoryBar}] ${data.memoryUsagePercent}%\n\n` +
    `🤖 *Mémoire du Bot:* 💖\n` +
    `├ 🧠 Heap Utilisé: ${data.botMemUsed} MB\n` +
    `├ 📦 Heap Total: ${data.botMemTotal} MB\n` +
    `├ 🏠 RSS: ${data.botMemRss} MB\n` +
    `├ 🔗 Externe: ${data.botMemExternal} MB\n` +
    `└ ${data.botMemoryEmoji} Efficacité: [${data.botMemoryBar}] ${data.botMemoryUsagePercent}%\n\n` +
    `🌐 *Réseau et Connectivité:* 🔗\n` +
    `├ 🔌 Interfaces: ${data.networkInterfaces}\n` +
    `${data.networkDetails}` +
    `├ 📡 Statut: ${data.networkStatus}\n` +
    `├ ⏱️ Latence Réseau: ${data.networkLatency}\n` +
    `└ 🛡️ Pare-feu: ${data.firewallStatus}\n\n` +
    `💽 *Stockage:* 💿\n` +
    `├ 🆓 Libre: ${data.diskFree} GB\n` +
    `├ 📊 Total: ${data.diskTotal} GB\n` +
    `├ 📈 Utilisé: ${data.diskUsed} GB\n` +
    `└ ${data.diskEmoji} Utilisation: [${data.diskBar}] ${data.diskUsagePercent}%\n\n` +
    `⏰ *Temps et Latence:* 🕐\n` +
    `├ ⏱️ Latence du Bot: ${data.latency}ms\n` +
    `└ 🚀 Bot en ligne depuis: ${data.botUptime}`,
  error: () => '🐝 Oh non ! Une erreur inattendue s’est produite. Réessayez dans un instant, s’il vous plaît ! 🥺'
},
plugin_viewmsg: {
  only_owner: () => '🚫 Cette commande est réservée au propriétaire du bot ! 💔',
  invalid_usage: (prefix) => `🤔 Utilisez : ${prefix}viewmsg [on/off]`,
  viewmsg_on: () => '✅ Visualisation des messages activée !',
  viewmsg_off: () => '✅ Visualisation des messages désactivée !',
  error: () => '😥 Une erreur s’est produite lors du changement des paramètres de visualisation des messages.'
},
plugin_modoaluguel: {
  only_main_owner: () => '🚫 Seule le propriétaire principal peut gérer le mode de location !',
  invalid_usage: (prefix, status) => `🤔 Utilisation : ${prefix}modelocation on|off\nStatut actuel : ${status}`,
  rental_mode_on: () => '✅ Mode de location global ACTIVÉ ! Le bot ne répondra désormais que dans les groupes avec une location active.',
  rental_mode_off: () => '✅ Mode de location global DÉSACTIVÉ ! Le bot répondra dans tous les groupes autorisés.',
  error_set_mode: () => '❌ Erreur lors de la modification du mode de location global.',
  error: () => '❌ Une erreur inattendue s’est produite.'
},
plugin_listaluguel: {
  only_owner: () => '🚫 Cette commande est réservée au propriétaire du bot ! 💔',
  header: (nomebot, globalMode, groupCount) => `╭───「 *Liste des Locations - ${nomebot}* 」───╮\n│ 🌍 *Mode Location Global*: ${globalMode}\n│ 📊 *Total de Groupes*: ${groupCount}\n╰────────────────╯\n`,
  no_groups: () => '📪 Aucun groupe avec une location enregistrée.',
  group_entry: (index, groupName, status, expires) => `🔹 *${index}. ${groupName}*\n  - *Statut*: ${status}\n  - *Expire le*: ${expires}\n\n`,
  no_groups_filtered: () => '📪 Aucun groupe trouvé avec ce filtre.',
  invalid_filter: (prefix) => `🤔 Filtre invalide ! Utilisez : ${prefix}listlocations [ven|atv|perm]`,
  error: () => '❌ Une erreur s’est produite lors de la liste des locations 💔'
},
plugin_addaluguel: {
  only_owner: () => '🚫 Seule le propriétaire principal peut ajouter des locations !',
  only_group: () => '🚫 Cette commande ne peut être utilisée que dans les groupes.',
  invalid_duration: (prefix) => `🤔 Durée invalide. Utilisez un nombre de jours (ex : 30) ou le mot "permanente".\nExemple : ${prefix}ajouterlocation 30`,
  success: (groupName, duration) => `✅ Location ajoutée pour le groupe *${groupName}*! Durée : ${duration}.`,
  error_add: () => '❌ Erreur lors de l’ajout de la location au groupe.',
  error: () => '❌ Une erreur inattendue s’est produite lors de l’ajout de la location.',
  permanent: () => 'Permanente',
  days: () => 'jours'
},
plugin_gerarcodigo: {
  only_owner: () => '🚫 Seule le propriétaire principal peut générer des codes !',
  invalid_usage: (prefix) => `🤔 Utilisation : ${prefix}generercode <jours|permanente> [id_groupe_optionnel]`,
  invalid_duration: () => '🤔 Durée invalide. Utilisez un nombre de jours (ex : 7) ou le mot "permanente".',
  invalid_group_id: () => '🤔 ID de groupe cible invalide. Fournissez l’ID complet (numéro@g.us) ou laissez vide pour un code générique.',
  success: (code, duration) => `✅ Code généré : *${code}*\nDurée : ${duration}`,
  target_group: (groupName, groupId) => `\nGroupe cible : *${groupName}* (${groupId})`,
  no_target_group: () => '\nGroupe cible : N’importe quel groupe',
  error_generate: () => '❌ Erreur lors de la génération du code d’activation.',
  error: () => '❌ Une erreur inattendue s’est produite lors de la génération du code.',
  permanent: () => 'Permanente',
  days: () => 'jours'
},
plugin_entrar: {
  only_owner: () => '🚫 Cette commande est réservée à mon propriétaire ! 💔',
  invalid_link: (prefix) => `🤔 Entrez un lien d’invitation valide ! Exemple : ${prefix}rejoindre https://chat.whatsapp.com/...`,
  success: (groupName) => `✅ J’ai rejoint le groupe *${groupName}* avec succès !`,
  error_join: () => '❌ Erreur lors de l’entrée dans le groupe. Lien invalide, permission refusée ou le bot est déjà dans le groupe.',
  error: () => '❌ Une erreur inattendue s’est produite lors de la tentative d’entrée dans le groupe.'
},
plugin_modoliteglobal: {
  only_owner: () => '🚫 Cette commande est réservée à mon propriétaire ! 💔',
  lite_enabled: () => '👶 *Mode Lite activé globalement !* Le contenu inapproprié pour les enfants sera filtré dans tous les groupes (sauf s’il est explicitement désactivé dans certains groupes).',
  lite_disabled: () => '🔞 *Mode Lite désactivé globalement !* Le contenu du menu ludique sera affiché complètement (sauf s’il est explicitement activé dans certains groupes).',
  error: () => '❌ Une erreur inattendue s’est produite lors du changement du mode lite.'
}
};