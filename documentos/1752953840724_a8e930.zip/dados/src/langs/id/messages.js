// [ By Hiudy ] -- ID

module.exports = {
  // config.js || By Hiudy
  invalid_prefix: "❌ Awalan harus tepat 1 karakter.",
  invalid_number: "❌ Nomor harus hanya berisi angka (10-15 karakter).",
  example_number: "Contoh: 553399285117 (tanpa simbol atau spasi)",
  invalid_language: (valid) => `❌ Bahasa tidak valid, bahasa yang tersedia: ${valid.join(',')}`,
  config_cancelled: "🛑 Operasi dibatalkan oleh pengguna.",
  installing_dependencies: "📦 Menginstal dependensi...",
  install_complete: "✔ Instalasi selesai! Jalankan 'npm start' untuk memulai bot.",
  install_error: (message) => `❌ Kesalahan instalasi: ${message}`,
  manual_install_info: "ℹ️ Anda bisa mencoba menginstal secara manual dengan: npm install --force --no-bin-links",
  config_welcome: (version) => `🔧 Konfigurator Nazuna - v${version}`,
  creator_message: "🚀 Dibuat oleh Hiudy",
  existing_config_loaded: "ℹ️ Konfigurasi yang ada telah dimuat.",
  error_reading_config: (message) => `⚠ Kesalahan membaca konfigurasi yang ada: ${message}`,
  using_default_values: "ℹ️ Menggunakan nilai default.",
  basic_config_title: "KONFIGURASI DASAR",
  ask_owner_name: "👤 Siapa nama Anda?",
  ask_owner_number: "📞 Apa nomor Anda (hanya angka, 10-15)?",
  ask_bot_name: "🤖 Apa nama bot?",
  ask_prefix: "⚙️ Apa awalan (1 karakter)?",
  ask_language: "⚒️ Apa bahasa bot? (pt, en, es, id, fr)",
  config_summary: "📋 Ringkasan konfigurasi:",
  owner_name_summary: (name) => `Nama pemilik: ${name}`,
  owner_number_summary: (number) => `Nomor pemilik: ${number}`,
  bot_name_summary: (name) => `Nama bot: ${name}`,
  prefix_summary: (prefix) => `Awalan bot: ${prefix}`,
  language_summary: (lang) => `Bahasa bot: ${lang}`,
  config_saved_success: "🎉 Konfigurasi berhasil diselesaikan!",
  ask_install_deps: "📦 Instal dependensi sekarang?",
  install_later_info: "⚡ Untuk menginstal nanti, gunakan: npm run config:install",
  nazuna_ready: (version) => `🚀 Nazuna siap digunakan! - v${version}`,
  error_saving_config: (message) => `❌ Kesalahan menyimpan konfigurasi: ${message}`,
  unexpected_error: (message) => `❌ Kesalahan tak terduga: ${message}`,
  prompt_input_current: (value) => `(Saat ini: ${value || 'Tidak ditentukan'})`,
  fatal_error: (message) => `❌ Kesalahan fatal: ${message}`,
  
  // start.js || By Hiudy
  shutting_down: "🛑 Mematikan bot...",
  starter_header: "🚀 Pencetus Nazuna 🚀",
  starter_version: (version) => `🔧 Dibuat oleh Hiudy - Versi: ${version} 🔧`,
  config_not_found: "⚠ Ups! Sepertinya Anda belum mengkonfigurasi bot.",
  run_config_command: (command) => `🔹 Untuk mengkonfigurasi, jalankan: ${command}`,
  modules_not_found: "⚠ Ups! Sepertinya modul belum terinstal.",
  run_install_command: (command) => `📦 Untuk menginstal, jalankan: ${command}`,
  connection_file_not_found: (file) => `⚠ File koneksi tidak ditemukan: ${file}`,
  check_installation: "Periksa apakah bot telah terinstal dengan benar.",
  starting_with_code: (dualMode) => `🚀 Memulai bot dengan kode${dualMode ? ' (mode ganda)' : ''}...`,
  starting_with_qrcode: (dualMode) => `🚀 Memulai bot dengan QR Code${dualMode ? ' (mode ganda)' : ''}...`,
  error_starting_process: (message) => `❌ Kesalahan memulai proses: ${message}`,
  bot_crashed: (code) => `⚠ Bot crash dengan kode: ${code}`,
  many_restarts: (count, seconds) => `⚠ Terlalu banyak restart (${count}). Menunggu ${seconds} detik...`,
  restarting_bot: (seconds) => `⚠ Bot crash! Restart dalam ${seconds} detik...`,
  error_checking_qr: (message) => `❌ Kesalahan memeriksa direktori QR Code: ${message}`,
  ask_connection_method: "🔗 Bagaimana Anda ingin menghubungkan bot?",
  qr_code_connection: "1. Koneksi dengan QR Code",
  code_connection: "2. Koneksi dengan Kode",
  exit_option: "3. Keluar",
  choose_option: "Pilih opsi (1/2/3): ",
  starting_qr_connection: "📡 Memulai koneksi dengan QR Code...",
  starting_code_connection: "🔑 Memulai koneksi dengan Kode...",
  exiting: "👋 Keluar...",
  invalid_option_qr_default: "❌ Opsi tidak valid! Menggunakan QR Code sebagai default.",
  qr_detected_auto_connect: "📡 QR Code sudah terdeteksi! Memulai koneksi otomatis...",

  // update.js || By Hiudy
  updater_header: "Pembaruan Nazuna",
  checking_requirements: "Memeriksa prasyarat...",
  git_found: "✔ Git ditemukan.",
  git_not_found: "❌ Git tidak ditemukan. Git diperlukan untuk melanjutkan.",
  git_download_win: "ℹ️ Unduh dan instal Git untuk Windows di: https://git-scm.com/download/win",
  git_install_mac: "ℹ️ Instal Git di macOS melalui Homebrew ('brew install git') atau Xcode Command Line Tools.",
  git_install_linux: "ℹ️ Instal Git di Linux menggunakan pengelola paket distribusi Anda (mis: 'sudo apt-get install git').",
  npm_found: "✔ NPM ditemukan.",
  npm_not_found: "❌ NPM tidak ditemukan. NPM diperlukan untuk menginstal dependensi.",
  npm_download: "ℹ️ NPM disertakan dengan Node.js. Unduh dan instal di: https://nodejs.org/",
  requirements_met: "✔ Semua prasyarat telah terpenuhi.",
  update_warning: "PERHATIAN: Proses ini akan mengganti file bot saat ini dengan versi terbaru.",
  backup_info: "ℹ️ Cadangan otomatis dari 'config.json', 'database', dan 'media' akan dibuat.",
  cancel_info: "Anda bisa membatalkan kapan saja dengan menekan CTRL+C.",
  starting_in: (countdown) => `Memulai pembaruan dalam ${countdown} detik...`,
  proceeding_with_update: "🚀 Melanjutkan pembaruan...",
  creating_backup: "📦 Membuat cadangan data Anda...",
  copying_database: "Menyalin database...",
  copying_config: "Menyalin file konfigurasi...",
  copying_media: "Menyalin file media...",
  backup_saved_at: (dir) => `✔ Cadangan berhasil disimpan di: ${dir}`,
  error_creating_backup: (msg) => `❌ Kesalahan membuat cadangan: ${msg}`,
  downloading_latest_version: "📥 Mengunduh versi terbaru dari repositori...",
  cloning_repo: "Mengkloning repositori...",
  downloading: "Mengunduh...",
  download_complete: "✔ Unduhan selesai.",
  failed_to_download: (msg) => `❌ Gagal mengunduh pembaruan: ${msg}`,
  checking_github_connectivity: "Memeriksa konektivitas dengan GitHub...",
  permission_or_git_config_error: "Mungkin masalah izin atau konfigurasi Git. Coba jalankan terminal sebagai administrator.",
  internet_connection_error: "Sepertinya ada masalah koneksi internet.",
  cleaning_old_files: "🧹 Membersihkan file lama...",
  removing_git_dir: "Menghapus direktori .git lama...",
  removing_package_json: "Menghapus package.json lama...",
  removing_package_lock: "Menghapus package-lock.json lama...",
  cleaning_data_dir: "Membersihkan direktori data (kecuali cadangan)...",
  cleaning_complete: "✔ Pembersihan selesai.",
  error_cleaning_files: (msg) => `❌ Kesalahan membersihkan file lama: ${msg}`,
  applying_update: "⬆️ Menerapkan pembaruan...",
  copying_dir: (dir) => `Menyalin direktori: ${dir}`,
  files_copied: (copied, total) => `File disalin: ${copied} dari ${total}`,
  update_applied_success: "✔ Pembaruan berhasil diterapkan.",
  error_applying_update: (msg) => `❌ Kesalahan menerapkan pembaruan: ${msg}`,
  restoring_backup: "🗂️ Memulihkan cadangan...",
  restoring_database: "Memulihkan database...",
  restoring_config: "Memulihkan file konfigurasi...",
  restoring_media: "Memulihkan file media...",
  restore_success: "✔ Cadangan berhasil dipulihkan.",
  error_restoring_backup: (msg) => `❌ Kesalahan memulihkan cadangan: ${msg}`,
  installing_deps: "📦 Menginstal dependensi baru...",
  deps_installed_success: "✔ Dependensi berhasil diinstal.",
  failed_to_install_deps: (msg) => `❌ Gagal menginstal dependensi: ${msg}`,
  manual_install_prompt: "Coba instal secara manual dengan 'npm install'.",
  finishing_up: "✨ Menyelesaikan...",
  removing_backup_dir: "Menghapus direktori cadangan sementara...",
  backup_removed: "Cadangan sementara dihapus.",
  error_cleaning_temp_files: (msg) => `❌ Kesalahan membersihkan file sementara: ${msg}`,
  progress: (completed, total) => `Progres: [${completed}/${total}]`,
  fetching_commit_info: "🔍 Mengambil informasi pembaruan terakhir...",
  error_fetching_commits: (status) => `❌ Kesalahan mengambil informasi commit: ${status}`,
  update_complete_success: "🎉 Pembaruan selesai dengan sukses!",
  start_bot_prompt: "Anda sudah bisa memulai bot dengan 'npm start'.",
  error_during_update: (msg) => `❌ Terjadi kesalahan kritis selama pembaruan: ${msg}`,
  backup_location_info: (dir) => `ℹ️ Data penting Anda (config, database, media) telah disimpan di: ${dir}`,
  manual_restore_info: "Anda dapat memulihkannya secara manual dengan memindahkan file dari folder cadangan ke folder 'data'.",
  contact_dev_for_help: "Jika masalah berlanjut, hubungi pengembang.",
  
  // connect.js || By Hiudy
  invalid_number: "❌ Nomor tidak valid! Harus antara 10 hingga 15 digit.",
  ask_phone_number: "📞 Masukkan nomor Anda (dengan kode negara dan wilayah, mis.: +5511999999999): \n\n",
  pairing_code: (code) => `🔢 Kode penyandingan Anda: ${code}`,
  pairing_instructions: "📲 Di WhatsApp, buka 'Perangkat Tertaut' -> 'Tautkan dengan Nomor Telepon' dan masukkan kode.\n",
  bot_started: (nomebot, prefixo, nomedono, dualMode) => `
============================================
Bot: ${nomebot}
Prefiks: ${prefixo}
Pemilik: ${nomedono}
Pembuat: Hiudy
============================================
    ✅ BOT BERHASIL DIMULAI${dualMode ? ' (MODE DUAL)' : ''}
============================================`,
  starting_nazuna: (dualMode) => `🚀 Memulai Nazuna ${dualMode ? '(Mode Dual)' : '(Mode Tunggal)'}...`,
  starting_dual_mode: "🔀 Mode Dual diaktifkan - Memulai koneksi sekunder...",
  dual_mode_ready: "🔀 Kedua koneksi berhasil dibuat - Mode dual siap!",
  secondary_connection_established: "🔀 Koneksi sekunder berhasil dibuat!",
  secondary_connection_closed: (reason) => `🔀 Koneksi sekunder ditutup, alasan: ${reason}`,
  reconnecting_secondary: "🔀 Mencoba menyambungkan kembali koneksi sekunder...",
  error_starting_secondary: (err) => `🔀 Gagal memulai koneksi sekunder: ${err}`,
  continuing_primary_only: "🔀 Melanjutkan hanya dengan koneksi primer...",
  error_starting_bot: (err) => `❌ Gagal memulai bot: ${err}`,
  primary_connection_closed: (reason, message) => `⚠️ Koneksi primer ditutup, alasan: ${reason} - ${message}`,
  reconnecting_primary: "🔄 Mencoba menyambungkan kembali koneksi primer...",
  updating_primary_session: "🔄 Memperbarui sesi primer...",
  connecting_secondary_session: "🔀 Menghubungkan sesi sekunder...",
  invalid_index_module: "❌ Modul index.js tidak mengekspor fungsi yang valid.",
  error_processing_poll: (err) => `❌ Gagal memproses pembaruan jajak pendapat: ${err}`,
  error_calling_index: (err) => `❌ Gagal memanggil modul index.js: ${err}`,
  error_removing_blacklist_user: (from, err) => `❌ Gagal menghapus pengguna dalam daftar hitam dari grup ${from}: ${err}`,
  error_sending_welcome: (from, err) => `❌ Gagal mengirim pesan selamat datang di grup ${from}: ${err}`,
  error_sending_exit: (from, err) => `❌ Gagal mengirim pesan keluar di grup ${from}: ${err}`,
  x9_mode_message: (participant, action, by) => `🕵️ *Mode X9* 🕵️\n\n@${participant} telah ${action} oleh @${by}!`,
  antifake_remove_message: (participant) => `🚫 @${participant} dihapus karena berasal dari negara yang tidak diizinkan (antifake diaktifkan)!`,
  antipt_remove_message: (participant) => `🚫 @${participant} dihapus karena berasal dari Portugal (antipt diaktifkan)!`,
  blacklist_remove_message: (participant, reason) => `🚫 @${participant} dihapus secara otomatis karena berada di daftar hitam.\nAlasan: ${reason}`,
  welcome_message: (text, sender) => ({
    default: `Selamat datang @${sender} di #nomedogp#!\nAnda adalah anggota ke-*#membros#*!`,
    custom: (text) => text,
  }),
  exit_message: (text, sender) => ({
    default: `Selamat tinggal @${sender}! 👋\nGrup *#nomedogp#* sekarang memiliki *#membros#* anggota.`,
    custom: (text) => text,
  }),
  reason_messages: {
    401: "🗑️ Sesi tidak valid, menghapus autentikasi...",
    408: "⏰ Sesi habis waktu, memuat ulang...",
    411: "📄 File sesi tampak salah, mencoba memuat ulang...",
    428: "📡 Tidak dapat mempertahankan koneksi WhatsApp, mencoba lagi...",
    440: "🔗 Terlalu banyak sesi terhubung, tutup beberapa...",
    500: "⚙️ Sesi tampak salah dikonfigurasi, mencoba menyambungkan kembali...",
    503: "❓ Kesalahan tidak dikenal, mencoba menyambungkan kembali...",
    515: "🔄 Memulai ulang kode untuk menstabilkan koneksi...",
  },
plugin_config: {
  only_owner: () => '⚠️ Maaf, perintah ini hanya untuk pemilik saya! 😎',
  usage_prefixo: (prefix, command) => `Ketik prefiks keren! Contoh: ${prefix}${command} #`,
  usage_numerodono: (prefix, command) => `Harap masukkan nomor pemilik! Contoh: ${prefix}${command} 55123456789`,
  usage_nomedono: (prefix, command) => `Siapa nama pemiliknya? Contoh: ${prefix}${command} Budi`,
  usage_nomebot: (prefix, command) => `Beri nama keren untuk bot! Contoh: ${prefix}${command} SuperBot`,
  usage_language: (prefix, command) => `Pilih bahasa! Contoh: ${prefix}${command} id (opsi: en, pt, es, fr, id)`,
  success_prefixo: (value) => `✨ Prefiks diperbarui ke *${value}*! Siap digunakan! 🚀`,
  success_numerodono: (value) => `📱 Nomor pemilik diperbarui ke *${value}*! Semua beres! ✅`,
  success_nomedono: (value) => `👑 Nama pemilik diperbarui ke *${value}*! Sempurna! 😊`,
  success_nomebot: (value) => `🤖 Bot sekarang bernama *${value}*! Nama keren! 🎉`,
  success_language: (value) => `🌍 Bahasa diubah ke *${value}*! Siap mengobrol! 🗣️`,
  error: () => '😥 Ups, ada yang salah! Coba lagi, ya! 💔',
  invalid_prefix: () => '⚠️ Prefiks harus 1 sampai 5 karakter. Coba seperti ! atau #!',
  invalid_phone: () => '⚠️ Nomor tidak valid! Gunakan hanya angka, 10 sampai 15 digit (contoh: 55123456789).',
  invalid_name: () => '⚠️ Nama harus 1 sampai 50 karakter. Ayo buat keren! 😊',
  invalid_language: () => '⚠️ Bahasa tidak valid! Pilih dari: en, pt, es, fr, id.'
},
plugin_owner_admin: {
  only_owner: () => '⚠️ Maaf, perintah ini hanya untuk pemilik saya! 😎',
  only_group: () => '🚫 Perintah ini hanya berfungsi di grup! Coba di grup, ya! 🗣️',
  success_seradm: (prefix, command) => `🎉 Anda sekarang admin! Gunakan kekuatan Anda dengan bijak! 😎`,
  success_sermembro: (prefix, command) => `📌 Anda telah diturunkan menjadi anggota. Panggil saya jika perlu apa saja! 😉`,
  error: (prefix, command) => `🐝 Oh tidak! Ada kesalahan kecil di sini. Coba lagi sebentar lagi, ya! 🥺`
},
plugin_menu_media: {
  only_owner: () => '⚠️ Maaf, perintah ini hanya untuk pemilik saya! 😎',
  only_group: () => '🚫 Perintah ini hanya berfungsi di grup! Coba di grup, ya! 🗣️',
  no_media: (prefix, command) => `📸 Tandai gambar atau video dengan perintah: ${prefix}${command} (mengutip media)`,
  success: () => `✅ Media menu berhasil diperbarui! Siap bersinar! ✨`,
  error: () => `😥 Ups, ada yang salah saat memperbarui media! Coba lagi, ya! 💔`
},
plugin_group_ban: {
  only_owner: () => '⚠️ Maaf, perintah ini hanya untuk pemilik saya! 😎',
  only_group: () => '🚫 Perintah ini hanya berfungsi di grup! Coba di grup, ya! 🗣️',
  success_ban: () => '🚫 Grup diblokir! Hanya pengguna premium atau pemilik saya yang bisa menggunakan bot di sini sekarang. 🔒',
  success_unban: () => '✅ Grup dibuka! Semua orang bisa menggunakan bot lagi. 🎉',
  error: () => '🐝 Oh tidak! Ada kesalahan kecil di sini. Coba lagi sebentar lagi, ya! 🥺'
},
plugin_premium_manager: {
  only_owner: () => '⚠️ Maaf, perintah ini hanya untuk pemilik saya! 😎',
  only_group: () => '🚫 Perintah ini hanya berfungsi di grup! Coba di grup, ya! 🗣️',
  no_mention: (prefix, command) => `🙄 Tandai pengguna dengan perintah: ${prefix}${command} @pengguna`,
  user_already_premium: () => '🌟 Pengguna sudah ada di daftar premium!',
  user_not_premium: () => '❌ Pengguna tidak ada di daftar premium.',
  group_already_premium: () => '🌟 Grup sudah ada di daftar premium!',
  group_not_premium: () => '❌ Grup tidak ada di daftar premium.',
  success_add_user: (user) => `✅ @${user} telah ditambahkan ke daftar premium! 🎉`,
  success_remove_user: (user) => `🫡 @${user} telah dihapus dari daftar premium.`,
  success_add_group: () => `✅ Grup telah ditambahkan ke daftar premium! 🎉`,
  success_remove_group: () => `🫡 Grup telah dihapus dari daftar premium.`,
  premium_list: (users, groups) => `✨ *Daftar Anggota Premium* ✨\n\n` +
    `👤 *Pengguna Premium* (${users.length})\n` +
    (users.length > 0 ? users.map((u, i) => `🔹 ${i + 1}. @${u.split('@')[0]}`).join('\n') : `   Tidak ada pengguna premium ditemukan.\n`) +
    `\n👥 *Grup Premium* (${groups.length})\n` +
    (groups.length > 0 ? groups.join('\n') : `   Tidak ada grup premium ditemukan.\n`),
  error: () => '😥 Ups, ada yang salah! Coba lagi, ya! 💔'
},
plugin_subowner_manager: {
  only_main_owner: () => '🚫 Hanya Pemilik utama yang bisa menggunakan perintah ini! 😎',
  no_target: (prefix, command) => `🤔 Anda perlu menandai pengguna atau memberikan nomor lengkap (mis: ${prefix}${command} 5511999998888 atau @pengguna)`,
  invalid_jid: () => '❌ ID pengguna tidak valid. Gunakan format lengkap (mis: 1234567890@s.whatsapp.net) atau tandai pengguna.',
  already_subowner: () => '🌟 Pengguna ini sudah menjadi subpemilik! Tidak perlu ditambahkan lagi. 😊',
  owner_cannot_be_subowner: () => '🤔 Pemilik utama sudah memiliki semua kekuatan super! Tidak bisa ditambahkan sebagai subpemilik. 😉',
  save_error: () => '😥 Ups! Saya mengalami masalah kecil saat menyimpan daftar subpemilik. Coba lagi, ya!',
  not_subowner: () => '🤔 Pengguna ini tidak ada dalam daftar subpemilik.',
  unexpected_error: () => '❌ Kesalahan tak terduga saat memproses daftar subpemilik. 🤷',
  no_subowners: () => '✨ Tidak ada subpemilik yang terdaftar saat ini.',
  success_add: (user) => `✅ @${user} telah ditambahkan sebagai subpemilik! 🎉`,
  success_remove: (user) => `🫡 @${user} telah dihapus dari subpemilik.`,
  list_subowners: (list, mentions) => `👑 *Daftar Subpemilik Saat Ini:*\n\n${list}`,
  error: () => '❌ Ups, ada yang salah! Coba lagi, ya! 💔'
},
plugin_antipv_manager: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik bot! 💔',
  no_message: (prefix, command) => `🤔 Harap masukkan pesan baru untuk antipv. Contoh: ${prefix}${command} Perintah di privat dinonaktifkan!`,
  antipv_enabled: () => '✅ Antipv diaktifkan! Bot sekarang akan mengabaikan pesan di privat.',
  antipv_disabled: () => '✅ Antipv dinonaktifkan! Bot sekarang akan merespons normal di privat.',
  antipv2_enabled: () => '✅ Antipv2 diaktifkan! Bot sekarang akan memperingatkan bahwa perintah hanya berfungsi di grup di privat.',
  antipv2_disabled: () => '✅ Antipv2 dinonaktifkan! Bot sekarang akan merespons normal di privat.',
  antipv3_enabled: () => '✅ Antipv3 diaktifkan! Bot sekarang akan memblokir pengguna yang menggunakan perintah di privat.',
  antipv3_disabled: () => '✅ Antipv3 dinonaktifkan! Bot sekarang akan merespons normal di privat.',
  message_updated: (message) => `✅ Pesan antipv diperbarui menjadi: "${message}"`,
  error: () => '❌ Ups, ada yang salah! Coba lagi, ya! 💔'
},
plugin_global_block_manager: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik bot! 💔',
  no_command: (prefix, command) => `❌ Harap masukkan perintah untuk diblokir/dibuka! Contoh: ${prefix}${command} sticker`,
  no_user: () => '🤔 Tandai seseorang atau berikan ID pengguna! 🙄',
  command_already_blocked: (cmd) => `❌ Perintah *${cmd}* sudah diblokir!`,
  command_not_blocked: (cmd) => `❌ Perintah *${cmd}* tidak diblokir!`,
  user_already_blocked: (user) => `❌ Pengguna @${user} sudah diblokir!`,
  user_not_blocked: (user) => `❌ Pengguna @${user} tidak diblokir!`,
  default_reason: () => 'Tidak disebutkan',
  command_blocked: (cmd, reason) => `✅ Perintah *${cmd}* diblokir secara global!\nAlasan: ${reason}`,
  command_unblocked: (cmd) => `✅ Perintah *${cmd}* dibuka secara global!`,
  user_blocked: (user, reason) => `✅ Pengguna @${user} diblokir secara global!\nAlasan: ${reason}`,
  user_unblocked: (user) => `✅ Pengguna @${user} dibuka secara global!`,
  no_blocked_commands: () => 'Tidak ada perintah yang diblokir.',
  no_blocked_users: () => 'Tidak ada pengguna yang diblokir.',
  list_blocks: (nomebot, blockedCommands, blockedUsers) => `🔒 *Blokir Global - ${nomebot}* 🔒\n\n📜 *Perintah yang Diblokir*:\n${blockedCommands}\n\n👥 *Pengguna yang Diblokir*:\n${blockedUsers}`,
  error: () => '🐝 Oh tidak! Terjadi kesalahan tak terduga. Coba lagi sebentar lagi, ya! 🥺'
},
plugin_premium_manager: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik bot! 💔',
  no_user: () => '🤔 Tandai seseorang atau berikan ID pengguna! 🙄',
  only_group: () => '❌ Perintah ini hanya bisa digunakan di grup! 💔',
  user_already_premium: (user) => `❌ Pengguna @${user} sudah ada di daftar premium!`,
  user_not_premium: (user) => `❌ Pengguna @${user} tidak ada di daftar premium!`,
  group_already_premium: () => '❌ Grup sudah ada di daftar premium!',
  group_not_premium: () => '❌ Grup tidak ada di daftar premium!',
  user_added: (user) => `✅ Pengguna @${user} telah ditambahkan ke daftar premium!`,
  user_removed: (user) => `🫡 Pengguna @${user} telah dihapus dari daftar premium!`,
  group_added: () => '✅ Grup telah ditambahkan ke daftar premium!',
  group_removed: () => '🫡 Grup telah dihapus dari daftar premium!',
  premium_list: (nomebot, usersPremiumText, groupsPremiumText, usersCount, groupsCount) => 
    `✨ *Daftar Anggota Premium - ${nomebot}* ✨\n\n👤 *Pengguna Premium* (${usersCount})\n${usersPremiumText}\n\n👥 *Grup Premium* (${groupsCount})\n${groupsPremiumText}`,
  no_premium_users: () => 'Tidak ada pengguna premium yang ditemukan.',
  no_premium_groups: () => 'Tidak ada grup premium yang ditemukan.',
  group_info_error: (groupId) => `Grup ID: ${groupId} (tidak dapat mengambil nama)`,
  error: () => '😔 Ups, ada yang salah. Coba lagi nanti! 💔'
},
plugin_group_list: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik bot! 💔',
  group_list: (nomebot, totalGroups, groupsText) => `🌟 *Daftar Grup dan Komunitas - ${nomebot}* 🌟\n📊 *Total Grup:* ${totalGroups}\n\n${groupsText}`,
  no_groups: () => 'Tidak ada grup yang ditemukan.',
  group_entry: (index, subject, id, participantCount) => `🔹 *${index}. ${subject}*\n🆔 *ID:* ${id}\n👥 *Peserta:* ${participantCount}\n\n`,
  error: () => '🐝 Oh tidak! Terjadi kesalahan tak terduga. Coba lagi sebentar lagi, ya! 🥺'
},
plugin_bot_state: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik bot! 💔',
  already_on: () => '🌟 Bot sudah diaktifkan!',
  already_off: () => '🌙 Bot sudah dinonaktifkan!',
  bot_on: () => '✅ *Bot diaktifkan!* Sekarang semua orang bisa menggunakan perintah.',
  bot_off: () => '✅ *Bot dinonaktifkan!* Hanya pemilik yang bisa menggunakan perintah.',
  error: () => '🐝 Oh tidak! Terjadi kesalahan tak terduga. Coba lagi sebentar lagi, ya! 🥺'
},
plugin_getplugin: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik bot! 💔',
  no_command: (prefix) => `❌ Masukkan nama perintah. Contoh: ${prefix}getplugin menu`,
  command_not_found: (cmd) => `❌ Perintah *${cmd}* tidak ditemukan di plugin mana pun!`,
  error: () => '🐝 Oh tidak! Terjadi kesalahan tak terduga. Coba lagi sebentar lagi, ya! 🥺'
},
plugin_infoserver: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik bot! 💔',
  server_info: (nomebot, data) => `🌸 ═════════════════════ 🌸\n    *INFORMASI SERVER - ${nomebot}*\n🌸 ═════════════════════ 🌸\n\n` +
    `🖥️ *Sistem Operasi:* 🏠\n` +
    `├ 🟢 Node.js: ${data.nodeVersion}\n` +
    `├ 💻 Platform: ${data.platform}\n` +
    `├ 🏗️ Arsitektur: ${data.arch}\n` +
    `├ 🔧 Tipe: ${data.type}\n` +
    `├ 📋 Rilis: ${data.release}\n` +
    `├ 🏷️ Nama Host: ${data.hostname}\n` +
    `├ 🔄 Endianness: ${data.endianness}\n` +
    `├ ⏳ Sistem Online Selama: ${data.osUptime} jam\n` +
    `└ 📅 Waktu Saat Ini: ${data.currentTime}\n\n` +
    `⚡ *Prosesor (CPU):* 🧠\n` +
    `├ 🔢 Inti: ${data.cpuCount}\n` +
    `├ 🏷️ Model: ${data.cpuModel}\n` +
    `├ 👤 Waktu Pengguna: ${data.cpuUser}s\n` +
    `├ ⚙️ Waktu Sistem: ${data.cpuSystem}s\n` +
    `├ 📈 Penggunaan CPU Saat Ini: ${data.cpuPercent}%\n` +
    `├ 📊 Beban 1 menit: ${data.loadAvg[0].toFixed(2)}\n` +
    `├ 📈 Beban 5 menit: ${data.loadAvg[1].toFixed(2)}\n` +
    `└ 📉 Beban 15 menit: ${data.loadAvg[2].toFixed(2)}\n\n` +
    `💾 *Memori Sistem:* 🧠\n` +
    `├ 🆓 RAM Bebas: ${data.freeMemory} GB\n` +
    `├ 📊 RAM Total: ${data.totalMemory} GB\n` +
    `├ 📈 RAM Terpakai: ${data.usedMemory} GB\n` +
    `└ ${data.memoryEmoji} Penggunaan: [${data.memoryBar}] ${data.memoryUsagePercent}%\n\n` +
    `🤖 *Memori Bot:* 💖\n` +
    `├ 🧠 Heap Terpakai: ${data.botMemUsed} MB\n` +
    `├ 📦 Heap Total: ${data.botMemTotal} MB\n` +
    `├ 🏠 RSS: ${data.botMemRss} MB\n` +
    `├ 🔗 Eksternal: ${data.botMemExternal} MB\n` +
    `└ ${data.botMemoryEmoji} Efisiensi: [${data.botMemoryBar}] ${data.botMemoryUsagePercent}%\n\n` +
    `🌐 *Jaringan dan Konektivitas:* 🔗\n` +
    `├ 🔌 Antarmuka: ${data.networkInterfaces}\n` +
    `${data.networkDetails}` +
    `├ 📡 Status: ${data.networkStatus}\n` +
    `├ ⏱️ Latensi Jaringan: ${data.networkLatency}\n` +
    `└ 🛡️ Firewall: ${data.firewallStatus}\n\n` +
    `💽 *Penyimpanan:* 💿\n` +
    `├ 🆓 Bebas: ${data.diskFree} GB\n` +
    `├ 📊 Total: ${data.diskTotal} GB\n` +
    `├ 📈 Terpakai: ${data.diskUsed} GB\n` +
    `└ ${data.diskEmoji} Penggunaan: [${data.diskBar}] ${data.diskUsagePercent}%\n\n` +
    `⏰ *Waktu dan Latensi:* 🕐\n` +
    `├ ⏱️ Latensi Bot: ${data.latency}ms\n` +
    `└ 🚀 Bot Online Selama: ${data.botUptime}`,
  error: () => '🐝 Oh tidak! Terjadi kesalahan tak terduga. Coba lagi sebentar lagi, ya! 🥺'
},
plugin_viewmsg: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik bot! 💔',
  invalid_usage: (prefix) => `🤔 Gunakan: ${prefix}viewmsg [on/off]`,
  viewmsg_on: () => '✅ Penampilan pesan diaktifkan!',
  viewmsg_off: () => '✅ Penampilan pesan dinonaktifkan!',
  error: () => '😥 Terjadi kesalahan saat mengubah pengaturan penampilan pesan.'
},
plugin_modoaluguel: {
  only_main_owner: () => '🚫 Hanya pemilik utama yang dapat mengelola mode sewa!',
  invalid_usage: (prefix, status) => `🤔 Penggunaan: ${prefix}sewabot on|off\nStatus saat ini: ${status}`,
  rental_mode_on: () => '✅ Mode sewa global DIHIDUPKAN! Bot sekarang hanya akan menjawab di grup dengan sewa aktif.',
  rental_mode_off: () => '✅ Mode sewa global DIMATIKAN! Bot akan menjawab di semua grup yang diizinkan.',
  error_set_mode: () => '❌ Gagal mengubah mode sewa global.',
  error: () => '❌ Terjadi kesalahan tak terduga.'
},
plugin_listaluguel: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik bot! 💔',
  header: (nomebot, globalMode, groupCount) => `╭───「 *Daftar Sewa - ${nomebot}* 」───╮\n│ 🌍 *Mode Sewa Global*: ${globalMode}\n│ 📊 *Total Grup*: ${groupCount}\n╰────────────────╯\n`,
  no_groups: () => '📪 Tidak ada grup dengan sewa terdaftar.',
  group_entry: (index, groupName, status, expires) => `🔹 *${index}. ${groupName}*\n  - *Status*: ${status}\n  - *Kedaluwarsa pada*: ${expires}\n\n`,
  no_groups_filtered: () => '📪 Tidak ada grup yang ditemukan dengan filter ini.',
  invalid_filter: (prefix) => `🤔 Filter tidak valid! Gunakan: ${prefix}daftarsewa [ven|atv|perm]`,
  error: () => '❌ Terjadi kesalahan saat mendaftar sewa 💔'
},
plugin_addaluguel: {
  only_owner: () => '🚫 Hanya pemilik utama yang dapat menambahkan sewa!',
  only_group: () => '🚫 Perintah ini hanya dapat digunakan di grup.',
  invalid_duration: (prefix) => `🤔 Durasi tidak valid. Gunakan jumlah hari (mis: 30) atau kata "permanente".\nContoh: ${prefix}tambahsewa 30`,
  success: (groupName, duration) => `✅ Sewa ditambahkan untuk grup *${groupName}*! Durasi: ${duration}.`,
  error_add: () => '❌ Gagal menambahkan sewa ke grup.',
  error: () => '❌ Terjadi kesalahan tak terduga saat menambahkan sewa.',
  permanent: () => 'Permanen',
  days: () => 'hari'
},
plugin_gerarcodigo: {
  only_owner: () => '🚫 Hanya pemilik utama yang dapat membuat kode!',
  invalid_usage: (prefix) => `🤔 Penggunaan: ${prefix}buatkode <hari|permanente> [id_grup_opsional]`,
  invalid_duration: () => '🤔 Durasi tidak valid. Gunakan jumlah hari (mis: 7) atau kata "permanente".',
  invalid_group_id: () => '🤔 ID grup target tidak valid. Berikan ID lengkap (nomor@g.us) atau biarkan kosong untuk kode umum.',
  success: (code, duration) => `✅ Kode dibuat: *${code}*\nDurasi: ${duration}`,
  target_group: (groupName, groupId) => `\nGrup target: *${groupName}* (${groupId})`,
  no_target_group: () => '\nGrup target: Grup apa saja',
  error_generate: () => '❌ Gagal membuat kode aktivasi.',
  error: () => '❌ Terjadi kesalahan tak terduga saat membuat kode.',
  permanent: () => 'Permanen',
  days: () => 'hari'
},
plugin_entrar: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik saya! 💔',
  invalid_link: (prefix) => `🤔 Masukkan tautan undangan yang valid! Contoh: ${prefix}gabung https://chat.whatsapp.com/...`,
  success: (groupName) => `✅ Berhasil bergabung dengan grup *${groupName}*!`,
  error_join: () => '❌ Gagal bergabung dengan grup. Tautan tidak valid, izin ditolak, atau bot sudah ada di grup.',
  error: () => '❌ Terjadi kesalahan tak terduga saat mencoba bergabung dengan grup.'
},
plugin_modoliteglobal: {
  only_owner: () => '🚫 Perintah ini hanya untuk pemilik saya! 💔',
  lite_enabled: () => '👶 *Mode Lite diaktifkan secara global!* Konten yang tidak sesuai untuk anak-anak akan difilter di semua grup (kecuali jika dinonaktifkan secara eksplisit di beberapa grup).',
  lite_disabled: () => '🔞 *Mode Lite dinonaktifkan secara global!* Konten menu permainan akan ditampilkan sepenuhnya (kecuali jika diaktifkan secara eksplisit di beberapa grup).',
  error: () => '❌ Terjadi kesalahan tak terduga saat mengubah mode lite.'
}
};