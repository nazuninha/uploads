qa.c
