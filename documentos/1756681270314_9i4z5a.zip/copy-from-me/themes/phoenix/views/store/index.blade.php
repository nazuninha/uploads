@extends('layouts.main')
<?php use App\Models\ShopProduct; ?>

@section('content')
  <div class="container mx-auto grid px-6">
    <h2 class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200">
      {{ __('Store') }}
    </h2>

    @if ($isStoreEnabled && $shopProducts->count() > 0)
      <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
        <table class="w-full text-left text-sm text-gray-500 dark:text-gray-400">
          <thead class="bg-gray-50 text-xs uppercase text-gray-700 dark:bg-gray-700 dark:text-gray-400">
            <tr>
              <th scope="col" class="px-6 py-3">
                {{ __('Price') }}
              </th>
              <th scope="col" class="px-6 py-3">
                {{ __('Type') }}
              </th>
              <th scope="col" class="px-6 py-3">
                {{ __('Description') }}
              </th>
              <th scope="col" class="px-6 py-3">
                {{ __('Action') }}
              </th>
            </tr>
          </thead>
          <tbody>
            <?php /** @var $shopProduct ShopProduct */
            ?>
            @foreach ($shopProducts as $shopProduct)
              <tr class="border-b bg-white dark:border-gray-700 dark:bg-gray-800">
                <th scope="row" class="whitespace-nowrap px-6 py-4 font-medium">
                  {{ Currency::formatToCurrency($shopProduct->price, $shopProduct->currency_code) }}
                </th>
                <td class="px-6 py-4">
                  {{ strtolower($shopProduct->type) == 'credits' ? $credits_display_name : $shopProduct->type }}
                </td>
                <td class="px-6 py-4">
                  {{ $shopProduct->display }}
                  {{ strtolower($shopProduct->type) == 'credits' ? $credits_display_name : '' }}
                </td>
                <td class="px-6 py-4">
                  <a href="{{ route('checkout', $shopProduct->id) }}"
                    class="@cannot('user.shop.buy') disabled @endcannot focus:shadow-outline-purple rounded-md border border-transparent bg-primary-600 px-3 py-2 text-sm font-medium leading-5 text-white transition-colors duration-150 hover:bg-primary-700 focus:outline-none active:bg-primary-600">{{ __('Purchase') }}</a>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>
      </div>
      {{-- <x-pagination></x-pagination> --}}
    @else
      <x-alert title="" type="danger">
        @if ($shopProducts->count() == 0)
          {{ __('There are no store products!') }}
        @else
          {{ __('The store is not correctly configured!') }}
        @endif
      </x-alert>
    @endif

  </div>

  <script>
    const getUrlParameter = (param) => {
      const queryString = window.location.search;
      const urlParams = new URLSearchParams(queryString);
      return urlParams.get(param);
    }
    document.addEventListener("DOMContentLoaded", function(event) {
      const voucherCode = getUrlParameter('voucher');

      //if voucherCode not empty, open the modal and fill the input
      if (voucherCode) {
        document.querySelector('[x-data=data]')._x_dataStack[0].openRedeemModal()
        document.querySelector('#redeemVoucherCode').value = voucherCode;
      }
    });
  </script>

@endsection
