# Thank you for downloading Phoenix theme! <3

## Installation

1. Copy all files from `copy-from-me` to the root folder in ctrlpanel folder, it should be in `/var/www/ctrlpanel`.
2. You have to correct the permissions, to do that, follow [this section](https://ctrlpanel.gg/docs/Installation/getting-started#set-permissions) of the ctrlpanel's docs.
3. Run `php artisan migrate` to install the theme's settings.
4. Run `php artisan optimize:clear` to clear the cache.
5. Go to your ctrlpanel admin settings, and change the theme setting to "Phoenix".
6. If the styles look broken, hard refresh the page by `Ctrl + Shift + R`.

And that's it! The theme should be installed now!

## Troubleshoot

If you are having any issue while installing this theme, feel free to contact me on discord: `@flamekitten`, Or you can join My discord server [Flame Develops](https://discord.gg/wyh77B3x9v)
