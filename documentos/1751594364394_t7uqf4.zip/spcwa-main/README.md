# SPCWA
Spam Pairing Code Whatsapp using Javascript and Nodejs
<div align="center">
  <p>
    <img src="https://telegra.ph/file/6cb95459d6ff3a7e64901.jpg" width="250">
  </p>
  <p>This tool is used to spam Whatsapp<br>
    pairing codes and it is only used for small pranks. </p>
</div>

## System Requirement
• Nodejs version 20+

## Install in Termux
```bash
apt update && apt upgrade -y
apt install nodejs git -y
git clone https://github.com/ZeltNamizake/spcwa
```

## Install in Distro Linux
```bash
sudo apt update && apt upgrade
sudo apt install nodejs git
git clone https://github.com/ZeltNamizake/spcwa
```

## Install in Windows with Gitbash
You need to Install Nodejs and Git on your Device
```bash
git clone https://github.com/ZeltNamizake/spcwa
```

## Run SPCWA
```bash
cd spcwa
npm start
```

Note:
Every time you want to run a script check if there is a file named "auth" but, If there is a file named "auth" then delete it first before running the script by the command:
```bash
rm -r auth
```
If it has been deleted, you can run the script using the command:
```bash
npm start
```

###### Created by  ```Driyasz (ZeltNamizake)```
